"""
tests/test_talk.py — TALK sanity tests (brief section 4) + growth resize.

1. Gate forced closed -> TALK output equals HSNNM output (identical weights).
2. Gradients are nonzero for A, B and the gate parameters.
3. Active neurons per token never exceed k + m.
4. Top-k / top-m mask counts correct, winners and recruited sets disjoint.
5. 200-step overfit smoke on a tiny batch in bf16 (GPU only).
Plus: y_base equals HSNNM's lobe output exactly; growth resizes A/B coherently.

Run:  python -m pytest tests/test_talk.py -v
"""
import math
import sys
from pathlib import Path

import pytest
import torch
import torch.nn.functional as F

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE.parent.parent / "HSNNM"))

from config import Config, set_seed  # noqa: E402
from model.novel_model import build_novel_model  # noqa: E402
from model.lobe import Lobe, kwta_topk_mask  # noqa: E402
from talk_layer import TalkLobe, TalkConfig, resize_talk_optimizer_state  # noqa: E402
from talk_model import build_talk_model  # noqa: E402


def _cfg(vocab: int = 128) -> Config:
    c = Config.smoke()
    c.model.vocab_size = vocab
    c.train.use_amp = "fp32"
    return c


# ---------------------------------------------------------------------
# 4a. Masks (fast, direct)
# ---------------------------------------------------------------------
def test_masks_counts_and_disjoint():
    torch.manual_seed(0)
    n, N, ratio = 64, 384, 0.2
    r = 16
    lobe = TalkLobe(hidden_dim=384, ffn_dim=N, kwta_ratio=ratio,
                    use_kwta=True, r=r, recruit_ratio=0.05)
    x = torch.randn(n, 384) * 1.5
    out = lobe.talk_forward(x)

    k = lobe.kwta_k
    m = lobe._recruit_count()
    assert k == math.ceil(N * ratio)
    assert m == math.ceil(N * 0.05)

    win = out["win_mask"]
    rec = out["rec_mask"]
    # Exactly k winners (continuous activations -> no ties in practice).
    assert (win.sum(-1) == k).all(), win.sum(-1)
    assert (rec.sum(-1) == m).all(), rec.sum(-1)
    # Disjoint: winners cannot be recruited.
    assert not (win & rec).any()
    # k + m <= N
    assert k + m <= N


# ---------------------------------------------------------------------
# 3. Active neurons per token <= k + m
# ---------------------------------------------------------------------
def test_active_neurons_never_exceed_k_plus_m():
    torch.manual_seed(1)
    lobe = TalkLobe(384, 384, 0.2, True, r=16, recruit_ratio=0.05)
    x = torch.randn(256, 384) * 2.0
    out = lobe.talk_forward(x)
    active = out["win_mask"].sum(-1) + out["rec_mask"].sum(-1)
    assert (active <= lobe.kwta_k + lobe._recruit_count()).all()
    assert (active > 0).all()


# ---------------------------------------------------------------------
# y_base must equal HSNNM's lobe output exactly
# ---------------------------------------------------------------------
def test_y_base_matches_hsnnm_lobe():
    torch.manual_seed(2)
    hs = Lobe(384, 384, kwta_ratio=0.2, use_kwta=True)
    tk = TalkLobe(384, 384, kwta_ratio=0.2, use_kwta=True)
    tk.fc1.load_state_dict(hs.fc1.state_dict())
    tk.fc2.load_state_dict(hs.fc2.state_dict())
    with torch.no_grad():
        tk.strength.copy_(torch.rand_like(tk.strength) * 0.5)
    hs.strength.copy_(tk.strength)
    x = torch.randn(32, 384)
    with torch.no_grad():
        y_hs, _ = hs.forward_subnetwork(x)
        y_base = tk.talk_forward(x)["y_base"]
    torch.testing.assert_close(y_hs, y_base, rtol=1e-5, atol=1e-6)


# ---------------------------------------------------------------------
# 1. Gate forced closed -> identical to HSNNM (same weights, whole model)
# ---------------------------------------------------------------------
def test_gate_closed_equals_hsnnm():
    set_seed(0)
    cfg = _cfg()
    hs = build_novel_model(cfg)
    tk = build_talk_model(cfg)
    missing, unexpected = tk.load_state_dict(hs.state_dict(), strict=False)
    assert unexpected == [], f"unexpected keys: {unexpected}"
    assert missing, "TALK-only keys should be reported missing"
    for key in missing:
        assert key.endswith((".A", ".B")) or "talk_gate" in key, key

    for layer in tk.layers:
        layer.lobe_layer.gate_force = 0.0
    hs.eval()
    tk.eval()
    x = torch.randint(0, cfg.model.vocab_size, (2, 16))
    with torch.no_grad():
        logits_hs, _ = hs(x)
        logits_tk, _ = tk(x, update_hebbian=False)
    torch.testing.assert_close(logits_tk, logits_hs, rtol=1e-5, atol=1e-6)


# ---------------------------------------------------------------------
# 2. Gradients nonzero for A, B, gate params
# ---------------------------------------------------------------------
def test_gradients_reach_recruitment_and_gate():
    set_seed(1)
    cfg = _cfg()

    # (a) gate params: gradient flows through the straight-through estimator
    # even when the hard decision is closed.
    tk = build_talk_model(cfg)
    tk.train()
    x = torch.randint(0, cfg.model.vocab_size, (4, 16))
    y = torch.roll(x, -1, dims=1)
    logits, diag = tk(x)
    loss = F.cross_entropy(logits.reshape(-1, logits.size(-1)), y.reshape(-1))
    loss = loss + 0.01 * sum(d["talk_open_penalty"] for d in diag["per_layer"]) / len(diag["per_layer"])
    loss.backward()
    for li, layer in enumerate(tk.layers):
        g = layer.lobe_layer.talk_gate
        for name, p in (("w1", g.w1), ("w2", g.w2), ("b", g.b)):
            assert p.grad is not None, (li, name, "None")
            assert p.grad.abs().sum() > 0, (li, name, "zero grad")

    # (b) A/B receive gradient only when y_rec is multiplied by g = 1 — force
    # the gate open to verify the recruitment path itself.
    tk.zero_grad(set_to_none=True)
    for layer in tk.layers:
        layer.lobe_layer.gate_force = 1.0
    logits, diag = tk(x)
    loss = F.cross_entropy(logits.reshape(-1, logits.size(-1)), y.reshape(-1))
    loss.backward()
    for li, layer in enumerate(tk.layers):
        for lj, lobe in enumerate(layer.lobe_layer.lobes):
            assert lobe.A.grad is not None and lobe.A.grad.abs().sum() > 0, (li, lj, "A")
            assert lobe.B.grad is not None and lobe.B.grad.abs().sum() > 0, (li, lj, "B")


# ---------------------------------------------------------------------
# Growth: A/B resized coherently, forward still works
# ---------------------------------------------------------------------
def test_growth_resizes_recruitment_maps():
    torch.manual_seed(3)
    lobe = TalkLobe(64, 128, 0.2, True, r=8, recruit_ratio=0.05)
    old_N, old_k = lobe.ffn_dim, lobe.kwta_k
    lobe.grow_neurons(6, donor_strength_idx=0, noise_scale=0.01)
    assert lobe.ffn_dim == old_N + 6
    assert lobe.A.shape == (old_N + 6, 8)
    assert lobe.B.shape == (8, old_N + 6)
    assert lobe.fc1.weight.shape[0] == old_N + 6
    assert lobe.fc2.weight.shape[1] == old_N + 6
    # k scales with N, so the kept fraction stays close to the configured ratio.
    assert lobe.kwta_k == math.ceil((old_N + 6) * 0.2) or \
        abs(lobe.kwta_k / (old_N + 6) - 0.2) < 0.02
    out = lobe.talk_forward(torch.randn(4, 64))
    assert torch.isfinite(out["y_base"]).all()
    assert out["rec_mask"].sum(-1).max() <= lobe._recruit_count()


# ---------------------------------------------------------------------
# 5. 200-step overfit smoke in bf16 (GPU only)
# ---------------------------------------------------------------------
@pytest.mark.skipif(not torch.cuda.is_available(), reason="needs ROCm GPU for bf16")
def test_overfit_200_steps_bf16():
    set_seed(2)
    cfg = _cfg(vocab=64)
    cfg.model.max_seq_len = 64
    tk = build_talk_model(cfg).cuda()
    x = torch.randint(0, 64, (8, 16), device="cuda")
    y = torch.roll(x, -1, dims=1)
    opt = torch.optim.AdamW(tk.parameters(), lr=3e-3, betas=(0.9, 0.95))
    losses = []
    for step in range(200):
        tk.train()
        with torch.autocast(device_type="cuda", dtype=torch.bfloat16):
            logits, diag = tk(x)
            loss = F.cross_entropy(logits.reshape(-1, logits.size(-1)), y.reshape(-1))
            loss = loss + 0.01 * sum(d["talk_open_penalty"] for d in diag["per_layer"]) / len(diag["per_layer"])
        assert torch.isfinite(loss), f"NaN/Inf at step {step}"
        opt.zero_grad(set_to_none=True)
        loss.backward()
        opt.step()
        losses.append(float(loss.detach()))
    assert losses[-1] < 0.6 * losses[0], (losses[0], losses[-1])
    assert all(math.isfinite(v) for v in losses)


# ---------------------------------------------------------------------
# Growth: optimizer moment buffers resized, params swapped into groups
# ---------------------------------------------------------------------
def test_growth_preserves_optimizer_state():
    set_seed(4)
    cfg = _cfg()
    model = build_talk_model(cfg)
    model.train()
    opt = torch.optim.AdamW(model.parameters(), lr=1e-3)
    x = torch.randint(0, cfg.model.vocab_size, (4, 16))
    y = torch.roll(x, -1, dims=1)

    def step_once():
        logits = model(x)[0]
        loss = F.cross_entropy(logits.reshape(-1, logits.size(-1)), y.reshape(-1))
        opt.zero_grad(set_to_none=True)
        loss.backward()
        opt.step()

    step_once()  # populate Adam state
    gm = model.attach_growth_monitor()
    assert gm is not None
    gm.current_step = 10
    lobe = model.layers[0].lobe_layer.lobes[0]
    old_dim = lobe.ffn_dim
    old_A, old_B = lobe.A, lobe.B
    ev = gm.grow_lobe(0, 0, hebbian_tracker=model.hebbian_trackers[0],
                      optimizer=opt)
    resize_talk_optimizer_state(opt, lobe, old_A, old_B, ev["n_new"])

    assert lobe.ffn_dim == old_dim + ev["n_new"]
    assert opt.state[lobe.A]["exp_avg"].shape == lobe.A.shape
    assert opt.state[lobe.B]["exp_avg"].shape == lobe.B.shape
    assert opt.state[lobe.fc1.weight]["exp_avg"].shape == lobe.fc1.weight.shape
    assert opt.state[lobe.fc2.weight]["exp_avg"].shape == lobe.fc2.weight.shape
    ids = {id(p) for g in opt.param_groups for p in g["params"]}
    assert id(lobe.fc1.weight) in ids and id(lobe.fc2.weight) in ids

    step_once()  # training continues after growth
    assert torch.isfinite(model(x)[0]).all()


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
