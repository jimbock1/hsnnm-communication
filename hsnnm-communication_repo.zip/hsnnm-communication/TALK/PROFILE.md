# PROFILING — why 110 min here vs 40–60 min on Kaggle T4

Read-only profiling. No training code was modified and none of the five
comparison runs were started. All numbers come from short diagnostic runs
(100 steps) using the existing `train.py`, plus `torch.profiler` on a copy of
the same loop in a temporary script (since deleted).

Environment: RX 9060 XT (gfx1200, 15.92 GiB), torch 2.9.1+rocm7.2.1, Python
3.12, bf16 autocast, eager mode. Batch 64 × 256 unless stated. Data: TinyStories
`train[:10%]`, char vocab 123.

Measurement note: every 100-step run includes one 1-batch eval and the final
checkpoint save inside `wall_time_s`, so it is slightly conservative. Startup
(dataset load, model build, gate calibration) is outside the wall time.

---

## 0. TL;DR

**Correction:** the earlier token-budget explanation was wrong. I measured the
loader: 10 % of TinyStories is 191,072,541 chars, which packs to **11,047 train
batches per epoch** at 64 × 256. The config's `epochs: 2` is therefore
**22,094 steps / 362M tokens** — the same budget as the paper and the planned
five runs, *not* ~6,100 steps / ~100M tokens. The config comment ("~50M
tokens/epoch") is inaccurate for this dataset.

So the old Kaggle 40–60 min cannot be explained by fewer tokens. If its 2
epochs completed, `train_parallel = 51.1 min` for two jobs implies ~118k
tok/s/job (~236k aggregate), versus our measured **69.1k (HSNNM) / 53.0k
(TALK)** solo. The gap is per-token efficiency — T4 fp16/cuBLAS versus this
Windows ROCm bf16 path, plus the per-step sync stalls measured below — or the
Kaggle run did not actually complete 2 epochs (the report does not record its
step count). The files available cannot distinguish those two cases.

| | Tokens per run | Rate | Time |
|---|---|---|---|
| Kaggle config, 2 epochs (per job, 2 jobs shared T4), *if completed* | 362M | ~118k tok/s implied | 51.1 min reported |
| This plan, HSNNM | 360.4M | 69.1k tok/s | ~94 min + evals |
| This plan, TALK | 360.4M | 53.0k tok/s | ~120 min + evals |

At the same time, the step is **not** GPU-bound: one job leaves **~32–36 % of
the GPU idle**, almost entirely on host↔device synchronisation caused by the
routing code (boolean-mask indexing) and per-step diagnostics.

---

## 1. 100-step measurements

Real `train.py`, seed 0, `--steps 100 --eval-interval 1000 --eval-batches 1`,
TALK with `--gate-init-std 1.0`.

| Model | Batch | Wall (100 steps) | s/step | Tokens/s | GPU busy (Windows counter) |
|---|---|---|---|---|---|
| HSNNM | 64 | 23.7 s | 0.237 | **69,131** | **68.2 %** (median 69, p10 64, p90 71, max 74) |
| TALK | 64 | 30.9 s | 0.309 | **53,023** | **64.4 %** (median 66, p10 63, p90 70, max 70) |
| HSNNM | 128 | 39.5 s | 0.395 | 82,957 | not sampled |
| TALK | 128 | 53.1 s | 0.531 | 61,710 | not sampled |

`rocm-smi`/`amd-smi` are not installed in this ROCm Windows install, so GPU
utilisation was sampled at 2 Hz from Windows GPU Engine performance counters
(`Win32_PerfFormattedData_GPUPerformanceCounters_GPUEngine`, 3D + Compute
engines of the training process). Samples ≥20 % during the training phase were
used; startup (0 %) was excluded.

Cross-checks agree with the counter:

- Doubling batch from 64 to 128 doubles the token count per step but step time
  only rises 1.67× (HSNNM) / 1.72× (TALK). Fitting t = a + b·B:
  - HSNNM: fixed cost **a ≈ 79 ms/step (33 % of the step)**, marginal cost
    b ≈ 2.47 ms per row (≈ 9.6 µs/token).
  - TALK: fixed cost **a ≈ 87 ms/step (28 % of the step)**, marginal cost
    b ≈ 3.47 ms per row (≈ 13.6 µs/token).
- Concurrency (section 4) recovers a similar amount of idle capacity.

Projection for the real 22k-step runs (360.448M tokens, 44 evals each):

- HSNNM: 360.448M / 69.1k ≈ 87 min + evals ≈ **94 min**
- TALK: 360.448M / 53.0k ≈ 113 min + evals ≈ **120 min**

That reproduces the earlier ~110 min average; the five-run total is ~9 h.

---

## 2. torch.profiler, 50 steps

Temporary script reproduced `train.py`'s loop exactly (per-step `float(ce)`,
growth-signal push, optimizer/scheduler/clip) but skipped evals so the profile
is pure training steps. 5 warm-up steps, then `wait=0, warmup=1, active=50`.
Wall here is **inflated by the profiler** (2.8× HSNNM, 3.5× TALK) — use the
counts and CPU shares, not the absolute times.

| Per training step | HSNNM | TALK |
|---|---|---|
| Profiled wall | 0.66 s | 1.07 s |
| Real wall (from section 1) | 0.237 s | 0.309 s |
| `aten::item` / `aten::_local_scalar_dense` calls | **224** | **348** |
| `aten::nonzero` calls (each internally syncs) | **119** | **184** |
| `aten::_index_put_impl_` calls | 55.5 | 104 |
| `aten::copy_` calls | 568 | 889 |
| CPU op events | 10,232 | 17,053 |
| CPU self time in profiled window | 42.7 s / 50 steps = 853 ms/step | 68.2 s / 50 steps = 1,365 ms/step |
| of which `aten::nonzero` | 282 ms/step | 510 ms/step |
| of which `_local_scalar_dense` | 212 ms/step | 296 ms/step |

### Top 10 ops by CPU self time (50 profiled steps, totals in ms)

HSNNM:

| # | op | calls | self ms |
|---|---|---|---|
| 1 | `aten::nonzero` | 5,952 | 14,109 |
| 2 | `ProfilerStep*` | 50 | 12,475 |
| 3 | `aten::_local_scalar_dense` | 11,058 | 10,586 |
| 4 | `aten::copy_` | 23,214 | 1,727 |
| 5 | `aten::mm` | 5,823 | 375 |
| 6 | `aten::addmm` | 2,383 | 235 |
| 7 | `aten::_to_copy` | 19,828 | 217 |
| 8 | `aten::_index_put_impl_` | 2,776 | 180 |
| 9 | `aten::reshape` | 10,830 | 160 |
| 10 | `aten::index` | 3,176 | 146 |

TALK:

| # | op | calls | self ms |
|---|---|---|---|
| 1 | `aten::nonzero` | 9,200 | 25,490 |
| 2 | `ProfilerStep*` | 50 | 19,800 |
| 3 | `aten::_local_scalar_dense` | 17,169 | 14,785 |
| 4 | `aten::copy_` | 35,217 | 1,791 |
| 5 | `aten::mm` | 13,226 | 883 |
| 6 | `aten::_to_copy` | 34,182 | 331 |
| 7 | `aten::_index_put_impl_` | 5,200 | 319 |
| 8 | `aten::sum` | 10,679 | 235 |
| 9 | `aten::index` | 4,000 | 179 |
| 10 | `aten::t` | 28,792 | 168 |

### Top 10 ops by attributed device (GPU) time

ROCm device-time attribution in `key_averages()` double-counts parent/child
rows (the totals exceed wall time), so this is a **ranking only**, not a
GPU-time budget. `ProfilerStep*` is excluded.

HSNNM: `aten::bmm` 2,030 ms; `aten::nonzero` 1,903; `aten::copy_` 1,629;
`aten::as_strided` 1,501; `aten::_to_copy` 1,268; `aten::to` 977;
`aten::_local_scalar_dense` 968; `aten::_index_put_impl_` 890;
`aten::transpose` 858 (over 50 steps).

TALK: `aten::nonzero` 2,698 ms; `aten::as_strided` 2,271; `aten::copy_` 2,166;
`aten::_to_copy` 2,162; `aten::bmm` 2,067; `aten::topk` 1,807; `aten::to`
1,690; `aten::transpose` 1,303; `aten::_local_scalar_dense` 1,294.

The compute kernels (bmm/mm/SDPA) are visibly *not* the top cost. The top
costs are mask bookkeeping and host syncs.

### GPU compute vs idle

- Windows counter: GPU busy **68 % HSNNM / 64 % TALK**, i.e. **~1/3 idle**.
- Fixed-overhead fit from batch scaling: **33 % HSNNM / 28 % TALK** of the
  step is batch-independent (launch + sync + Python overhead).
- Those two independent estimates agree: the idle time is host-side waiting,
  not lack of arithmetic.

---

## 3. GPU→CPU sync inventory

Measured counts are per **training** step (profile window, no eval). “Implicit”
means a boolean-mask index allocates a dynamically sized result, so PyTorch
calls `nonzero` and reads the size on the host — a full stream sync even though
no `.item()` is written.

| Source | Location | HSNNM/step | TALK/step | Notes |
|---|---|---|---|---|
| NaN guard `if not torch.isfinite(loss)` | [train.py:478](TALK/train.py#L478) | 1 | 1 | bool tensor → Python → sync |
| Loss accumulation `float(ce.detach())` | [train.py:489](TALK/train.py#L489) | 1 | 1 | every step |
| TALK aux losses `float(ce/open/distill)` | [train.py:475](TALK/train.py#L475) | — | 3 | every step |
| Growth signals: util + entropy `.item()` | [novel_model.py:189](HSNNM/model/novel_model.py#L189), [:194](HSNNM/model/novel_model.py#L194) | 32 | 32 | 2 × 16 lobes that ran |
| `if not token_mask.any()` | [lobe.py:408](HSNNM/model/lobe.py#L408) | 16 | 16 | Python bool → sync, per lobe/layer |
| `int(token_mask.sum().item())` | [lobe.py:419](HSNNM/model/lobe.py#L419), [talk_layer.py:258](TALK/talk_layer.py#L258) | 16 | 16 | execution count |
| `c.mean().item()` in diagnostics | [lobe.py:431](HSNNM/model/lobe.py#L431), [talk_layer.py:295](TALK/talk_layer.py#L295) | 16 | 16 | per lobe |
| `active_sum += (...).sum().item()` | [talk_layer.py:271](TALK/talk_layer.py#L271) | — | 16 | per lobe |
| `div_sum += (...).sum().item()` | [talk_layer.py:278](TALK/talk_layer.py#L278) | — | 16 | per open lobe |
| `gate_map.mean().item()` | [talk_layer.py:299](TALK/talk_layer.py#L299) | — | 4 | per layer |
| Boolean indexing `x_flat[token_mask]`, `weights[token_mask]`, `out_flat[...] +=` | [lobe.py:413](HSNNM/model/lobe.py#L413)–[:417](HSNNM/model/lobe.py#L417), [talk_layer.py:256](TALK/talk_layer.py#L256) | implicit | implicit | 119 / 184 `nonzero` calls measured |
| `r["rec_mask"][g_hard > 0.5]` | [talk_layer.py:276](TALK/talk_layer.py#L276) | — | implicit | per lobe |
| Logging block every 50 steps (`float(loss)`, memory counters, parameter count, JSONL write, print) | [train.py:496](TALK/train.py#L496) | 1 / 50 steps | 5 / 50 steps | amortised |
| Eval every 500 steps: `float(tok_nll.sum())`, `int(valid.sum())`, 2 × `.cpu()` per batch | [train.py:262](TALK/train.py#L262)–[:269](TALK/train.py#L269) | ~4 × 50 batches per eval | same + gate `.cpu()` | amortised; capped at 50 batches |

**Measured totals:** HSNNM **224 scalar reads + 119 `nonzero` + 55.5 masked
writes per step**; TALK **348 scalar reads + 184 `nonzero` + 104 masked writes
per step**.

The big contributors are not the obvious `float(ce)`. They are the routing
data path: every one of the 16 (layer, lobe) pairs does a Python-level
`.any()`, a `.sum().item()`, a confidence `.item()`, two outputs of growth
diagnostics, and 3–4 boolean-mask index operations, each of which syncs.

---

## 4. Does one job leave the GPU idle? (concurrency)

Same 100 steps, launched simultaneously, each in its own process.

| Jobs | Per-job tokens/s | Aggregate | vs solo |
|---|---|---|---|
| HSNNM solo | 69.1k | 69.1k | 1.00× |
| TALK solo | 53.0k | 53.0k | 1.00× |
| HSNNM + TALK | 48.2k + 36.9k | **85.1k** | +23 % vs HSNNM solo |
| HSNNM + TALK + TALK | 37.1k + 26.6k + 26.7k | **90.4k** | +31 % vs HSNNM solo |

Yes — one job leaves the GPU idle (~1/3 of the time). Two jobs recover most of
it: each job slows to ~70 % of its solo rate, aggregate throughput rises ~23 %.
A third job adds only ~6 % more aggregate and pushes each job to ~50–54 % of
solo. Two concurrent jobs is the practical sweet spot; beyond that the shared
limiter is host-side (syncs, Python, single-threaded data loading), not
arithmetic.

---

## 5. Comparison with the original HSNNM training script

Sources: [HSNNM/training/train.py](HSNNM/training/train.py),
[HSNNM/configs/phase1_novel.yaml](HSNNM/configs/phase1_novel.yaml),
`Downloads/KAGGLE_REPORT.txt`, and HSNNM-4.pdf §3 ("22,000 steps,
approximately 360M tokens").

| | Original HSNNM script (Kaggle T4) | This `train.py` (9060 XT) |
|---|---|---|
| Steps | **2 epochs = 22,094 steps** (measured loader; config comment of ~50M tokens/epoch is wrong) | **22,000 steps** (paper) |
| Tokens/run | **≈362M** (191M-char slice × 2 epochs) | **360.4M** |
| Batch × seq | 64 × 256 | 64 × 256 (same) |
| Precision | fp16 + GradScaler (T4 has no bf16) | bf16 autocast + fp32 master weights |
| Parallelism | 2 models trained at once on one T4 (`train_parallel` = 51.1 min) | one job at a time |
| Per-job throughput | ≈118k tok/s implied by 51.1 min *if* 2 epochs completed | 53–69k tok/s |
| Data workers | 2 | 0 |
| Logging | every 25 steps; `loss.item()` only at log | every 50 steps, but `float(ce)` **every step** |
| Eval | every 500 steps, full val split | every 500 steps, fixed 50 batches |
| Checkpoints | every 1,000 steps (~86 MB each) | final + pre-growth only |
| Growth signals | every step (2 `.item()` per lobe) | every step (same) |
| Per-step NaN guard | `torch.isfinite` bool → sync every step | same |
| fp16 scaler | GradScaler `unscale_`/found-inf path (extra sync) | none (bf16) |
| Parameter/architecture/LR/warmup/clip | identical | identical |

So the old script did **not** avoid the per-step sync problem — it had the same
routing syncs, the same growth-signal `.item()`s, plus an fp16 `isfinite`-style
scaler check. It was 40–60 min because it trained **3.6× fewer tokens**, on a
T4 where two jobs shared the GPU.

At the same 2-epoch / 22,094-step budget this GPU takes roughly
362M / 69k ≈ 87 min (HSNNM) and 362M / 53k ≈ 113 min (TALK) of loop time, plus
evaluations — slower than the 51.1 min reported for two T4 jobs. The old script
was faster per token, not shorter.

The only extra per-step cost unique to this script is `float(ce.detach())`
(line 489) and, for TALK, the three aux-loss floats (line 475) — small compared
with the routing/diagnostic syncs that both versions share. The gains here are
elsewhere: bf16 with no GradScaler sync, 50-batch eval cap instead of full-val
eval, no periodic checkpoint writes, and one job owning the whole GPU.

---

## Conclusions

1. **Both configs are ~22k steps / 362M tokens.** The old config's 2 epochs and
   the paper's 22k steps are the same budget with this loader, so token count
   does not explain the 110 vs 51 min gap.
2. **The gap is per-token efficiency.** The Kaggle report implies ~118k tok/s
   per job (if 2 epochs completed) versus 69.1k/53.0k measured here; the report
   does not state its step count, so a shorter-than-config Kaggle run is the
   other possibility.
3. **A single job is ~2/3 GPU-busy.** ~1/3 of each step is host-side waiting,
   dominated by boolean-mask routing (`nonzero` + dynamic-shape indexing) and
   per-step diagnostics: 224 scalar reads + 119 `nonzero` per HSNNM step, 348 +
   184 per TALK step.
4. **Two concurrent jobs recover most of the idle capacity** (aggregate 85k
   tok/s vs 53–69k solo, each job at ~70 % of solo speed); three adds little.
5. If the intent is to reproduce the old **40–60 min wall time**, run the
   original 2-epoch budget (~6k steps) instead of the paper's 22k steps. That
   is a methodology choice, not a performance fix; this profiling pass did not
   change it.

No training code was modified; the five comparison runs remain unstarted.
