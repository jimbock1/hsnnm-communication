"""
watch.py — live side-by-side view of the three short6k runs.

    python watch.py            # refresh every 10 s until all runs are done
    python watch.py --once     # one table + one curves.png

Reads results/short6k/<run>.json and results/short6k/<run>/log.jsonl (which
train.py writes after every 50 steps and every eval). Never touches the GPU.
Writes results/short6k/watch.txt and results/short6k/curves.png.
"""
from __future__ import annotations

import argparse
import json
import os
import time
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

HERE = Path(__file__).resolve().parent
RESULTS = Path(os.environ.get("TALK_RESULTS",
                               str(HERE / "results" / "short6k")))
RUNS = ["hsnnm_s0", "talk_s0", "talk_s1", "talk_s2",
        "talkv2_s0", "talkv2_s1", "talkv2_s2", "dense_s0"]
CLEAR = "\033[2J\033[H"


def _load_json(run: str) -> dict | None:
    p = RESULTS / f"{run}.json"
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text())
    except Exception:  # noqa: BLE001
        return None


def _load_log(run: str) -> list:
    p = RESULTS / run / "log.jsonl"
    if not p.exists():
        return []
    recs = []
    try:
        for line in p.read_text(encoding="utf-8", errors="ignore").splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                recs.append(json.loads(line))
            except Exception:  # noqa: BLE001
                continue
    except Exception:  # noqa: BLE001
        pass
    return recs


def _fmt(v, nd=3):
    if v is None:
        return "-"
    if isinstance(v, float):
        return f"{v:.{nd}f}"
    return str(v)


def _row(run: str):
    summary = _load_json(run) or {}
    recs = _load_log(run)
    setup = summary.get("setup") or next(
        (r.get("setup") for r in recs if r.get("event") == "init"), {}) or {}
    steps_total = setup.get("steps") or 6100
    last_step = None
    train_loss = tok_s = eta = vram = util = None
    for r in reversed(recs):
        if r.get("event") == "train_step":
            last_step = r.get("step")
            train_loss = r.get("loss")
            tok_s = r.get("tokens_per_s")
            eta = r.get("eta_s")
            vram = r.get("gpu_peak_mb")
            util = r.get("gpu_util")
            break
    evals = [r for r in recs if r.get("event") == "eval"]
    last_eval = evals[-1] if evals else {}
    status = "done" if summary.get("complete") else ("run" if last_step else "wait")
    if summary.get("stopped_early"):
        status = "stop"
    return {
        "run": run,
        "step": last_step,
        "total": steps_total,
        "status": status,
        "loss": train_loss,
        "ppl": last_eval.get("val_ppl"),
        "eval_step": last_eval.get("step"),
        "tok_s": tok_s,
        "eta_min": (eta / 60) if isinstance(eta, (int, float)) else None,
        "open": last_eval.get("gate_open_rate_overall"),
        "active": last_eval.get("active_fraction"),
        "div": last_eval.get("recruit_diversity"),
        "util": util,
        "vram": (vram / 1024) if isinstance(vram, (int, float)) else None,
        "elapsed_min": (summary.get("wall_time_s") or 0) / 60
        if summary.get("complete") else None,
    }


def render() -> str:
    rows = [_row(r) for r in RUNS]
    head = (f"{'run':<10} {'step':>10} {'st':<4} {'loss':>8} {'val_ppl':>8} "
            f"{'@eval':>6} {'tok/s':>8} {'ETA m':>6} {'open':>6} {'active':>6} "
            f"{'div':>6} {'util%':>5} {'VRAM G':>6}")
    lines = [head, "-" * len(head)]
    for r in rows:
        step = f"{r['step']}/{r['total']}" if r["step"] else "-"
        lines.append(
            f"{r['run']:<10} {step:>10} {r['status']:<4} "
            f"{_fmt(r['loss'], 4):>8} {_fmt(r['ppl'], 2):>8} "
            f"{_fmt(r['eval_step']):>6} {_fmt(r['tok_s'], 0):>8} "
            f"{_fmt(r['eta_min'], 1):>6} {_fmt(r['open'], 3):>6} "
            f"{_fmt(r['active'], 3):>6} {_fmt(r['div'], 3):>6} "
            f"{_fmt(r['util'], 0):>5} {_fmt(r['vram'], 1):>6}")
    done = sum(1 for r in rows if r["status"] in ("done", "stop"))
    lines.append("-" * len(head))
    lines.append(f"{done}/{len(RUNS)} runs finished.  updated {time.strftime('%H:%M:%S')}  "
                 f"(log: {RESULTS})")
    return "\n".join(lines)


def plot() -> None:
    fig, axes = plt.subplots(1, 3, figsize=(15, 4.2))
    for run in RUNS:
        recs = _load_log(run)
        ts = [(r["step"], r["loss"]) for r in recs
              if r.get("event") == "train_step" and r.get("loss") is not None]
        if ts:
            axes[0].plot([a for a, _ in ts], [b for _, b in ts], lw=1.2, label=run)
        ev = [(r["step"], r.get("val_ppl")) for r in recs
              if r.get("event") == "eval" and r.get("val_ppl") is not None]
        if ev:
            axes[1].plot([a for a, _ in ev], [b for _, b in ev], marker="o",
                         ms=3, lw=1.2, label=run)
        op = [(r["step"], r.get("gate_open_rate_overall")) for r in recs
              if r.get("event") == "eval"
              and r.get("gate_open_rate_overall") is not None]
        if op:
            axes[2].plot([a for a, _ in op], [b for _, b in op], marker="o",
                         ms=3, lw=1.2, label=run)
    axes[0].set(title="train loss", xlabel="step")
    axes[0].set_yscale("log")
    axes[1].set(title="val perplexity (50-batch subset)", xlabel="step")
    axes[1].set_yscale("log")
    axes[2].set(title="TALK gate open rate", xlabel="step", ylim=(0, 1))
    for ax in axes:
        ax.grid(alpha=0.25)
        ax.legend(fontsize=8)
    fig.tight_layout()
    RESULTS.mkdir(parents=True, exist_ok=True)
    fig.savefig(RESULTS / "curves.png", dpi=110)
    plt.close(fig)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--interval", type=float, default=10.0)
    ap.add_argument("--once", action="store_true")
    args = ap.parse_args()

    last_plot = -1
    while True:
        text = render()
        print(CLEAR + text, flush=True)
        try:
            (RESULTS / "watch.txt").write_text(text + "\n", encoding="utf-8")
        except Exception:  # noqa: BLE001
            pass
        newest = 0
        for run in RUNS:
            for r in _load_log(run):
                if r.get("event") == "eval":
                    newest = max(newest, r.get("step", 0))
        if newest >= last_plot + 500 or last_plot < 0:
            try:
                plot()
                last_plot = newest
            except Exception as e:  # noqa: BLE001
                print(f"(plot failed: {type(e).__name__}: {e})")
        if args.once:
            return
        done = 0
        for run in RUNS:
            s = _load_json(run) or {}
            if s.get("complete"):
                done += 1
        if done == len(RUNS):
            return
        time.sleep(args.interval)


if __name__ == "__main__":
    main()
