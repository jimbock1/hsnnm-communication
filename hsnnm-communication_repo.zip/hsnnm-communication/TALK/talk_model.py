"""
talk_model.py — build a TALK model without editing HSNNM, plus FLOPs helpers.

The HSNNM NovelModel/NovelTransformerBlock are reused unchanged. We swap each
block's LobeLayer for a TalkLobeLayer and rebuild the Hebbian trackers so they
point at the new lobes.
"""
from __future__ import annotations

import math
import sys
from pathlib import Path
from typing import Optional

import torch

HSNNM_DIR = Path(__file__).resolve().parent.parent / "HSNNM"
if str(HSNNM_DIR) not in sys.path:
    sys.path.insert(0, str(HSNNM_DIR))

from config import count_parameters  # noqa: E402
from model.hebbian import build_hebbian_tracker  # noqa: E402
from model.novel_model import build_novel_model  # noqa: E402

from talk_layer import TalkConfig, TalkLobeLayer  # noqa: E402


def build_talk_model(config, talk_cfg: Optional[TalkConfig] = None):
    """Build HSNNM then replace every LobeLayer with a TalkLobeLayer."""
    talk_cfg = talk_cfg or TalkConfig()
    model = build_novel_model(config)

    for layer in model.layers:
        old = layer.lobe_layer
        layer.lobe_layer = TalkLobeLayer(
            hidden_dim=old.hidden_dim,
            ffn_dim=old.lobes[0].ffn_dim,
            num_lobes=old.num_lobes,
            top_k=old.top_k,
            kwta_ratio=old.kwta_ratio,
            use_kwta=old.use_kwta,
            routing_mode=old.routing_mode,
            talk=talk_cfg,
        )

    model.hebbian_trackers = [
        build_hebbian_tracker(layer.lobe_layer, config.hebbian)
        for layer in model.layers
    ]
    model.talk_cfg = talk_cfg
    return model


@torch.no_grad()
def calibrate_talk_gate(model, input_ids: torch.Tensor, device: str) -> dict:
    """Set each layer's gate bias so ~50% of tokens start with the gate open.

    Uses one training batch only (never validation/test data). Returns the
    pre/post open rates for logging.
    """
    was_training = model.training
    model.eval()
    x = input_ids.to(device)
    _, diag = model(x, update_hebbian=False)
    before = []
    for li, d in enumerate(diag["per_layer"]):
        s = d["talk_gate_score_map"].float()
        gate = model.layers[li].lobe_layer.talk_gate
        before.append(d["talk_open_rate"])
        # Offset the existing bias (s already contains it): median(s) -> 0.
        gate.b.data.add_(-s.median())
    _, diag2 = model(x, update_hebbian=False)
    after = [d["talk_open_rate"] for d in diag2["per_layer"]]
    if was_training:
        model.train()
    return {"before": before, "after": after}


def analytic_flops_per_token(model_name: str, config, open_rate: float = 0.0) -> int:
    """Same convention as HSNNM's estimate_flops_per_token.

    Counts 2*M*N*K per matmul; attention projections, lobes, routing gates,
    LM head. Ignores attention score/AV matmuls, softmax, LN, activations,
    k-WTA masking, and embedding lookup. TALK adds gate scoring, recruitment
    scoring (2*k*r + 2*r*N), and 4*m*H when the gate is open.
    """
    m = config.model
    H, V, L = m.hidden_dim, m.vocab_size, m.num_layers
    F = m.ffn_dim
    top_k = m.top_k_lobes
    lobes = m.lobes_per_layer
    attn = 8 * H * H

    if model_name == "dense":
        per_layer = attn + 4 * H * F
        return per_layer * L + 2 * H * V

    base_ffn = top_k * (4 * H * F)
    lobe_gates = lobes * 2 * H
    if model_name == "hsnnm":
        per_layer = attn + lobe_gates + base_ffn
        return per_layer * L + 2 * H * V

    if model_name == "talk":
        talk_cfg = getattr(config, "talk", TalkConfig())
        r = talk_cfg.r
        k = max(1, int(math.ceil(F * m.kwta_ratio)))
        mrec = max(1, int(math.ceil(F * talk_cfg.recruit_ratio)))
        recruit_scoring = top_k * (2 * k * r + 2 * r * F)
        talk_gate = 6.0
        open_extra = top_k * open_rate * (4 * mrec * H)
        per_layer = attn + lobe_gates + base_ffn + recruit_scoring + talk_gate + open_extra
        return int(round(per_layer * L + 2 * H * V))

    raise ValueError(f"unknown model_name: {model_name}")


def parameter_report(model) -> dict:
    return {
        "total_params": count_parameters(model),
        "details": model.parameter_report() if hasattr(model, "parameter_report") else {},
    }
