"""
gpu_sampler.py — per-process GPU utilisation sampler (Windows counters).

ROCm's rocm-smi / amd-smi are not available on this box, so we read the
Windows GPU Engine performance counters, which expose one instance per
(process, engine) pair. Utilisation is the sum over that process's 3D and
Compute engines, capped at 100 %.

Runs as a separate process: train.py launches it with its own PID and reads
the last sample from the JSONL at each log step (a file read, not a GPU sync).

    python gpu_sampler.py --pid 1234 --out runs/x/gpu/gpu.jsonl
"""
from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
import time
from pathlib import Path

PS_TEMPLATE = r"""
$ErrorActionPreference = 'SilentlyContinue'
Get-CimInstance -ClassName Win32_PerfFormattedData_GPUPerformanceCounters_GPUEngine |
  Where-Object { $_.Name -match 'engtype_(3D|Compute)' -and $_.Name -match 'pid_{pid}_' } |
  ForEach-Object { "$($_.UtilizationPercentage)" }
"""


def sample(pid: int) -> dict:
    cmd = ["powershell", "-NoProfile", "-NonInteractive", "-Command",
           PS_TEMPLATE.replace("{pid}", str(pid))]
    t0 = time.time()
    try:
        out = subprocess.run(cmd, capture_output=True, text=True, timeout=20)
        vals = []
        for line in out.stdout.splitlines():
            line = line.strip()
            if re.fullmatch(r"\d+(\.\d+)?", line):
                vals.append(float(line))
        util = min(100.0, sum(vals)) if vals else None
        return {"t": round(t0, 3), "util": util, "engines": len(vals)}
    except Exception as e:  # noqa: BLE001
        return {"t": round(t0, 3), "util": None, "error": type(e).__name__}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--pid", type=int, required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--interval", type=float, default=2.0)
    args = ap.parse_args()

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    with open(out, "w", encoding="utf-8", buffering=1) as f:
        while True:
            f.write(json.dumps(sample(args.pid)) + "\n")
            time.sleep(args.interval)


if __name__ == "__main__":
    main()
