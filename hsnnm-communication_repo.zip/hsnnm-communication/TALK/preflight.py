"""
preflight.py — verify the local ROCm/PyTorch stack before any training.

Checks, in order:
  1. torch build, HIP version, GPU name/VRAM
  2. bf16 matmul on GPU (correctness vs fp32) and fp16
  3. torch.compile availability (compiles a tiny function; falls back cleanly)
  4. one forward+backward at the paper batch size (64 x 256) for each model
     type, reporting peak VRAM; exits nonzero if it does not fit.

Run:  python preflight.py [--batch-size 64] [--seq-len 256] [--skip-models]
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import torch

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE.parent / "HSNNM"))

from config import Config  # noqa: E402


def _fail(msg: str) -> None:
    print(f"[FAIL] {msg}")
    sys.exit(1)


def check_torch() -> dict:
    info = {
        "torch": torch.__version__,
        "hip": torch.version.hip,
        "cuda_available": torch.cuda.is_available(),
        "bf16_supported": torch.cuda.is_bf16_supported() if torch.cuda.is_available() else False,
    }
    print(f"[torch] version={info['torch']} hip={info['hip']}")
    if not torch.cuda.is_available():
        _fail("torch.cuda.is_available() is False — no GPU visible to PyTorch")
    props = torch.cuda.get_device_properties(0)
    info.update({
        "device": torch.cuda.get_device_name(0),
        "vram_gib": round(props.total_memory / 1024**3, 2),
        "capability": f"{props.major}.{props.minor}",
    })
    print(f"[gpu] {info['device']}  VRAM={info['vram_gib']} GiB  bf16={info['bf16_supported']}")
    if not info["bf16_supported"]:
        _fail("GPU reports bf16 unsupported")
    return info


def check_matmul() -> dict:
    torch.manual_seed(0)
    out = {}
    for dtype in (torch.bfloat16, torch.float16):
        a = torch.randn(1024, 1024, device="cuda", dtype=torch.float32)
        b = torch.randn(1024, 1024, device="cuda", dtype=torch.float32)
        ref = (a @ b)
        got = (a.to(dtype) @ b.to(dtype)).float()
        rel = (got - ref).abs().max().item() / ref.abs().max().item()
        name = str(dtype).split(".")[-1]
        out[name] = {"max_rel_err": rel, "finite": bool(torch.isfinite(got).all())}
        print(f"[matmul] {name}: max_rel_err={rel:.2e} finite={out[name]['finite']}")
        if not out[name]["finite"] or rel > 5e-2:
            _fail(f"{name} matmul incorrect on GPU")
    return out


def check_compile() -> dict:
    def f(x):
        return torch.nn.functional.gelu(x) * 2.0

    x = torch.randn(64, 384, device="cuda")
    try:
        t0 = time.time()
        cf = torch.compile(f)
        y = cf(x)
        torch.cuda.synchronize()
        ok = bool(torch.isfinite(y).all())
        print(f"[compile] ok={ok} first_call_s={time.time() - t0:.1f}")
        return {"ok": ok, "first_call_s": round(time.time() - t0, 1)}
    except Exception as e:  # noqa: BLE001
        print(f"[compile] unavailable: {type(e).__name__}: {e}")
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def model_setup(model_name: str, batch_size: int, seq_len: int):
    """Build a paper-shaped model with a realistic vocab."""
    from config import DataConfig, ModelConfig, HebbianConfig, GrowthConfig, AblationConfig, TrainConfig

    cfg = Config(
        data=DataConfig(data_fraction=0.10, seq_len=seq_len, val_fraction=0.10, num_workers=0),
        model=ModelConfig(
            vocab_size=110, hidden_dim=384, max_seq_len=512, num_layers=4,
            num_heads=6, dropout=0.1, ffn_dim=384, lobes_per_layer=4,
            top_k_lobes=1, kwta_ratio=0.20, tie_embeddings=True,
        ),
        hebbian=HebbianConfig(enabled=True, increment=0.01, decay_rate=0.01),
        growth=GrowthConfig(enabled=True),
        ablation=AblationConfig(use_kwta=True, use_hebbian=True, use_growth=True),
        train=TrainConfig(batch_size=batch_size, use_amp="bf16"),
        model_type=model_name,
        name=f"preflight_{model_name}",
    )
    if model_name == "dense":
        cfg.model.ffn_dim = 1536
        cfg.hebbian.enabled = False
        cfg.growth.enabled = False
        cfg.ablation = AblationConfig(use_kwta=False, use_hebbian=False,
                                      use_growth=False, routing_mode="learned")
    return cfg


def check_model(model_name: str, batch_size: int, seq_len: int) -> dict:
    from config import count_parameters, set_seed
    from model.baseline_model import build_baseline_model
    from model.novel_model import build_novel_model

    set_seed(0)
    cfg = model_setup(model_name, batch_size, seq_len)
    if model_name == "dense":
        model = build_baseline_model(cfg)
    elif model_name == "hsnnm":
        model = build_novel_model(cfg)
    else:
        from talk_model import build_talk_model
        model = build_talk_model(cfg)
    model = model.cuda()

    torch.cuda.empty_cache()
    torch.cuda.reset_peak_memory_stats()
    x = torch.randint(0, cfg.model.vocab_size, (batch_size, seq_len), device="cuda")
    y = torch.randint(0, cfg.model.vocab_size, (batch_size, seq_len), device="cuda")

    opt = torch.optim.AdamW(model.parameters(), lr=3e-4)
    t0 = time.time()
    with torch.autocast(device_type="cuda", dtype=torch.bfloat16):
        if model_name == "dense":
            logits = model(x)
            diag = {}
        else:
            logits, diag = model(x)
        loss = torch.nn.functional.cross_entropy(
            logits.reshape(-1, logits.size(-1)), y.reshape(-1))
        if model_name == "talk":
            aux = sum(d["talk_open_penalty"] for d in diag["per_layer"]) / len(diag["per_layer"])
            loss = loss + 0.01 * aux
    opt.zero_grad()
    loss.backward()
    opt.step()
    torch.cuda.synchronize()
    peak = torch.cuda.max_memory_allocated() / 1024**3
    finite = bool(torch.isfinite(loss))
    rec = {
        "model": model_name,
        "params": count_parameters(model),
        "loss": float(loss.item()),
        "finite": finite,
        "peak_vram_gib": round(peak, 2),
        "step_time_s": round(time.time() - t0, 2),
    }
    print(f"[model] {model_name}: params={rec['params']:,} loss={rec['loss']:.4f} "
          f"peak={rec['peak_vram_gib']} GiB step={rec['step_time_s']}s finite={finite}")
    if model_name == "talk":
        from talk_model import calibrate_talk_gate
        cal = calibrate_talk_gate(model, x, "cuda")
        rec["open_rate_before_calibration"] = cal["before"]
        rec["open_rate"] = cal["after"]
        print(f"[model] talk open rate before/after init calibration: "
              f"{[round(v, 3) for v in cal['before']]} -> "
              f"{[round(v, 3) for v in cal['after']]}")
    if not finite:
        _fail(f"{model_name} produced non-finite loss at paper batch size")
    del model, opt
    torch.cuda.empty_cache()
    return rec


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--batch-size", type=int, default=64)
    ap.add_argument("--seq-len", type=int, default=256)
    ap.add_argument("--skip-models", action="store_true")
    ap.add_argument("--out", default=str(HERE / "results" / "preflight.json"))
    args = ap.parse_args()

    results = {"torch": check_torch(), "matmul": check_matmul(), "compile": check_compile()}
    if not args.skip_models:
        results["models"] = [check_model(n, args.batch_size, args.seq_len)
                             for n in ("dense", "hsnnm", "talk")]
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    Path(args.out).write_text(json.dumps(results, indent=2))
    print(f"\n[preflight] all checks passed -> {args.out}")


if __name__ == "__main__":
    main()
