# TALK on HSNNM — local implementation, preflight, and runbook

Sidecar implementation of the TALK layer from `talk_implementation_brief.md`,
built on the existing HSNNM code in `../HSNNM` **without modifying it**, plus a
single training entry point, sanity tests, and the five-run comparison harness.

Nothing has been trained at full length yet. The five comparison runs are
launched only after the report is approved.

---

## 1. Files

| File | Purpose |
| --- | --- |
| `talk_layer.py` | `TalkConfig`, `TalkGate`, `TalkLobe` (recruitment maps A/B, `talk_forward`), `TalkLobeLayer` (gate + diagnostics), `resize_talk_optimizer_state`. Subclasses HSNNM `Lobe`/`LobeLayer`. |
| `talk_model.py` | `build_talk_model` (swaps `LobeLayer` -> `TalkLobeLayer`, rebuilds Hebbian trackers), `calibrate_talk_gate`, `analytic_flops_per_token`. |
| `train.py` | `python train.py --model {dense,hsnnm,talk} --seed N`. Paper-matched step loop, bf16, aux losses, growth, eval, JSON outputs. |
| `preflight.py` | GPU / bf16 / compile / fwd+bwd memory checks. Writes `results/preflight.json`. |
| `tests/test_talk.py` | 8 sanity tests (brief section 4 + growth optimizer state). |
| `summarize.py` | One table over `results/{dense_s0,hsnnm_s0,talk_s0..2}.json`. |
| `run_all.ps1` | Runs the five comparisons in order; skips `complete: true` results. |
| `TALK_HSNNM.ipynb` | Environment check, preflight, results table, curves. |
| `results/`, `runs/` | Per-run JSON + logs + checkpoints (created on use). |

HSNNM is imported by path (`../HSNNM`); no HSNNM file was edited.

---

## 2. Environment (verified on this PC)

| Item | Value |
| --- | --- |
| GPU | AMD Radeon RX 9060 XT, gfx1200, 15.92 GiB |
| Driver | 32.0.32029.2010 |
| ROCm SDK wheels | `rocm[libraries,devel]==7.2.1` (TheRock-style `rocm_sdk_*` packages) |
| PyTorch | `2.9.1+rocm7.2.1`, HIP `7.2.53211-158bd99533` |
| bf16 matmul | works (1024² max rel err 3.2e-3 vs fp32) |
| fp16 matmul | works (4.8e-4) |
| `torch.compile` | **unavailable** — no Triton on Windows. Eager mode is used. |
| Peak VRAM, 64 x 256 fwd+bwd | dense 2.18 GiB, HSNNM 2.26 GiB, TALK 2.80 GiB |

Install commands used (venv at `.venv`):

```powershell
.venv\Scripts\python.exe -m pip install `
  --find-links https://repo.radeon.com/rocm/windows/rocm-rel-7.2.1/ `
  "rocm[libraries,devel]==7.2.1"
.venv\Scripts\python.exe -m pip install --no-deps `
  "https://repo.radeon.com/rocm/windows/rocm-rel-7.2.1/torch-2.9.1%2Brocm7.2.1-cp312-cp312-win_amd64.whl"
```

Then `datasets`, `pytest`, `numpy`, `pyyaml`, `tqdm`, `tensorboard`, `matplotlib`,
`ipykernel`, `nbformat`, `nbconvert`, `nbclient`.

---

## 3. Commands

```powershell
# checks
.venv\Scripts\python.exe preflight.py
.venv\Scripts\python.exe -m pytest tests\test_talk.py -v

# one run
.venv\Scripts\python.exe train.py --model talk --seed 0 --gate-init-std 1.0

# all five (skips completed), then the table
.\run_all.ps1
```

`train.py --smoke` runs 40 steps on a 1 % slice (used to validate the pipeline).

---

## 4. Paper-matched settings (HSNNM-4, September revision)

4 layers, d_model 384, 6 heads, dropout 0.1, 4 lobes/layer, top-1 routing,
384 neurons/lobe, k-WTA 20 % (k = 77), GELU, residual outer skip.
Char-level TinyStories, first 10 % of the train split (same rows the earlier
pipeline selected), 10 % of stories held out, seq 256, batch 64, 22,000 steps
(360.4 M tokens), AdamW (0.9, 0.95), lr 3e-4, 200-step warmup + cosine, wd 0.1,
grad clip 1.0. Eval every 500 steps on the first 50 validation batches
(819 k tokens, fixed order and fixed story split across all runs).

**Precision is the one intentional deviation**: bf16 autocast with fp32 master
weights on the local GPU. The paper does not state its precision; the previous
Kaggle run used fp16 on a T4.

### Deviations and conflicts (also in the earlier `REPORT.md`)

1. **k-WTA ratio**: brief section 3 says 10 %; the paper and existing code use
   20 %. Hard rule 1 (paper-matched setup) wins: **20 %** is used for every run
   including dense/HSNNM, so the comparison is internally consistent.
2. **Hebbian decay**: paper 0.01; old YAML 0.001. **0.01** is used.
3. **Training budget**: paper's 22,000 steps instead of the old 2-epoch loop.
4. **Eval size**: capped to 50 fixed val batches per eval (same subset for all
   runs) to keep 44 evals per run affordable.
5. **Data slice**: `train[:10%]` (first rows) — identical to the previous
   `select(range(int(len*0.10)))`, without materializing the full corpus.
6. **Growth** is enabled exactly as HSNNM defines it (multi-signal saturation,
   500-step checks, 5,000-step cooldown, +32 neurons). Its thresholds are
   strict; if it never fires, that is logged as zero events, not hidden. Before
   every resize a `pre_update_growth_L*_l*_step*.pt` checkpoint is written for
   rollback (latest 2 per lobe are kept), and its path is recorded in
   `growth_events`.

---

## 5. TALK implementation notes

Per token and routed lobe, `h = GELU(x W1) * (1 + strength)`; `win_mask` is
HSNNM's k-WTA; `y_base = W2 (h * win_mask)` is bit-identical to HSNNM (tested).
Gate: `s = w1*margin + w2*mass + b`, `p = sigmoid(-s / T)`, straight-through
hard gate in training, hard gate at inference. Recruitment: `z = (h*mask) A`,
`scores = z B`, winners forced to `-inf`, hard top-`m` (m = ceil(0.05 N)),
`y_rec = W2(h * sigmoid(scores) * rec_mask)`, `y = y_base + g*y_rec`.
Losses: `CE + 0.01*mean(p) + 0.1*MSE(y, W2(h).detach())`, training only.

Implementation choices worth knowing:

- **Gate bias calibration.** Bias `b` is offset on one training batch so the
  hard open rate starts at ~50 % in every layer (brief 3.1). Verified:
  `[0.50, 0.50, 0.50, 0.50]`.
- **Gate init scale (flagged).** With the default `w1,w2 ~ N(0, 0.01)` the score
  is O(1e-4) while margin/mass are O(0.05); the open-rate penalty then flips the
  whole gate closed within ~20 steps and the sigmoid saturates (open rate 0.000
  for the rest of a 300-step probe). With `gate_init_std = 1.0` the gate stays
  alive: probe open rate 0.503 at step 150, 0.318 at step 300, with val loss
  2.198 vs 2.202 (default) — a wash in loss, but only the larger init actually
  exercises recruitment. `run_all.ps1` passes `--gate-init-std 1.0`. This is the
  strongest open decision in the setup; reverting to 0.01 makes TALK collapse to
  HSNNM behavior.
- **Growth and A/B.** `TalkLobe.grow_neurons` creates **new** `A`/`B`
  Parameters (not `.data` swaps — a `.data` resize after optimizer history
  produces invalid-gradient errors). `resize_talk_optimizer_state` transfers and
  zero-pads Adam moments and swaps the new params into the param groups, exactly
  like `GrowthMonitor` does for `fc1/fc2`. Covered by a test.
- **Diversity** counts distinct recruited neurons per lobe across a batch over
  **open-gate tokens only**, divided by N (closed-gate recruitment is not used).
- `corr` is the Pearson correlation between per-token CE and the layer-averaged
  hard gate decision on the eval subset.

---

## 6. FLOPs convention

`2*M*N*K` per matmul. Per token: attention projections `8H²`; dense FFN
`4HF`; HSNNM `lobes*2H` gates + `top_k*4HF`; LM head `2HV`. Omitted: attention
score/AV matmuls, softmax, LayerNorm, activations, k-WTA masking, embedding
lookup. TALK adds `6` (gate) + `2kr + 2rF` (recruitment scoring) per layer and
`4mH * open_rate` (recruited up/down projections).

At V = 123 (10 % slice), H = 384, F = 384, L = 4, k = 77, r = 16, m = 20:

| model | FLOPs/token | vs dense |
| --- | --- | --- |
| dense (F=1536) | 14,250,240 | — |
| HSNNM | 7,184,640 | −49.58 % |
| TALK, gate closed | 7,243,672 | −49.17 % |
| TALK, gate fully open | 7,366,552 | −48.30 % |

The paper's 49.6 % reduction is reproduced by this convention.

---

## 7. Sanity tests (all passing)

`python -m pytest tests/test_talk.py -v` → **8 passed**:

1. gate forced closed → TALK logits equal HSNNM logits with identical weights
2. gradients nonzero for gate params; for A/B when the gate is open
3. active neurons per token ≤ k + m
4. exactly k winners, exactly m recruits, disjoint sets
5. 200-step overfit in bf16: loss falls, no NaNs
6. `y_base` equals HSNNM lobe output exactly
7. growth resizes A/B/fc1/fc2 coherently, k ratio preserved
8. growth preserves Adam state (padded moments, params swapped into groups,
   training continues)

---

## 8. Short probes (logged sweep, brief allows ≤ 6)

| run | steps | gate init std | val_ppl @300 | open rate @300 |
| --- | --- | --- | --- | --- |
| `talk_probe` | 300 | 0.01 (spec default) | 9.04 | 0.000 |
| `talk_probe_w1` | 300 | 1.0 | 9.01 | 0.318 |

Both on the 10 % slice, 5 eval batches, lr schedule compressed to 300 steps.
These are diagnostics, not hyperparameter selection on the final eval set.

---

## 9. Five-run plan and cost

| run | model | seed |
| --- | --- | --- |
| `dense_s0` | dense | 0 |
| `hsnnm_s0` | HSNNM | 0 |
| `talk_s0` | TALK | 0 |
| `talk_s1` | TALK | 1 |
| `talk_s2` | TALK | 2 |

Measured throughput ~55 k tokens/s → ~0.30 s/step → **~110 min per 22 k-step
run**, ~1.9 h including 44 evals and checkpointing; **~9.5 h for all five**
sequentially. `run_all.ps1` resumes by skipping completed runs.

---

## 10. Reporting rules

`summarize.py` prints the table and TALK mean ± population std. With one dense
and one HSNNM seed against three TALK seeds, a difference of a few percent in
perplexity is **inconclusive**; the final report will say so. No seed is dropped
or cherry-picked.
