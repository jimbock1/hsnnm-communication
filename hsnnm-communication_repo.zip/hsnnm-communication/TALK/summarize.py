"""
summarize.py — one table from results/*.json.

    python summarize.py

Reads the five comparison runs (dense_s0, hsnnm_s0, talk_s0, talk_s1, talk_s2).
Missing/incomplete runs are reported as such; nothing is fabricated.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path
from statistics import mean, pstdev

HERE = Path(__file__).resolve().parent
RESULTS = HERE / "results"
RUNS = [("dense", 0), ("hsnnm", 0), ("talk", 0), ("talk", 1), ("talk", 2)]


def _fmt(v, nd=4):
    if v is None:
        return "-"
    if isinstance(v, float):
        return f"{v:.{nd}f}"
    return str(v)


def load_runs() -> list:
    rows = []
    for model, seed in RUNS:
        path = RESULTS / f"{model}_s{seed}.json"
        row = {"run": f"{model}_s{seed}", "model": model, "seed": seed,
               "status": "missing"}
        if path.exists():
            try:
                d = json.loads(path.read_text())
                row.update({
                    "status": "done" if d.get("complete") else "partial",
                    "val_loss": d.get("final_val_loss"),
                    "val_ppl": d.get("final_val_ppl"),
                    "params": d.get("params_final", d.get("setup", {}).get("params")),
                    "flops": d.get("flops_per_token_at_open_rate", {}).get(model),
                    "flops_dense": d.get("flops_per_token_at_open_rate", {}).get("dense"),
                    "open_rate": d.get("gate", {}).get("gate_open_rate_overall"),
                    "active": d.get("gate", {}).get("active_fraction"),
                    "diversity": d.get("gate", {}).get("recruit_diversity"),
                    "corr": d.get("gate", {}).get("loss_gate_correlation"),
                    "wall_min": (d.get("wall_time_s") or 0) / 60,
                    "data": d,
                })
            except Exception as e:  # noqa: BLE001
                row["status"] = f"error: {e}"
        rows.append(row)
    return rows


def main() -> None:
    rows = load_runs()
    w = 96
    print("=" * w)
    print("TALK / HSNNM / DENSE - SUMMARY")
    print("=" * w)
    head = (f"{'run':<10} {'status':<8} {'val_ppl':>9} {'val_loss':>9} "
            f"{'params':>10} {'F/tok':>10} {'red%':>7} {'open':>6} "
            f"{'active':>7} {'div':>6} {'corr':>7} {'min':>6}")
    print(head)
    print("-" * w)
    for r in rows:
        red = None
        if r.get("flops") and r.get("flops_dense"):
            red = 1.0 - r["flops"] / r["flops_dense"]
        print(f"{r['run']:<10} {r['status']:<8} {_fmt(r.get('val_ppl'),2):>9} "
              f"{_fmt(r.get('val_loss')):>9} {_fmt(r.get('params')):>10} "
              f"{_fmt(r.get('flops')):>10} "
              f"{(f'{red*100:.1f}%' if red is not None else '-'):>7} "
              f"{_fmt(r.get('open_rate'),3):>6} {_fmt(r.get('active'),3):>7} "
              f"{_fmt(r.get('diversity'),3):>6} {_fmt(r.get('corr'),3):>7} "
              f"{_fmt(r.get('wall_min'),1):>6}")

    talks = [r for r in rows if r["model"] == "talk" and r["status"] == "done"]
    if talks:
        ppls = [r["val_ppl"] for r in talks]
        print("-" * w)
        print(f"TALK ({len(talks)} seed{'s' if len(talks) != 1 else ''}): "
              f"val_ppl mean {mean(ppls):.3f} +/- {pstdev(ppls):.3f} "
              f"(range {min(ppls):.3f}-{max(ppls):.3f})")
        opens = [r["open_rate"] for r in talks if r["open_rate"] is not None]
        if opens:
            print(f"     gate open mean {mean(opens):.3f}, "
                  f"active fraction mean {mean([r['active'] for r in talks]):.4f}")
        hs = next((r for r in rows if r["model"] == "hsnnm"), None)
        de = next((r for r in rows if r["model"] == "dense"), None)
        if hs and hs["status"] == "done":
            delta = mean(ppls) - hs["val_ppl"]
            print(f"     Δ vs HSNNM (single seed): {delta:+.3f} perplexity "
                  f"({'TALK better' if delta < 0 else 'HSNNM better'})")
        if de and de["status"] == "done":
            delta = mean(ppls) - de["val_ppl"]
            print(f"     Δ vs dense (single seed): {delta:+.3f} perplexity "
                  f"({'TALK better' if delta < 0 else 'dense better'})")
        print("     NOTE: with one dense/HSNNM seed and three TALK seeds, a small")
        print("     margin (a few percent of perplexity) is inconclusive.")

    if any(r["status"] == "missing" for r in rows):
        print("\nMissing runs. Launch them with:  .\\run_all.ps1")


if __name__ == "__main__":
    main()
