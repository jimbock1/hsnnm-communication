"""
train.py — short6k runs (dense / hsnnm / talk), seed 0.

    python train.py --model hsnnm --seed 0
    python train.py --model talk  --seed 0 --gate-init-std 1.0

Budget: 6,100 steps of 64 x 256 = 99.9M tokens (2 epochs of the 10 % slice).
Every optimiser/training setting is the original Kaggle phase-1 config scaled
to that length (warmup 200, cosine over 6,100, eval 500, growth check 500 /
cooldown 5,000, dropout 0.1, wd 0.1, clip 1.0). k-WTA stays at 20 %.

Outputs (all under results/short6k/):
    <run>.json              summary, eval curve, growth events, FLOPs
    <run>/log.jsonl         per-50-step and per-eval records
    <run>/ckpt/             step_XXXXXX.pt every 500 steps (last 3 kept)
                            + pre_update_growth_*.pt rollback points
    <run>/samples/          text generations every 1,000 steps + final greedy
    <run>/gpu/gpu.jsonl     GPU utilisation sampled by gpu_sampler.py
"""
from __future__ import annotations

import argparse
import json
import logging
import math
import os
import random
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Optional

import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader, Dataset

HERE = Path(__file__).resolve().parent
HSNNM = HERE.parent / "HSNNM"
for p in (str(HERE), str(HSNNM)):
    if p not in sys.path:
        sys.path.insert(0, p)

from config import (  # noqa: E402
    Config, DataConfig, ModelConfig, HebbianConfig, GrowthConfig,
    AblationConfig, TrainConfig, set_seed, count_parameters,
)
from model.tokenizer import CharTokenizer  # noqa: E402
from model.baseline_model import build_baseline_model  # noqa: E402
from model.novel_model import build_novel_model  # noqa: E402
from training.losses import lm_loss  # noqa: E402
from training.checkpoint import save_pre_update_checkpoint  # noqa: E402
from data.dataset_loader import CharLMDataset  # noqa: E402

from talk_layer import TalkConfig, resize_talk_optimizer_state  # noqa: E402
from talk_model import (build_talk_model, analytic_flops_per_token,  # noqa: E402
                        calibrate_talk_gate)

log = logging.getLogger("train")

# ---------------------------------------------------------------------
# Budget / settings
# ---------------------------------------------------------------------
DEFAULTS = {
    "steps": 6_100,            # 2 epochs of the 10 % slice (scale, not ~6.1k guess)
    "batch_size": 64,
    "seq_len": 256,
    "lr": 3e-4,
    "weight_decay": 0.1,
    "warmup_steps": 200,
    "grad_clip": 1.0,
    "data_fraction": 0.10,
    "val_fraction": 0.05,      # phase1_novel.yaml
    "eval_interval": 500,
    "log_interval": 50,
    "eval_batches": 50,        # fixed first-N subset shared by all runs
    "dropout": 0.1,
    "precision": "bf16",
    "ckpt_interval": 500,
}
DATA_SEED = 42
RESULTS = Path(os.environ.get("TALK_RESULTS",
                              str(HERE / "results" / "short6k")))


# ---------------------------------------------------------------------
# Small helpers
# ---------------------------------------------------------------------
def _keep_latest_rollbacks(ckpt_dir: Path, li: int, lj: int, keep: int = 2) -> None:
    files = sorted(ckpt_dir.glob(f"pre_update_growth_L{li}_l{lj}_step*.pt"),
                   key=lambda p: p.stat().st_mtime, reverse=True)
    for p in files[keep:]:
        try:
            p.unlink()
        except OSError:
            pass


def _rng_state() -> dict:
    st = {"torch": torch.get_rng_state(), "python": random.getstate(),
          "numpy": np.random.get_state()}
    if torch.cuda.is_available():
        st["cuda"] = torch.cuda.get_rng_state_all()
    return st


def _set_rng_state(st: dict) -> None:
    if not st:
        return
    if "torch" in st:
        torch.set_rng_state(st["torch"].cpu())
    if "cuda" in st and torch.cuda.is_available():
        torch.cuda.set_rng_state_all([s.cpu() for s in st["cuda"]])
    if "python" in st:
        random.setstate(st["python"])
    if "numpy" in st:
        np.random.set_state(st["numpy"])


def _pearson_t(a: torch.Tensor, b: torch.Tensor) -> torch.Tensor:
    a = a.double() - a.double().mean()
    b = b.double() - b.double().mean()
    den = a.norm() * b.norm()
    zero = torch.zeros((), device=a.device, dtype=torch.float64)
    return torch.where(den > 1e-12, (a * b).sum() / den.clamp_min(1e-12), zero)


def _last_gpu_util(path: Path) -> Optional[float]:
    try:
        lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()
        for line in reversed(lines[-6:]):
            rec = json.loads(line)
            if rec.get("util") is not None:
                return float(rec["util"])
    except Exception:  # noqa: BLE001
        pass
    return None


def _quant4(t: torch.Tensor):
    q = torch.quantile(t, torch.tensor([0.1, 0.5, 0.9], device=t.device))
    return t.mean(), q[0], q[1], q[2]


# ---------------------------------------------------------------------
# Data
# ---------------------------------------------------------------------
def load_texts(fraction: float, cache_dir: Optional[str] = None) -> list:
    from datasets import load_dataset
    pct = fraction * 100.0
    if fraction >= 1.0:
        ds = load_dataset("roneneldan/TinyStories", split="train",
                          cache_dir=cache_dir)
    elif pct >= 1.0 and abs(pct - round(pct)) < 1e-9:
        ds = load_dataset("roneneldan/TinyStories", split=f"train[:{int(pct)}%]",
                          cache_dir=cache_dir)
    else:
        # Sub-percent slices are not valid HF split strings; take a 1 % slice
        # and select inside it (smoke/resume tests only).
        ds = load_dataset("roneneldan/TinyStories", split="train[:1%]",
                          cache_dir=cache_dir)
        n = max(1, int(len(ds) * fraction / 0.01))
        ds = ds.select(range(min(n, len(ds))))
    return [row["text"] for row in ds]


def _load_corpus(path: str) -> list:
    """Local corpora: JSONL with a "text" field per line, or a plain .txt
    split on blank lines."""
    p = Path(path)
    if p.suffix == ".jsonl":
        docs = []
        with open(p, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    docs.append(json.loads(line)["text"])
        return docs
    text = p.read_text(encoding="utf-8")
    sep = chr(10) + chr(10)
    return [t for t in text.split(sep) if t.strip()]


class _PackedDocs(Dataset):
    """CharLMDataset-equivalent packing for large corpora.

    Encodes one document at a time into a single int32 buffer: a Python list
    of 500M ints would cost ~15 GB, this stays at ~2 GB."""

    def __init__(self, texts, tokenizer, seq_len, is_validation,
                 val_fraction, seed):
        self.seq_len = seq_len
        g = torch.Generator().manual_seed(seed)
        perm = torch.randperm(len(texts), generator=g).tolist()
        n_val = max(1, int(len(texts) * val_fraction))
        idxs = perm[:n_val] if is_validation else perm[n_val:]
        sep = tokenizer.encode(chr(10))[0]
        parts = []
        for i in idxs:
            arr = np.asarray(tokenizer.encode(texts[i]), dtype=np.int32)
            parts.append(arr)
            parts.append(np.asarray([sep], dtype=np.int32))
        buf = np.concatenate(parts)
        del parts
        chunk = seq_len + 1
        n = buf.size // chunk
        self._data = torch.from_numpy(buf[: n * chunk].reshape(n, chunk))
        print(f"{'val' if is_validation else 'train'} set: {n} chunks of "
              f"length {chunk} ({n * chunk / 1e6:.1f}M tokens)", flush=True)

    def __len__(self):
        return self._data.size(0)

    def __getitem__(self, idx):
        chunk = self._data[idx]
        return chunk[:-1].long(), chunk[1:].long()


def build_loaders(fraction: float, seq_len: int, batch_size: int,
                  val_fraction: float, seed: int,
                  cache_dir: Optional[str] = None,
                  corpus: Optional[str] = None):
    if corpus:
        texts = _load_corpus(corpus)
        print(f"corpus {corpus}: {len(texts)} docs, "
              f"{sum(len(t) for t in texts)/1e6:.1f}M chars", flush=True)
        tok = CharTokenizer.from_texts(texts)
        train_ds = _PackedDocs(texts, tok, seq_len, is_validation=False,
                               val_fraction=val_fraction, seed=DATA_SEED)
        val_ds = _PackedDocs(texts, tok, seq_len, is_validation=True,
                             val_fraction=val_fraction, seed=DATA_SEED)
    else:
        texts = load_texts(fraction, cache_dir)
        tok = CharTokenizer.from_texts(texts)
        train_ds = CharLMDataset(texts, tok, seq_len, is_validation=False,
                                 val_fraction=val_fraction, seed=DATA_SEED)
        val_ds = CharLMDataset(texts, tok, seq_len, is_validation=True,
                               val_fraction=val_fraction, seed=DATA_SEED)
    order_gen = torch.Generator().manual_seed(seed)
    train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True,
                              generator=order_gen, num_workers=0, drop_last=True)
    val_loader = DataLoader(val_ds, batch_size=batch_size, shuffle=False,
                            num_workers=0, drop_last=False)
    return texts, tok, train_loader, val_loader


# ---------------------------------------------------------------------
# Config / model / optimiser
# ---------------------------------------------------------------------
def build_config(args) -> Config:
    cfg = Config(
        data=DataConfig(data_fraction=args.data_fraction, seq_len=args.seq_len,
                        val_fraction=args.val_fraction, num_workers=0),
        model=ModelConfig(
            vocab_size=110, hidden_dim=384, max_seq_len=512, num_layers=4,
            num_heads=6, dropout=DEFAULTS["dropout"], ffn_dim=384,
            lobes_per_layer=4, top_k_lobes=1, kwta_ratio=0.20,
            tie_embeddings=True,
        ),
        hebbian=HebbianConfig(enabled=True, increment=0.01, decay_rate=0.01),
        growth=GrowthConfig(
            enabled=True, check_interval_steps=500, rolling_window=200,
            confidence_threshold=0.75, utilization_threshold=0.85,
            entropy_threshold=0.90, persistence_ratio=0.95,
            neurons_per_growth=32, param_ceiling=1_000_000_000,
            minimum_growth_interval=5000,
        ),
        ablation=AblationConfig(use_kwta=True, use_hebbian=True,
                                use_growth=True, routing_mode="learned"),
        train=TrainConfig(
            seed=args.seed, batch_size=args.batch_size, grad_accum_steps=1,
            lr=args.lr, weight_decay=DEFAULTS["weight_decay"],
            warmup_steps=DEFAULTS["warmup_steps"], lr_schedule="cosine",
            grad_clip=DEFAULTS["grad_clip"], use_amp=DEFAULTS["precision"],
            log_interval_steps=DEFAULTS["log_interval"],
            eval_interval_steps=args.eval_interval,
            checkpoint_interval_steps=args.ckpt_interval,
            run_dir=str(RESULTS / args.run_name),
            log_expanded=True, log_flops=True,
        ),
        model_type=args.model, name=args.run_name,
    )
    if args.model == "dense":
        cfg.model.ffn_dim = 1536
        cfg.hebbian.enabled = False
        cfg.growth.enabled = False
        cfg.ablation = AblationConfig(use_kwta=False, use_hebbian=False,
                                      use_growth=False, routing_mode="learned")
    if args.no_growth:
        cfg.growth.enabled = False
    if args.no_hebbian:
        cfg.hebbian.enabled = False
        cfg.ablation.use_hebbian = False
    return cfg


def build_model(cfg: Config, talk_cfg: TalkConfig):
    if cfg.model_type == "dense":
        return build_baseline_model(cfg)
    if cfg.model_type == "hsnnm":
        return build_novel_model(cfg)
    return build_talk_model(cfg, talk_cfg)


def build_optimizer(model, cfg: Config):
    decay, no_decay = [], []
    for name, p in model.named_parameters():
        if not p.requires_grad:
            continue
        if p.ndim < 2 or name.endswith(".bias") or "ln" in name.lower():
            no_decay.append(p)
        else:
            decay.append(p)
    return torch.optim.AdamW(
        [{"params": decay, "weight_decay": cfg.train.weight_decay},
         {"params": no_decay, "weight_decay": 0.0}],
        lr=cfg.train.lr, betas=(0.9, 0.95), eps=1e-8,
    )


def build_scheduler(optimizer, total_steps: int, warmup: int):
    def f(s):
        if s < warmup:
            return s / max(1, warmup)
        progress = (s - warmup) / max(1, total_steps - warmup)
        return 0.5 * (1.0 + math.cos(math.pi * min(1.0, progress)))
    return torch.optim.lr_scheduler.LambdaLR(optimizer, f)


def flops_table(cfg: Config, open_rate: float = 0.0) -> dict:
    import copy
    dense_cfg = copy.copy(cfg)
    dense_cfg.model = copy.copy(cfg.model)
    dense_cfg.model.ffn_dim = 1536
    novel_cfg = copy.copy(cfg)
    novel_cfg.model = copy.copy(cfg.model)
    novel_cfg.model.ffn_dim = 384
    return {
        "dense": analytic_flops_per_token("dense", dense_cfg),
        "hsnnm": analytic_flops_per_token("hsnnm", novel_cfg),
        "talk": analytic_flops_per_token("talk", novel_cfg, open_rate),
    }


# ---------------------------------------------------------------------
# Checkpointing
# ---------------------------------------------------------------------
def _rebuild_to_counts(model, counts) -> None:
    """Grow freshly-built lobes to the saved per-lobe ffn_dim (after growth)."""
    if not counts:
        return
    for li, layer_counts in enumerate(counts):
        lobe_layer = model.layers[li].lobe_layer
        for lj, target in enumerate(layer_counts):
            lobe = lobe_layer.lobes[lj]
            if target > lobe.ffn_dim:
                lobe.grow_neurons(target - lobe.ffn_dim,
                                  donor_strength_idx=0, noise_scale=0.0)


def _gm_state(gm) -> Optional[dict]:
    if gm is None:
        return None
    return {
        "current_step": gm.current_step,
        "last_growth_step": gm.last_growth_step,
        "windows": [[{"conf": list(w.conf), "util": list(w.util),
                      "entr": list(w.entr)} for w in row]
                    for row in gm.windows],
    }


def _restore_gm(gm, st: Optional[dict]) -> None:
    if gm is None or not st:
        return
    gm.current_step = st.get("current_step", gm.current_step)
    gm.last_growth_step = st.get("last_growth_step", gm.last_growth_step)
    for li, row in enumerate(st.get("windows", [])):
        for lj, w in enumerate(row):
            win = gm.windows[li][lj]
            win.conf.extend(w.get("conf", []))
            win.util.extend(w.get("util", []))
            win.entr.extend(w.get("entr", []))


def save_ckpt(path: Path, model, optimizer, scheduler, tok, cfg, args,
              step: int, best, eval_curve, growth_events, gm,
              nonfinite: dict, timers: dict) -> None:
    payload = {
        "model_state_dict": model.state_dict(),
        "optimizer_state_dict": optimizer.state_dict(),
        "scheduler_state_dict": scheduler.state_dict(),
        "step": int(step),
        "lobe_neuron_counts": (model.get_lobe_neuron_counts()
                               if hasattr(model, "get_lobe_neuron_counts") else None),
        "rng": _rng_state(),
        "best": best,
        "eval_curve": eval_curve,
        "growth_events": growth_events,
        "growth_monitor": _gm_state(gm),
        "config": cfg.to_dict(),
        "args": vars(args),
        "nonfinite": nonfinite,
        "timers": timers,
        "tokenizer": tok.to_dict(),
    }
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".pt.tmp")
    torch.save(payload, tmp)
    tmp.replace(path)


def _find_latest(ckpt_dir: Path) -> Optional[Path]:
    files = sorted(ckpt_dir.glob("step_*.pt"), key=lambda p: p.stem)
    return files[-1] if files else None


def _prune_ckpts(ckpt_dir: Path, keep: int = 3) -> None:
    files = sorted(ckpt_dir.glob("step_*.pt"), key=lambda p: p.stem)
    for p in files[:-keep] if len(files) > keep else []:
        try:
            p.unlink()
        except OSError:
            pass


# ---------------------------------------------------------------------
# Evaluation
# ---------------------------------------------------------------------
@torch.no_grad()
def evaluate(model_name: str, model, loader, max_batches: int,
             detailed: bool = True) -> dict:
    """One pass over the first `max_batches` batches (1e9 = full split).

    All GPU reads are accumulated as tensors and converted with a single
    `.tolist()` at the end; the only per-batch host reads are the ones the
    model already makes (confidence means, open rates, execution counts).
    """
    model.eval()
    dev = "cuda"
    if model_name == "talk":
        for layer in model.layers:
            layer.lobe_layer.collect_rec_masks = detailed

    nll = torch.zeros((), device=dev, dtype=torch.float64)
    ntok = torch.zeros((), device=dev, dtype=torch.float64)
    open_nll = torch.zeros((), device=dev, dtype=torch.float64)
    open_tok = torch.zeros((), device=dev, dtype=torch.float64)
    closed_nll = torch.zeros((), device=dev, dtype=torch.float64)
    closed_tok = torch.zeros((), device=dev, dtype=torch.float64)

    losses, gates, margins, masses, rec_counts, gscores = [], [], [], [], [], []
    prev_rec: dict = {}
    match_exact = torch.zeros((), device=dev, dtype=torch.float64)
    match_overlap = torch.zeros((), device=dev, dtype=torch.float64)
    match_n = torch.zeros((), device=dev, dtype=torch.float64)

    conf_sum: dict = {}
    freq_sum: dict = {}
    freq_cnt: dict = {}
    lobe_counts: dict = {}
    div_sum: dict = {}
    div_n: dict = {}
    layer_tokens = 0
    n_batches = 0
    n_layers = n_lobes = 0
    open_layer: list = []
    active_layer: list = []

    for x, y in loader:
        x = x.cuda(non_blocking=True)
        y = y.cuda(non_blocking=True)
        with torch.autocast(device_type="cuda", dtype=torch.bfloat16):
            if model_name == "dense":
                logits = model(x)
                diag = None
            else:
                logits, diag = model(x, update_hebbian=False)
        flat_logits = logits.reshape(-1, logits.size(-1)).float()
        flat_y = y.reshape(-1)
        tok_nll = F.cross_entropy(flat_logits, flat_y, ignore_index=0,
                                  reduction="none")
        valid = flat_y != 0
        nll += tok_nll[valid].sum().double()
        ntok += valid.sum().double()
        B, T = y.shape
        layer_tokens += B * T
        n_batches += 1

        if diag is not None:
            L = len(diag["per_layer"])
            if n_layers == 0:
                n_layers = L
                n_lobes = len(diag["per_layer"][0]["per_lobe_execution_count"])
                open_layer = [0.0] * L
                active_layer = [0.0] * L
            for li, d in enumerate(diag["per_layer"]):
                for lj, c in enumerate(d["per_lobe_execution_count"]):
                    lobe_counts[(li, lj)] = lobe_counts.get((li, lj), 0) + int(c)
                for lj, c in enumerate(d["per_lobe_confidence_mean"]):
                    conf_sum[(li, lj)] = conf_sum.get((li, lj), 0.0) + float(c)
                for lj, mask in enumerate(d["per_lobe_winning_masks"]):
                    if mask is None:
                        continue
                    key = (li, lj)
                    if key not in freq_sum:
                        freq_sum[key] = torch.zeros(mask.shape[1], device=dev,
                                                    dtype=torch.float64)
                        freq_cnt[key] = 0
                    freq_sum[key] += mask.sum(0).double()
                    freq_cnt[key] += mask.shape[0]

            if model_name == "talk":
                g = torch.stack([d["talk_gate_map"] for d in diag["per_layer"]]).mean(0)
                gflat = g.reshape(-1)[valid].float()
                w = tok_nll[valid]
                om = gflat > 0.5
                open_nll += w[om].sum().double()
                open_tok += om.sum().double()
                closed_nll += w[~om].sum().double()
                closed_tok += (~om).sum().double()

                for li, d in enumerate(diag["per_layer"]):
                    open_layer[li] += float(d["talk_open_rate"])
                    active_layer[li] += float(d["talk_active_fraction"])
                    for lj, dv in enumerate(d["talk_diversity_per_lobe"]):
                        if dv is None:
                            continue
                        key = (li, lj)
                        div_sum[key] = (div_sum.get(key, torch.zeros(
                            (), device=dev, dtype=torch.float64)) + dv.double())
                        div_n[key] = div_n.get(key, 0) + 1

                if detailed:
                    losses.append(w.float())
                    gates.append(gflat)
                    margins.append(torch.stack(
                        [d["talk_margin_map"] for d in diag["per_layer"]]
                    ).mean(0).reshape(-1)[valid].float())
                    masses.append(torch.stack(
                        [d["talk_mass_map"] for d in diag["per_layer"]]
                    ).mean(0).reshape(-1)[valid].float())
                    rec_counts.append(torch.stack(
                        [d["talk_rec_count_map"] for d in diag["per_layer"]]
                    ).mean(0).reshape(-1)[valid].float())
                    gscores.append(torch.stack(
                        [d["talk_gate_score_map"] for d in diag["per_layer"]]
                    ).mean(0).reshape(-1)[valid].float())

                    for li, d in enumerate(diag["per_layer"]):
                        cur = d.get("talk_rec_idx_map")
                        if cur is None:
                            continue
                        cur = cur.reshape(-1, cur.shape[-1])[valid]
                        prev = prev_rec.get(li)
                        if prev is not None and prev.shape == cur.shape:
                            match_exact += (cur == prev).all(1).sum().double()
                            inter = (cur.unsqueeze(2) == prev.unsqueeze(1)).any(2)
                            match_overlap += (inter.sum(1).double()
                                              / max(1, cur.shape[1])).sum()
                            match_n += cur.shape[0]
                        prev_rec[li] = cur

        if n_batches >= max_batches:
            break

    parts, names = [], []

    def add(name: str, t: torch.Tensor) -> None:
        names.append(name)
        parts.append(t.double().reshape(1))

    add("loss", nll / ntok)
    add("ntok", ntok)
    add("open_nll", open_nll)
    add("open_tok", open_tok)
    add("closed_nll", closed_nll)
    add("closed_tok", closed_tok)

    if detailed and losses:
        add("corr", _pearson_t(torch.cat(losses), torch.cat(gates)))
    else:
        add("corr", torch.zeros((), device=dev, dtype=torch.float64))

    # Entropy / utilisation per lobe, plus k-WTA active fraction.
    ent_vals = []
    util_vals = []
    for key in sorted(freq_sum.keys()):
        f = freq_sum[key] / max(1, freq_cnt[key])
        tot = f.sum().clamp_min(1e-12)
        p = f / tot
        ent = -(p.clamp_min(1e-12).log() * p).sum() / math.log(max(2, f.numel()))
        util = f.mean()
        ent_vals.append(ent)
        util_vals.append(util)
        add(f"ent_L{key[0]}_{key[1]}", ent)
        add(f"util_L{key[0]}_{key[1]}", util)
    add("entropy_mean", (torch.stack(ent_vals).mean() if ent_vals else
                         torch.zeros((), device=dev, dtype=torch.float64)))
    add("util_mean", (torch.stack(util_vals).mean() if util_vals else
                      torch.zeros((), device=dev, dtype=torch.float64)))

    div_vals = []
    for key in sorted(div_sum):
        dv = div_sum[key] / max(1, div_n[key])
        div_vals.append(dv)
        add(f"div_L{key[0]}_{key[1]}", dv)
    add("diversity_mean", (torch.stack(div_vals).mean() if div_vals else
                           torch.zeros((), device=dev, dtype=torch.float64)))

    add("match_exact", match_exact / match_n.clamp_min(1))
    add("match_overlap", match_overlap / match_n.clamp_min(1))

    if detailed and margins:
        for nm, src in (("margin", margins), ("mass", masses),
                        ("gscore", gscores)):
            mean, p10, p50, p90 = _quant4(torch.cat(src))
            add(f"{nm}_mean", mean)
            add(f"{nm}_p10", p10)
            add(f"{nm}_p50", p50)
            add(f"{nm}_p90", p90)
        add("rec_count_mean", torch.cat(rec_counts).mean())
    else:
        for nm in ("margin", "mass", "gscore"):
            for q in ("mean", "p10", "p50", "p90"):
                add(f"{nm}_{q}", torch.zeros((), device=dev, dtype=torch.float64))
        add("rec_count_mean", torch.zeros((), device=dev, dtype=torch.float64))

    vals = torch.cat(parts).tolist()
    d = dict(zip(names, vals))

    loss = float(d["loss"])
    out = {
        "val_loss": loss,
        "val_ppl": math.exp(min(loss, 50.0)),
        "val_bpc": loss / math.log(2),
        "val_tokens": int(d["ntok"]),
        "batches": n_batches,
    }

    if n_layers:
        out["per_lobe_token_share"] = [
            [lobe_counts.get((li, lj), 0) / max(1, layer_tokens)
             for lj in range(n_lobes)] for li in range(n_layers)
        ]
        out["per_lobe_confidence"] = [
            [conf_sum.get((li, lj), 0.0) / max(1, n_batches)
             for lj in range(n_lobes)] for li in range(n_layers)
        ]
        out["per_lobe_entropy"] = [
            [float(d.get(f"ent_L{li}_{lj}", 0.0)) for lj in range(n_lobes)]
            for li in range(n_layers)
        ]
        out["per_lobe_utilisation"] = [
            [float(d.get(f"util_L{li}_{lj}", 0.0)) for lj in range(n_lobes)]
            for li in range(n_layers)
        ]
        out["routing_confidence_mean"] = float(
            np.mean(out["per_lobe_confidence"]))
        out["util_mean"] = float(d["util_mean"])
        out["entropy_mean"] = float(d["entropy_mean"])
        out["kwta_active_fraction"] = out["util_mean"]
        out["hebbian_stats"] = ([t.get_strength_stats()
                                 for t in model.hebbian_trackers]
                                if hasattr(model, "hebbian_trackers") else None)

    if model_name == "talk":
        out["gate_open_rate_per_layer"] = [v / max(1, n_batches)
                                           for v in open_layer]
        out["gate_open_rate_overall"] = float(np.mean(out["gate_open_rate_per_layer"]))
        out["active_fraction"] = float(np.mean(active_layer) / max(1, n_batches))
        out["recruit_diversity"] = float(d["diversity_mean"])
        out["per_lobe_diversity"] = [
            [float(d.get(f"div_L{li}_{lj}", 0.0)) for lj in range(n_lobes)]
            for li in range(n_layers)
        ]
        out["loss_gate_correlation"] = float(d["corr"])
        if float(d["open_tok"]) > 0:
            out["val_ppl_open_gate"] = math.exp(
                min(float(d["open_nll"]) / float(d["open_tok"]), 50.0))
        if float(d["closed_tok"]) > 0:
            out["val_ppl_closed_gate"] = math.exp(
                min(float(d["closed_nll"]) / float(d["closed_tok"]), 50.0))
        out["gate_open_token_fraction"] = float(d["open_tok"]) / max(1.0, float(d["ntok"]))
        out["margin_mean"] = float(d["margin_mean"])
        out["margin_p10"] = float(d["margin_p10"])
        out["margin_p50"] = float(d["margin_p50"])
        out["margin_p90"] = float(d["margin_p90"])
        out["mass_mean"] = float(d["mass_mean"])
        out["mass_p10"] = float(d["mass_p10"])
        out["mass_p50"] = float(d["mass_p50"])
        out["mass_p90"] = float(d["mass_p90"])
        out["gate_score_mean"] = float(d["gscore_mean"])
        out["gate_score_p10"] = float(d["gscore_p10"])
        out["gate_score_p50"] = float(d["gscore_p50"])
        out["gate_score_p90"] = float(d["gscore_p90"])
        out["recruited_count_mean"] = float(d["rec_count_mean"])
        out["recruit_set_match_prev_batch"] = float(d["match_exact"])
        out["recruit_set_overlap_prev_batch"] = float(d["match_overlap"])

    if model_name == "talk":
        for layer in model.layers:
            layer.lobe_layer.collect_rec_masks = False
    return out


# ---------------------------------------------------------------------
# Generation
# ---------------------------------------------------------------------
def _load_prompts(path: Path) -> list:
    lines = [ln.strip() for ln in path.read_text(encoding="utf-8").splitlines()]
    prompts = [ln for ln in lines if ln and not ln.startswith("#")]
    if len(prompts) != 8:
        raise SystemExit(f"expected 8 prompts in {path}, found {len(prompts)}")
    return prompts


@torch.no_grad()
def generate(model_name: str, model, tok: CharTokenizer, prompts: list,
             n_chars: int = 300, temperature: float = 0.8, top_k: int = 40,
             seed: int = 1234, greedy: bool = False):
    """Batched continuation. Right padding is safe: each row reads logits at
    its own last real position, and causal attention never sees the pads that
    follow it."""
    was_training = model.training
    model.eval()
    dev = "cuda"
    enc = [tok.encode(p) for p in prompts]
    lens = [len(e) for e in enc]
    n = len(enc)
    ids = torch.zeros(n, max(lens) + 8, dtype=torch.long, device=dev)
    for i, e in enumerate(enc):
        ids[i, :len(e)] = torch.tensor(e, device=dev)
    gen = torch.Generator(device=dev)
    gen.manual_seed(seed)
    rows = torch.arange(n, device=dev)
    dbg = os.environ.get("TALK_GEN_DEBUG")
    if dbg:
        print(f"[gen] ids={tuple(ids.shape)} lens={lens}", flush=True)
    open_steps = []
    rec_steps = []

    with torch.no_grad(), torch.autocast(device_type="cuda",
                                         dtype=torch.bfloat16):
        for _ in range(n_chars):
            if model_name == "dense":
                logits = model(ids)
                diag = None
            else:
                logits, diag = model(ids, update_hebbian=False)
            if dbg:
                torch.cuda.synchronize()
                print(f"[gen] fwd ok {tuple(ids.shape)}", flush=True)
            last = torch.tensor([l - 1 for l in lens], device=dev)
            cur = logits[rows, last].float()
            if greedy:
                nxt = cur.argmax(-1)
            else:
                topv, topi = (cur / temperature).topk(top_k, dim=-1)
                probs = F.softmax(topv, dim=-1)
                pick = torch.multinomial(probs, 1, generator=gen).squeeze(-1)
                nxt = topi.gather(-1, pick.unsqueeze(-1)).squeeze(-1)

            ids[rows, torch.tensor(lens, device=dev)] = nxt
            if dbg:
                torch.cuda.synchronize()
                print("[gen] write ok", flush=True)
            if model_name == "talk":
                go = torch.stack([d["talk_gate_map"][rows, last]
                                  for d in diag["per_layer"]]).mean(0)
                rc = torch.stack([d["talk_rec_count_map"][rows, last]
                                  for d in diag["per_layer"]]).mean(0)
                open_steps.append(go)
                rec_steps.append(rc)
            lens = [l + 1 for l in lens]
            if max(lens) >= ids.shape[1]:
                if ids.shape[1] >= 512:
                    break
                ids = torch.cat([ids, torch.zeros(n, 8, dtype=torch.long,
                                                  device=dev)], dim=1)

    texts = [tok.decode(ids[i, :lens[i]].tolist()) for i in range(n)]
    stats = None
    if model_name == "talk":
        o = torch.stack(open_steps).tolist()  # (n_chars, n)
        r = torch.stack(rec_steps).tolist()
        stats = {
            "open_rate": [[o[t][i] for t in range(len(o))] for i in range(n)],
            "rec_count": [[r[t][i] for t in range(len(r))] for i in range(n)],
        }
    if was_training:
        model.train()
    return texts, stats


def _write_samples(path: Path, header: str, prompts: list, texts: list,
                   stats: Optional[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    out = [header, ""]
    for i, (p, t) in enumerate(zip(prompts, texts), start=1):
        out.append(f"## prompt {i}")
        out.append(p)
        out.append("--- continuation ---")
        out.append(t)
        if stats is not None:
            o = stats["open_rate"][i - 1]
            r = stats["rec_count"][i - 1]
            out.append(f"gate_open_mean={np.mean(o):.4f} "
                       f"rec_count_mean={np.mean(r):.2f}")
        out.append("")
    path.write_text("\n".join(out), encoding="utf-8")


def run_generation(tag: str, step: int, args, model, tok, prompts, samples_dir: Path,
                   greedy: bool = False) -> None:
    st = _rng_state()
    t0 = time.time()
    try:
        texts, stats = generate(args.model, model, tok, prompts,
                                n_chars=args.gen_chars,
                                temperature=args.gen_temp, top_k=args.gen_topk,
                                seed=args.gen_seed, greedy=greedy)
    finally:
        _set_rng_state(st)
    header = (f"# model={args.model} step={step} "
              f"{'greedy' if greedy else f'temp={args.gen_temp} top_k={args.gen_topk} seed={args.gen_seed}'}"
              f" chars={args.gen_chars}")
    _write_samples(samples_dir / f"{tag}.txt", header, prompts, texts, stats)
    if stats is not None:
        (samples_dir / f"{tag}_talk.json").write_text(
            json.dumps(stats, indent=2), encoding="utf-8")
    print(f"[{args.run_name}] samples {tag} written "
          f"({time.time() - t0:.1f}s)", flush=True)


# ---------------------------------------------------------------------
# Main training
# ---------------------------------------------------------------------
def train(args) -> dict:
    cfg = build_config(args)
    set_seed(args.seed)
    if not torch.cuda.is_available():
        raise SystemExit("CUDA/HIP device not available — run preflight.py first.")

    RESULTS.mkdir(parents=True, exist_ok=True)
    run_root = RESULTS / args.run_name
    ckpt_dir = run_root / "ckpt"
    samples_dir = run_root / "samples"
    gpu_dir = run_root / "gpu"
    for p in (run_root, ckpt_dir, samples_dir, gpu_dir):
        p.mkdir(parents=True, exist_ok=True)
    res_path = RESULTS / f"{args.run_name}.json"
    gpu_path = gpu_dir / f"gpu_pid.jsonl"
    log_path = run_root / "log.jsonl"
    jsonl = open(log_path, "a" if args.resume else "w", encoding="utf-8", buffering=1)

    def emit(rec: dict) -> None:
        jsonl.write(json.dumps(rec) + "\n")

    prompts = _load_prompts(Path(args.prompts))

    texts, tok, train_loader, val_loader = build_loaders(
        cfg.data.data_fraction, cfg.data.seq_len, cfg.train.batch_size,
        cfg.data.val_fraction, args.seed, cfg.data.cache_dir, args.corpus)
    train_chars = sum(len(t) for t in texts)
    del texts
    cfg.model.vocab_size = tok.vocab_size
    (run_root / "vocab.json").write_text(json.dumps(tok.to_dict()))
    cfg.save(run_root / "config.yaml")

    talk_cfg = TalkConfig(r=args.talk_r, recruit_ratio=args.talk_m_ratio,
                          lambda_open=args.lambda_open,
                          lambda_distill=args.lambda_distill,
                          gate_init_std=args.gate_init_std,
                          rate_target=args.gate_target)
    cfg.talk = talk_cfg
    model = build_model(cfg, talk_cfg).cuda()

    resume_payload = None
    start_step = 0
    if args.resume:
        ckpt = (Path(args.resume) if args.resume != "latest"
                else _find_latest(ckpt_dir))
        if ckpt is None or not Path(ckpt).exists():
            raise SystemExit(f"--resume given but no checkpoint found in {ckpt_dir}")
        resume_payload = torch.load(ckpt, map_location="cuda", weights_only=False)
        _rebuild_to_counts(model, resume_payload.get("lobe_neuron_counts"))
        model.load_state_dict(resume_payload["model_state_dict"])
        start_step = int(resume_payload.get("step", 0))
        print(f"[{args.run_name}] RESUMED from {Path(ckpt).name} at step {start_step}",
              flush=True)

    gate_init = None
    if args.model == "talk" and resume_payload is None:
        cal_x = next(iter(train_loader))[0]
        gate_init = calibrate_talk_gate(model, cal_x, "cuda")
        print(f"gate init open rate {[round(v, 3) for v in gate_init['before']]}"
              f" -> {[round(v, 3) for v in gate_init['after']]}", flush=True)

    optimizer = build_optimizer(model, cfg)
    scheduler = build_scheduler(optimizer, args.steps, cfg.train.warmup_steps)

    growth_monitor = None
    if cfg.model_type != "dense" and cfg.growth.enabled:
        growth_monitor = model.attach_growth_monitor()

    if resume_payload is not None:
        if resume_payload.get("optimizer_state_dict"):
            optimizer.load_state_dict(resume_payload["optimizer_state_dict"])
        if resume_payload.get("scheduler_state_dict"):
            scheduler.load_state_dict(resume_payload["scheduler_state_dict"])
        _restore_gm(growth_monitor, resume_payload.get("growth_monitor"))
        _set_rng_state(resume_payload.get("rng"))
        emit({"event": "resume", "step": start_step,
              "checkpoint": str(ckpt)})

    params = count_parameters(model)
    flops = flops_table(cfg)
    tokens_per_step = cfg.train.batch_size * cfg.data.seq_len

    setup = {
        "model": args.model,
        "seed": args.seed,
        "device": torch.cuda.get_device_name(0),
        "torch": torch.__version__,
        "hip": torch.version.hip,
        "precision": "bf16 autocast, fp32 master weights",
        "dataset": (f"local corpus {args.corpus}"
                    if getattr(args, "corpus", None)
                    else f"roneneldan/TinyStories train[:{cfg.data.data_fraction*100:g}%]"),
        "tokenizer": f"char-level, vocab={tok.vocab_size}",
        "train_stories_chars": train_chars,
        "seq_len": cfg.data.seq_len,
        "batch_size": cfg.train.batch_size,
        "steps": args.steps,
        "tokens_total": args.steps * tokens_per_step,
        "optimizer": "AdamW betas=(0.9,0.95) eps=1e-8",
        "lr": args.lr, "weight_decay": cfg.train.weight_decay,
        "warmup_steps": cfg.train.warmup_steps, "schedule": "cosine",
        "grad_clip": cfg.train.grad_clip, "dropout": cfg.model.dropout,
        "num_layers": cfg.model.num_layers, "hidden_dim": cfg.model.hidden_dim,
        "num_heads": cfg.model.num_heads, "ffn_dim": cfg.model.ffn_dim,
        "lobes_per_layer": cfg.model.lobes_per_layer,
        "top_k_lobes": cfg.model.top_k_lobes,
        "kwta_ratio": cfg.model.kwta_ratio,
        "val_fraction": cfg.data.val_fraction,
        "eval_interval": args.eval_interval,
        "eval_batches": args.eval_batches,
        "eval_metric": "mean char cross-entropy -> perplexity (exp)",
        "growth": ({"enabled": True,
                    "check_interval": cfg.growth.check_interval_steps,
                    "rolling_window": cfg.growth.rolling_window,
                    "thresholds": [cfg.growth.confidence_threshold,
                                   cfg.growth.utilization_threshold,
                                   cfg.growth.entropy_threshold],
                    "persistence_ratio": cfg.growth.persistence_ratio,
                    "neurons_per_growth": cfg.growth.neurons_per_growth,
                    "cooldown": cfg.growth.minimum_growth_interval}
                   if growth_monitor is not None else {"enabled": False}),
        "hebbian": {"enabled": cfg.hebbian.enabled,
                    "increment": cfg.hebbian.increment,
                    "decay_rate": cfg.hebbian.decay_rate},
        "params": params,
        "flops_per_token": flops,
        "talk": (talk_cfg.__dict__ if args.model == "talk" else None),
        "gate_init_open_rate": gate_init,
        "ckpt_interval": args.ckpt_interval,
        "gen_every": args.gen_every,
        "gen_chars": args.gen_chars,
        "gen_temp": args.gen_temp,
        "gen_top_k": args.gen_topk,
        "gen_seed": args.gen_seed,
        "prompts": str(Path(args.prompts)),
        "results_root": str(RESULTS),
    }

    print("=" * 82)
    print(f"RUN {args.run_name}  model={args.model} seed={args.seed}")
    for k in ("device", "precision", "dataset", "tokenizer", "seq_len",
              "batch_size", "steps", "tokens_total", "optimizer", "lr",
              "weight_decay", "warmup_steps", "grad_clip", "dropout",
              "ffn_dim", "lobes_per_layer", "top_k_lobes", "kwta_ratio",
              "val_fraction", "eval_interval", "eval_batches", "params",
              "flops_per_token", "growth", "hebbian", "ckpt_interval",
              "gen_every", "gen_chars", "gen_temp", "gen_top_k", "gen_seed"):
        print(f"  {k}: {setup[k]}")
    if args.model == "talk":
        print(f"  talk: {setup['talk']}")
    print(f"  conflicts resolved: steps={args.steps:,} "
          f"({args.steps * tokens_per_step / 1e6:.0f}M tokens); "
          "hebbian decay=0.01 (paper's corrected rate; YAML says 0.001); "
          f"eval subset={args.eval_batches} batches; num_workers=0; "
          "precision=bf16.")
    print("=" * 82, flush=True)
    if resume_payload is None:
        emit({"event": "init", "step": 0, "setup": setup})

    def save_results(complete: bool, extra: dict) -> dict:
        rec = {"run": args.run_name, "model": args.model, "seed": args.seed,
               "complete": complete, "setup": setup, **extra}
        tmp = RESULTS / f"{args.run_name}.json.tmp"
        tmp.write_text(json.dumps(rec, indent=2))
        os.replace(tmp, res_path)
        return rec

    if resume_payload is not None:
        eval_curve = resume_payload.get("eval_curve", [])
        growth_events = resume_payload.get("growth_events", [])
        best = resume_payload.get("best", {"val_loss": float("inf"), "step": 0})
        nonfinite = resume_payload.get("nonfinite", {"loss": 0, "grad": 0})
        timers = resume_payload.get("timers", {"train_time_s": 0.0,
                                               "train_steps": 0,
                                               "gen_time_s": 0.0})
    else:
        eval_curve = []
        growth_events = []
        best = {"val_loss": float("inf"), "step": 0}
        nonfinite = {"loss": 0, "grad": 0}
        timers = {"train_time_s": 0.0, "train_steps": 0, "gen_time_s": 0.0}

    def flops_block(open_rate: float) -> dict:
        table = flops_table(cfg, open_rate)
        dense_ref = table["dense"]
        return {
            "dense": dense_ref,
            "hsnnm": table["hsnnm"],
            "talk_closed": flops_table(cfg, 0.0)["talk"],
            "talk_open": flops_table(cfg, 1.0)["talk"],
            "talk_at_measured_open_rate": table["talk"],
            "open_rate_used": open_rate,
            "talk_reduction_vs_dense": 1.0 - table["talk"] / dense_ref,
        }

    def summary_extra(m: dict) -> dict:
        return {
            "final_val_loss": m["val_loss"],
            "final_val_ppl": m["val_ppl"],
            "final_val_bpc": m.get("val_bpc"),
            "best_val_loss": best["val_loss"],
            "best_step": best["step"],
            "eval_curve": eval_curve,
            "growth_events": growth_events,
            "gate": {k: m[k] for k in
                     ("gate_open_rate_overall", "gate_open_rate_per_layer",
                      "active_fraction", "recruit_diversity",
                      "loss_gate_correlation", "val_ppl_open_gate",
                      "val_ppl_closed_gate", "recruit_set_match_prev_batch",
                      "recruited_count_mean") if k in m},
            "flops": flops_block(m.get("gate_open_rate_overall", 0.0)),
            "tokens_seen": step_now[0] * tokens_per_step,
            "wall_time_s": round(time.time() - t_start, 1),
            "train_time_s": round(timers["train_time_s"], 1),
            "nonfinite": nonfinite,
        }

    step_now = [start_step]
    t_start = time.time()
    torch.cuda.reset_peak_memory_stats()
    if resume_payload is None:
        save_results(False, {"eval_curve": [], "growth_events": [], "gate": {},
                             "flops": flops_block(0.0), "tokens_seen": 0,
                             "wall_time_s": 0.0, "train_time_s": 0.0,
                             "nonfinite": nonfinite})

    # External GPU sampler (separate process, Windows counters).
    sampler = None
    try:
        if not os.environ.get("TALK_NO_SAMPLER"):
            sampler = subprocess.Popen(
                [sys.executable, str(HERE / "gpu_sampler.py"),
                 "--pid", str(os.getpid()), "--out", str(gpu_path),
                 "--interval", "2"],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception as e:  # noqa: BLE001
        print(f"(gpu sampler unavailable: {type(e).__name__}: {e})", flush=True)

    def do_eval(step: int) -> dict:
        m = evaluate(args.model, model, val_loader, args.eval_batches,
                     detailed=True)
        m["step"] = step
        m["flops"] = flops_block(m.get("gate_open_rate_overall", 0.0))
        eval_curve.append(m)
        emit({"event": "eval", **m})
        if m["val_loss"] < best["val_loss"]:
            best.update(val_loss=m["val_loss"], step=step)
        save_results(False, summary_extra(m))
        line = (f"[{args.run_name}] eval step {step:>6} val_loss {m['val_loss']:.4f} "
                f"ppl {m['val_ppl']:.2f} bpc {m['val_bpc']:.4f}")
        if "gate_open_rate_overall" in m:
            line += (f" | open {m['gate_open_rate_overall']:.3f} "
                     f"active {m['active_fraction']:.3f} "
                     f"div {m['recruit_diversity']:.3f} "
                     f"corr {m['loss_gate_correlation']:+.3f}")
        print(line, flush=True)
        model.train()
        return m

    try:
        train_iter = iter(train_loader)
        if start_step:
            skip = start_step % max(1, len(train_loader))
            for _ in range(skip):
                try:
                    next(train_iter)
                except StopIteration:
                    train_iter = iter(train_loader)
            print(f"  (data iterator fast-forwarded {skip} batches)", flush=True)

        step = start_step
        ce_acc = torch.zeros((), device="cuda")
        loss_acc = torch.zeros((), device="cuda")
        gn_acc = torch.zeros((), device="cuda")
        badgrad_acc = torch.zeros((), device="cuda", dtype=torch.int32)
        openp_acc = torch.zeros((), device="cuda")
        dist_acc = torch.zeros((), device="cuda")
        or_acc = 0.0
        n_acc = 0
        interval_time = 0.0
        low_open_streak = 0
        stop_early = False
        stop_reason = None
        model.train()

        while step < args.steps:
            try:
                x, y = next(train_iter)
            except StopIteration:
                train_iter = iter(train_loader)
                continue
            x = x.cuda(non_blocking=True)
            y = y.cuda(non_blocking=True)
            t0 = time.time()

            with torch.autocast(device_type="cuda", dtype=torch.bfloat16):
                if args.model == "dense":
                    logits = model(x)
                    diag = None
                else:
                    logits, diag = model(x)
                ce = lm_loss(logits, y)
                loss = ce
                open_pen = distill = None
                if args.model == "talk":
                    n_layers = len(diag["per_layer"])
                    open_pen = sum(d["talk_open_penalty"]
                                   for d in diag["per_layer"]) / n_layers
                    distill = sum(d["talk_distill_loss"]
                                  for d in diag["per_layer"]) / n_layers
                    loss = ce + args.lambda_open * open_pen \
                        + args.lambda_distill * distill

            if not torch.isfinite(loss):
                nonfinite["loss"] += 1
                log.warning("non-finite loss at step %d — skipping update", step)
                optimizer.zero_grad(set_to_none=True)
                continue

            loss.backward()
            gn = torch.nn.utils.clip_grad_norm_(model.parameters(),
                                                cfg.train.grad_clip)
            optimizer.step()
            scheduler.step()
            optimizer.zero_grad(set_to_none=True)
            step += 1
            step_now[0] = step

            dt = time.time() - t0
            interval_time += dt
            timers["train_time_s"] += dt
            timers["train_steps"] += 1
            ce_acc += ce.detach().float()
            loss_acc += loss.detach().float()
            gn_acc += torch.nan_to_num(gn.detach().float(), nan=0.0,
                                       posinf=0.0, neginf=0.0)
            badgrad_acc += (~torch.isfinite(gn)).to(torch.int32)
            if open_pen is not None:
                openp_acc += open_pen.detach().float()
                dist_acc += distill.detach().float()
                or_acc += (sum(d["talk_open_rate"] for d in diag["per_layer"])
                           / len(diag["per_layer"]))
            n_acc += 1

            if step % cfg.train.log_interval_steps == 0:
                vals = torch.stack([ce_acc, loss_acc, gn_acc,
                                    badgrad_acc.float(), openp_acc,
                                    dist_acc]).tolist()
                n = max(1, n_acc)
                ce_m, loss_m, gn_m, badg_m, open_m, dist_m = vals
                avg_step = timers["train_time_s"] / max(1, timers["train_steps"])
                eta = (args.steps - step) * avg_step
                util = _last_gpu_util(gpu_path)
                rec = {
                    "event": "train_step", "step": step,
                    "ce": ce_m / n, "loss": loss_m / n, "ppl": math.exp(min(ce_m / n, 50)),
                    "lr": scheduler.get_last_lr()[0],
                    "grad_norm_preclip": gn_m / n,
                    "nonfinite_grad_in_interval": int(badg_m),
                    "tokens_per_s": tokens_per_step * n / max(1e-9, interval_time),
                    "step_time_s": interval_time / n,
                    "eta_s": eta,
                    "elapsed_s": time.time() - t_start,
                    "gpu_mem_mb": torch.cuda.memory_allocated() / 1e6,
                    "gpu_peak_mb": torch.cuda.max_memory_allocated() / 1e6,
                    "gpu_util": util,
                    "params": count_parameters(model),
                }
                if args.model == "talk":
                    rec["ce_term"] = ce_m / n
                    rec["open_penalty_term"] = open_m / n
                    rec["distill_term"] = dist_m / n
                    rec["open_rate_train"] = or_acc / n
                emit(rec)
                line = (f"[{args.run_name}] step {step}/{args.steps} | "
                        f"loss {loss_m/n:.4f} | ")
                if eval_curve:
                    line += f"val {eval_curve[-1]['val_ppl']:.2f} | "
                else:
                    line += "val - | "
                line += (f"{rec['tokens_per_s']:.0f} tok/s | "
                         f"ETA {eta/60:.1f}m")
                if args.model == "talk":
                    line += f" | open {or_acc / n:.3f}"
                if util is not None:
                    line += f" | util {util:.0f}%"
                print(line, flush=True)
                ce_acc.zero_()
                loss_acc.zero_()
                gn_acc.zero_()
                badgrad_acc.zero_()
                openp_acc.zero_()
                dist_acc.zero_()
                or_acc = 0.0
                n_acc = 0
                interval_time = 0.0

            if growth_monitor is not None:
                model.push_growth_signals(diag, growth_monitor)
                growth_monitor.advance_step()
                if step % cfg.growth.check_interval_steps == 0:
                    for li in range(growth_monitor.num_layers):
                        for lj in range(growth_monitor.num_lobes_per_layer):
                            should, detail = growth_monitor.check_saturation(li, lj)
                            if not should:
                                continue
                            lobe_layer = model.layers[li].lobe_layer
                            lobe = lobe_layer.lobes[lj]
                            tag = f"growth_L{li}_l{lj}_step{step}"
                            pre_path = save_pre_update_checkpoint(
                                ckpt_dir, model, optimizer, tok, cfg, step, 0, tag)
                            _keep_latest_rollbacks(ckpt_dir, li, lj, keep=2)
                            before = evaluate(args.model, model, val_loader, 1,
                                              detailed=False)["val_loss"]
                            model.train()
                            old_A = getattr(lobe, "A", None)
                            old_B = getattr(lobe, "B", None)
                            ev = growth_monitor.grow_lobe(
                                li, lj,
                                hebbian_tracker=(model.hebbian_trackers[li]
                                                 if hasattr(model, "hebbian_trackers")
                                                 else None),
                                optimizer=optimizer)
                            if args.model == "talk":
                                resize_talk_optimizer_state(
                                    optimizer, lobe, old_A, old_B, ev["n_new"])
                            after = evaluate(args.model, model, val_loader, 1,
                                             detailed=False)["val_loss"]
                            model.train()
                            ev["saturation_detail"] = detail
                            ev["pre_update_checkpoint"] = str(pre_path)
                            ev["val_loss_before_1batch"] = before
                            ev["val_loss_after_1batch"] = after
                            growth_events.append(ev)
                            emit({"event": "growth", **ev})
                            print(f"GROWTH step {step} L{li}l{lj} "
                                  f"{ev['old_ffn_dim']}->{ev['new_ffn_dim']} "
                                  f"loss {before:.4f}->{after:.4f}", flush=True)

            if step % args.ckpt_interval == 0:
                save_ckpt(ckpt_dir / f"step_{step:06d}.pt", model, optimizer,
                          scheduler, tok, cfg, args, step, best, eval_curve,
                          growth_events, growth_monitor, nonfinite, timers)
                _prune_ckpts(ckpt_dir, keep=3)
                emit({"event": "ckpt", "step": step,
                      "file": f"step_{step:06d}.pt"})

            if step % args.eval_interval == 0:
                m = do_eval(step)
                if args.model == "talk" and step >= args.talk_stop_after:
                    if m["gate_open_rate_overall"] < args.talk_stop_threshold:
                        low_open_streak += 1
                    else:
                        low_open_streak = 0
                    if low_open_streak >= args.talk_stop_consecutive:
                        stop_early = True
                        stop_reason = (
                            f"gate open rate < {args.talk_stop_threshold:.1%} "
                            f"for {low_open_streak} consecutive evals after "
                            f"step {args.talk_stop_after}")
                        print(f"!!! TALK STOP RULE: {stop_reason} — "
                              f"stopping run, JSON kept.", flush=True)
                        break

            if args.gen_every and step % args.gen_every == 0:
                g_t0 = time.time()
                run_generation(f"step_{step:06d}", step, args, model, tok,
                               prompts, samples_dir)
                timers["gen_time_s"] += time.time() - g_t0
                emit({"event": "gen", "step": step, "kind": "sample"})

            if args.dry_run and step >= 3:
                break

        if eval_curve and eval_curve[-1].get("step") != step:
            do_eval(step)

        if not stop_early:
            # Final generation: sampled + greedy.
            g_t0 = time.time()
            run_generation("final_sampled", step, args, model, tok,
                           prompts, samples_dir)
            run_generation("final_greedy", step, args, model, tok,
                           prompts, samples_dir, greedy=True)
            timers["gen_time_s"] += time.time() - g_t0
            emit({"event": "gen", "step": step, "kind": "final"})

            print(f"[{args.run_name}] full validation "
                  f"({len(val_loader)} batches)...", flush=True)
            full = evaluate(args.model, model, val_loader, 10 ** 9,
                            detailed=False)
            model.train()
            emit({"event": "eval_full", "step": step, **full})
            save_ckpt(ckpt_dir / f"step_{step:06d}.pt", model, optimizer,
                      scheduler, tok, cfg, args, step, best, eval_curve,
                      growth_events, growth_monitor, nonfinite, timers)
            _prune_ckpts(ckpt_dir, keep=3)
        else:
            full = None

        total_s = time.time() - t_start
        subset = eval_curve[-1]
        extra = {
            "final_val_loss": subset["val_loss"],
            "final_val_ppl": subset["val_ppl"],
            "final_val_bpc": subset["val_bpc"],
            "final_val_loss_subset": subset["val_loss"],
            "final_val_ppl_subset": subset["val_ppl"],
            "final_val_bpc_subset": subset["val_bpc"],
            "final_val_loss_full": (full["val_loss"] if full else None),
            "final_val_ppl_full": (full["val_ppl"] if full else None),
            "final_val_bpc_full": (full["val_bpc"] if full else None),
            "full_val_tokens": (full["val_tokens"] if full else None),
            "best_val_loss": best["val_loss"], "best_step": best["step"],
            "eval_curve": eval_curve, "growth_events": growth_events,
            "gate": {k: subset[k] for k in
                     ("gate_open_rate_overall", "gate_open_rate_per_layer",
                      "active_fraction", "recruit_diversity",
                      "loss_gate_correlation", "val_ppl_open_gate",
                      "val_ppl_closed_gate", "recruit_set_match_prev_batch",
                      "recruited_count_mean") if k in subset},
            "gate_over_training": [[m["step"], m.get("gate_open_rate_overall")]
                                   for m in eval_curve
                                   if "gate_open_rate_overall" in m],
            "flops": flops_block(subset.get("gate_open_rate_overall", 0.0)),
            "tokens_seen": step * tokens_per_step,
            "params_final": count_parameters(model),
            "wall_time_s": round(total_s, 1),
            "train_time_s": round(timers["train_time_s"], 1),
            "gen_time_s": round(timers["gen_time_s"], 1),
            "nonfinite": nonfinite,
            "stopped_early": stop_early,
            "stop_reason": stop_reason,
            "final_step": step,
        }
        rec = save_results(True, extra)
        emit({"event": "done", "step": step, "wall_time_s": round(total_s, 1),
              "stopped_early": stop_early})
    finally:
        if sampler is not None:
            sampler.terminate()
            try:
                sampler.wait(timeout=5)
            except Exception:  # noqa: BLE001
                pass
        jsonl.close()

    print("-" * 82)
    print(f"DONE {args.run_name}: subset ppl {rec['final_val_ppl_subset']:.2f}, "
          f"full ppl {rec['final_val_ppl_full']}, "
          f"train {rec['train_time_s']/60:.1f} min, "
          f"wall {rec['wall_time_s']/60:.1f} min")
    if rec.get("gate"):
        g = rec["gate"]
        print(f"  gate open {g['gate_open_rate_overall']:.3f} "
              f"active {g['active_fraction']:.3f} "
              f"diversity {g['recruit_diversity']:.3f} "
              f"corr {g['loss_gate_correlation']:+.3f}")
    if stop_early:
        print(f"  STOPPED EARLY: {stop_reason}")
    print(f"  results: {res_path}")
    return rec


def main() -> None:
    if os.environ.get("TALK_FAULTHANDLER"):
        import faulthandler
        faulthandler.dump_traceback_later(45, repeat=True)
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--model", choices=["dense", "hsnnm", "talk"], required=True)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--steps", type=int, default=DEFAULTS["steps"])
    ap.add_argument("--batch-size", type=int, default=DEFAULTS["batch_size"])
    ap.add_argument("--seq-len", type=int, default=DEFAULTS["seq_len"])
    ap.add_argument("--lr", type=float, default=DEFAULTS["lr"])
    ap.add_argument("--data-fraction", type=float, default=DEFAULTS["data_fraction"])
    ap.add_argument("--corpus", default=None)
    ap.add_argument("--val-fraction", type=float, default=DEFAULTS["val_fraction"])
    ap.add_argument("--eval-interval", type=int, default=DEFAULTS["eval_interval"])
    ap.add_argument("--eval-batches", type=int, default=DEFAULTS["eval_batches"])
    ap.add_argument("--ckpt-interval", type=int, default=DEFAULTS["ckpt_interval"])
    ap.add_argument("--talk-r", type=int, default=16)
    ap.add_argument("--talk-m-ratio", type=float, default=0.05)
    ap.add_argument("--lambda-open", type=float, default=0.01)
    ap.add_argument("--lambda-distill", type=float, default=0.1)
    ap.add_argument("--gate-target", type=float, default=0.5)
    ap.add_argument("--gate-init-std", type=float, default=0.01)
    ap.add_argument("--talk-stop-after", type=int, default=1500)
    ap.add_argument("--talk-stop-threshold", type=float, default=0.02)
    ap.add_argument("--talk-stop-consecutive", type=int, default=3)
    ap.add_argument("--gen-every", type=int, default=1000)
    ap.add_argument("--gen-chars", type=int, default=300)
    ap.add_argument("--gen-temp", type=float, default=0.8)
    ap.add_argument("--gen-topk", type=int, default=40)
    ap.add_argument("--gen-seed", type=int, default=1234)
    ap.add_argument("--prompts", default=str(HERE / "prompts.txt"))
    ap.add_argument("--no-growth", action="store_true")
    ap.add_argument("--no-hebbian", action="store_true")
    ap.add_argument("--run-name", default=None)
    ap.add_argument("--resume", nargs="?", const="latest", default=None)
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--smoke", action="store_true")
    args = ap.parse_args()

    if args.smoke:
        args.steps = min(args.steps, 40)
        args.data_fraction = min(args.data_fraction, 0.01)
        args.eval_interval = min(args.eval_interval, 20)
        args.eval_batches = min(args.eval_batches, 5)
        args.ckpt_interval = min(args.ckpt_interval, 20)
        args.gen_every = 0
    if args.run_name is None:
        args.run_name = f"{args.model}_s{args.seed}" + ("_smoke" if args.smoke else "")

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
    )
    train(args)


if __name__ == "__main__":
    main()
