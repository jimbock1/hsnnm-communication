# run_all.ps1 — the five comparison runs, sequentially, skipping completed ones.
#
#   .\run_all.ps1
#
# A run counts as complete only if results/<run>.json exists with
# "complete": true. Interrupted/partial runs are retried from scratch.

$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

$py = "python"
if (-not (Test-Path $py)) {
    throw "Python venv not found at $py — install ROCm torch first (see README)."
}

$runs = @(
    @{ model = "dense"; seed = 0 },
    @{ model = "hsnnm"; seed = 0 },
    @{ model = "talk";  seed = 0 },
    @{ model = "talk";  seed = 1 },
    @{ model = "talk";  seed = 2 }
)

foreach ($r in $runs) {
    $name = "$($r.model)_s$($r.seed)"
    $file = Join-Path $PSScriptRoot "results\$name.json"
    if (Test-Path $file) {
        try {
            $j = Get-Content $file -Raw | ConvertFrom-Json
            if ($j.complete -eq $true) {
                Write-Host "[skip] $name already complete" -ForegroundColor DarkGray
                continue
            }
        } catch {
            Write-Host "[warn] could not read $file — rerunning $name" -ForegroundColor Yellow
        }
    }
    Write-Host "=== [run] $name ===" -ForegroundColor Cyan
    & $py train.py --model $r.model --seed $r.seed --gate-init-std 1.0
    if ($LASTEXITCODE -ne 0) { throw "run $name failed (exit $LASTEXITCODE)" }
}

Write-Host ""
& $py summarize.py
