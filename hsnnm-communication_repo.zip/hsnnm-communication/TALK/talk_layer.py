"""
talk_layer.py — TALK layer (sidecar; does not modify HSNNM).

TALK = HSNNM + a per-layer reliability gate + within-lobe recruitment.
Reference implementation per TALK brief section 3, plain PyTorch, no custom
kernels. The HSNNM path is untouched; this module subclasses Lobe/LobeLayer.

Definitions per token, for its routed lobe l (N neurons, width d):
  h        = GELU(x W1_l) * (1 + strength)      (HSNNM's pre-k-WTA activation)
  win_mask = HSNNM k-WTA mask (top-k by |h|)
  y_base   = W2_l (h * win_mask)                (must equal HSNNM exactly)
  gate     = sigmoid(-(w1*margin + w2*mass + b) / T)
  z        = (h * win_mask) A_l
  scores   = z B_l, winners set to -inf
  rec_mask = hard top-m of scores
  y_rec    = W2_l (h * sigmoid(scores) * rec_mask)
  y        = y_base + g * y_rec,  g straight-through hard gate
Losses: LM + lambda_open * mean(p) + lambda_distill * MSE(y, W2_l(h).detach())
"""
from __future__ import annotations

import math
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F

HSNNM_DIR = Path(__file__).resolve().parent.parent / "HSNNM"
if str(HSNNM_DIR) not in sys.path:
    sys.path.insert(0, str(HSNNM_DIR))

from model.lobe import Lobe, LobeLayer, kwta_topk_mask  # noqa: E402


@dataclass
class TalkConfig:
    r: int = 16
    recruit_ratio: float = 0.05       # m = ceil(N * recruit_ratio)
    lambda_open: float = 0.01
    lambda_distill: float = 0.1
    gate_temperature: float = 1.0
    gate_init_std: float = 0.01
    gate_per_layer: bool = True       # brief: 3 params per layer, shared by lobes
    rate_target: float = 0.5          # two-sided target for the mean gate prob


class TalkGate(nn.Module):
    """Three learned scalars per layer: w1*margin + w2*mass + b."""

    def __init__(self, temperature: float = 1.0, init_std: float = 0.01):
        super().__init__()
        self.w1 = nn.Parameter(torch.randn(()) * init_std)
        self.w2 = nn.Parameter(torch.randn(()) * init_std)
        self.b = nn.Parameter(torch.zeros(()))
        self.temperature = temperature

    def score(self, margin: torch.Tensor, mass: torch.Tensor) -> torch.Tensor:
        # Standardize the inputs per call: raw margin is ~1e-2 while mass is
        # ~5e-1, so unnormalized inputs leave the gate unable to separate
        # tokens and it degenerates into a global on/off switch.
        m = margin.float()
        ms = mass.float()
        m = (m - m.mean()) / m.std().clamp_min(1e-6)
        ms = (ms - ms.mean()) / ms.std().clamp_min(1e-6)
        return self.w1 * m + self.w2 * ms + self.b

    def forward(self, margin: torch.Tensor, mass: torch.Tensor) -> torch.Tensor:
        return torch.sigmoid(-self.score(margin, mass) / self.temperature)


class TalkLobe(Lobe):
    """Lobe + per-lobe low-rank recruitment maps A (N x r), B (r x N)."""

    def __init__(
        self,
        hidden_dim: int,
        ffn_dim: int,
        kwta_ratio: float = 0.2,
        use_kwta: bool = True,
        r: int = 16,
        recruit_ratio: float = 0.05,
    ):
        super().__init__(hidden_dim, ffn_dim, kwta_ratio, use_kwta=use_kwta)
        self.r = int(r)
        self.recruit_ratio = float(recruit_ratio)
        self.recruit_m = max(1, int(math.ceil(self.ffn_dim * self.recruit_ratio)))
        self.A = nn.Parameter(torch.randn(self.ffn_dim, self.r) * 0.02)
        self.B = nn.Parameter(torch.randn(self.r, self.ffn_dim) * 0.02)

    def _recruit_count(self) -> int:
        non_winners = max(1, self.ffn_dim - self.kwta_k)
        return max(1, min(self.recruit_m, non_winners))

    def talk_forward(self, x: torch.Tensor) -> dict:
        """x: (n, hidden_dim) -> dict of TALK outputs for n tokens."""
        self.last_executed = True
        h = F.gelu(self.fc1(x)) * (1.0 + self.strength)          # (n, N)

        if self.use_kwta:
            win_mask = kwta_topk_mask(h, self.kwta_k)            # (n, N) bool
        else:
            win_mask = torch.ones_like(h, dtype=torch.bool)

        base_in = h * win_mask.to(h.dtype)
        y_base = self.fc2(base_in)                                # (n, d)

        # Cheap reliability signals on magnitudes (detached; no gradient path).
        with torch.no_grad():
            mag = h.float().abs()
            k = min(self.kwta_k if self.use_kwta else self.ffn_dim - 1,
                    self.ffn_dim - 1)
            k = max(1, k)
            topv = mag.topk(k + 1, dim=-1).values                 # (n, k+1)
            hk = topv[..., -2]
            hk1 = topv[..., -1]
            eps = 1e-6
            margin = (hk - hk1) / (hk + eps)
            mass = mag.topk(k, dim=-1).values.sum(-1) / mag.sum(-1).clamp_min(eps)

        z = base_in @ self.A                                     # (n, r)
        scores = z @ self.B                                      # (n, N)
        scores = scores.masked_fill(win_mask, float("-inf"))
        m = self._recruit_count()
        topm = scores.topk(m, dim=-1).indices
        rec_mask = torch.zeros_like(scores, dtype=torch.bool)
        rec_mask.scatter_(-1, topm, True)
        rec_mask &= ~win_mask                                    # never recruit winners

        w_rec = torch.sigmoid(scores) * rec_mask.to(scores.dtype)
        y_rec = self.fc2(h * w_rec)                              # (n, d)

        dense = self.fc2(h) if self.training else None

        return {
            "y_base": y_base,
            "y_rec": y_rec,
            "dense": dense,
            "margin": margin,
            "mass": mass,
            "win_mask": win_mask,
            "rec_mask": rec_mask,
            "rec_idx": topm,
            "scores": scores,
        }

    def grow_neurons(self, n_new: int, donor_strength_idx: int = 0,
                     noise_scale: float = 0.01) -> None:
        """Grow fc1/fc2/strength via HSNNM, then resize A/B consistently.

        A/B become NEW Parameter objects (like fc1/fc2): mutating `.data` of a
        Parameter that already has optimizer/autograd history leaves stale
        shape metadata and breaks the next backward. The caller must pass the
        old A/B to `resize_talk_optimizer_state` to move Adam moments over.
        """
        if n_new <= 0:
            return
        old_A = self.A.detach().clone()
        old_B = self.B.detach().clone()
        device, dtype = self.A.device, self.A.dtype
        donor = max(0, min(int(donor_strength_idx), self.ffn_dim - 1))

        super().grow_neurons(n_new, donor, noise_scale)
        # A: append rows (donor + noise); B: append columns (donor + noise).
        new_A = old_A[donor:donor + 1] + torch.randn(
            n_new, self.r, device=device, dtype=dtype) * noise_scale
        new_B = old_B[:, donor:donor + 1] + torch.randn(
            self.r, n_new, device=device, dtype=dtype) * noise_scale
        self.A = nn.Parameter(torch.cat([old_A, new_A], dim=0))
        self.B = nn.Parameter(torch.cat([old_B, new_B], dim=1))
        self.recruit_m = max(1, int(math.ceil(self.ffn_dim * self.recruit_ratio)))


class TalkLobeLayer(LobeLayer):
    """HSNNM LobeLayer + TALK gate and recruitment accumulation."""

    def __init__(
        self,
        hidden_dim: int,
        ffn_dim: int,
        num_lobes: int,
        top_k: int,
        kwta_ratio: float,
        use_kwta: bool = True,
        routing_mode: str = "learned",
        talk: TalkConfig | None = None,
    ):
        super().__init__(hidden_dim, ffn_dim, num_lobes, top_k, kwta_ratio,
                         use_kwta=use_kwta, routing_mode=routing_mode)
        self.talk = talk or TalkConfig()
        self.lobes = nn.ModuleList([
            TalkLobe(hidden_dim, ffn_dim, kwta_ratio, use_kwta=use_kwta,
                     r=self.talk.r, recruit_ratio=self.talk.recruit_ratio)
            for _ in range(num_lobes)
        ])
        self.talk_gate = TalkGate(self.talk.gate_temperature,
                                  self.talk.gate_init_std)
        # Test hook: None = learned gate, 0.0 = forced closed, 1.0 = forced open.
        self.gate_force: Optional[float] = None
        # Eval-only hook: when True, also return the per-token recruited-neuron
        # index map (used for the cross-batch recruitment-pattern check).
        self.collect_rec_masks = False

    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, dict]:
        B, T, C = x.shape
        x_flat = x.reshape(B * T, C)
        N = B * T

        for lobe in self.lobes:
            lobe.reset_execution_flag()

        sel = self._route(x_flat)
        effective_k = self._effective_top_k

        out_flat = torch.zeros_like(x_flat)
        per_lobe_count = [0] * self.num_lobes
        per_lobe_masks: list = [None] * self.num_lobes
        per_lobe_conf: list = [None] * self.num_lobes

        if self.routing_mode == "learned" and effective_k > 1:
            sel_scores = self._last_scores.gather(-1, sel)
            weights = F.softmax(sel_scores, dim=-1)
        else:
            weights = torch.full((N, effective_k), 1.0 / effective_k,
                                 device=x.device, dtype=x.dtype)

        gate_map = torch.zeros(N, device=x.device)
        gate_p_map = torch.zeros(N, device=x.device)
        gate_score_map = torch.zeros(N, device=x.device)
        margin_map = torch.zeros(N, device=x.device)
        mass_map = torch.zeros(N, device=x.device)
        rec_count_map = torch.zeros(N, device=x.device)
        per_lobe_div: list = [None] * self.num_lobes
        rec_idx_map = None
        open_sum = torch.zeros((), device=x.device)
        p_count = 0
        active_sum = 0.0
        active_count = 0
        div_sum = 0.0
        div_count = 0
        distill_sum = torch.zeros((), device=x.device)
        distill_count = 0

        for k_slot in range(effective_k):
            lobe_ids = sel[:, k_slot]
            for lobe_idx in range(self.num_lobes):
                token_mask = (lobe_ids == lobe_idx)
                if not token_mask.any():
                    continue
                x_subset = x_flat[token_mask]
                lobe = self.lobes[lobe_idx]
                r = lobe.talk_forward(x_subset)

                margin = r["margin"].detach()
                mass = r["mass"].detach()
                s = self.talk_gate.score(margin, mass)
                p = torch.sigmoid(-s / self.talk_gate.temperature)

                if self.gate_force is not None:
                    g_hard = torch.full_like(p, float(self.gate_force))
                else:
                    g_hard = (p > 0.5).to(p.dtype)
                if self.training and self.gate_force is None:
                    g = g_hard + p - p.detach()
                else:
                    g = g_hard

                out_sub = r["y_base"] + g.unsqueeze(-1) * r["y_rec"]
                w = weights[token_mask, k_slot].unsqueeze(-1)
                out_flat[token_mask] += w * out_sub

                per_lobe_count[lobe_idx] += int(token_mask.sum().item())
                per_lobe_masks[lobe_idx] = r["win_mask"].detach()
                per_lobe_conf[lobe_idx] = lobe.compute_confidence(x_subset).detach()

                gate_map[token_mask] = g_hard.detach()
                gate_p_map[token_mask] = p.detach()
                gate_score_map[token_mask] = s.detach()
                margin_map[token_mask] = margin
                mass_map[token_mask] = mass
                rec_count_map[token_mask] = r["rec_mask"].sum(-1).to(x.dtype)

                open_sum = open_sum + p.sum()
                p_count += p.numel()

                n_active = (r["win_mask"].sum(-1).float()
                            + g_hard * r["rec_mask"].sum(-1).float())
                active_sum += (n_active / lobe.ffn_dim).sum().item()
                active_count += n_active.numel()

                # Diversity: distinct neurons recruited per lobe across the
                # batch (only tokens whose gate is open actually use them).
                open_rows = r["rec_mask"][g_hard > 0.5]
                if open_rows.shape[0] > 0:
                    div_lobe = open_rows.any(dim=0).sum().float() / lobe.ffn_dim
                    div_sum += div_lobe.item()
                    div_count += 1
                else:
                    div_lobe = torch.zeros((), device=x.device)
                per_lobe_div[lobe_idx] = div_lobe.detach()

                if self.collect_rec_masks:
                    if rec_idx_map is None:
                        max_m = max(l._recruit_count() for l in self.lobes)
                        rec_idx_map = torch.zeros(N, max_m, dtype=torch.long,
                                                  device=x.device)
                    m_l = r["rec_idx"].shape[1]
                    rec_idx_map[token_mask, :m_l] = r["rec_idx"]

                if self.training and r["dense"] is not None:
                    distill_sum = distill_sum + F.mse_loss(
                        out_sub.float(), r["dense"].detach().float(), reduction="sum")
                    distill_count += out_sub.numel()

        out = out_flat.view(B, T, C)
        open_rate = open_sum / max(1, p_count)
        # Two-sided rate target: the one-sided mean(p) penalty could only
        # ever drive the gate closed, and it did (open rate hit 0 by step
        # 1,000 in every seed).
        open_penalty = (open_rate - float(self.talk.rate_target)) ** 2
        distill = (distill_sum / max(1, distill_count)) if distill_count else \
            torch.zeros((), device=x.device)

        diagnostics = {
            "selected_lobe_indices": sel.view(B, T, effective_k),
            "per_lobe_execution_count": per_lobe_count,
            "per_lobe_winning_masks": per_lobe_masks,
            "per_lobe_confidence_mean": [
                (c.mean().item() if c is not None else 0.0) for c in per_lobe_conf
            ],
            "effective_top_k": effective_k,
            "routing_mode": self.routing_mode,
            "talk_open_rate": gate_map.mean().item() if N else 0.0,
            "talk_active_fraction": active_sum / max(1, active_count),
            "talk_diversity": div_sum / max(1, div_count),
            "talk_open_penalty": open_penalty,
            "talk_distill_loss": distill,
            "talk_gate_map": gate_map.view(B, T).detach(),
            "talk_gate_p_map": gate_p_map.view(B, T).detach(),
            "talk_gate_score_map": gate_score_map.view(B, T).detach(),
            "talk_margin_map": margin_map.view(B, T).detach(),
            "talk_mass_map": mass_map.view(B, T).detach(),
            "talk_rec_count_map": rec_count_map.view(B, T).detach(),
            "talk_diversity_per_lobe": per_lobe_div,
            "talk_rec_idx_map": (rec_idx_map.view(B, T, -1).detach()
                                 if rec_idx_map is not None else None),
        }
        return out, diagnostics


def resize_talk_optimizer_state(optimizer, lobe: TalkLobe,
                                old_A: torch.nn.Parameter,
                                old_B: torch.nn.Parameter,
                                n_new: int) -> None:
    """Move Adam moments to the new A/B Parameters and swap them into the
    optimizer's param groups (same treatment GrowthMonitor gives fc1/fc2).

    Existing neurons' moments are padded with zeros along the neuron axis;
    only the new neurons start fresh.
    """
    if optimizer is None:
        return
    for old_param, new_param, axis in ((old_A, lobe.A, 0), (old_B, lobe.B, 1)):
        state = optimizer.state.pop(old_param, None)
        if state:
            for key in ("exp_avg", "exp_avg_sq"):
                val = state.get(key)
                if val is None:
                    continue
                pad_shape = list(val.shape)
                pad_shape[axis] = n_new
                pad = torch.zeros(pad_shape, dtype=val.dtype, device=val.device)
                state[key] = torch.cat([val, pad], dim=axis)
            optimizer.state[new_param] = state
        for group in optimizer.param_groups:
            group["params"] = [new_param if p is old_param else p
                               for p in group["params"]]
