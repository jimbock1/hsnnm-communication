# Samples — TinyStories, 6,100-step budget

8 fixed prompts, temperature 0.8, top-k 40, sampling seed 1234, 300 characters.
talk v1 = original gate (open rate collapsed to 0). talk v2 = gate fix (standardized inputs, two-sided rate target); gate stays open ~0.5–0.6.
Greedy outputs for complete runs are in each run's `samples/final_greedy.txt`.

## Prompt 1

_Once upon a time, there was a little girl named Lily who found a shiny red ball in the garden._

**hsnnm (step 6,100)**

```
Once upon a time, there was a little girl named Lily who found a shiny red ball in the garden. She was the rabbit to her cherry and of she was so excited to see a starte with a piece of the sky.

"Lily, I'm sorry, why they were at the basket and made the caranby.

Thearost hur fumbrmouin ain t. os gin fin t lewa whey t mewin in awit ld wicever t. andea beadesigond wagrmo agr st, heest. t hin
```

**talk v1, closed gate (stopped at 2,500; samples at 2,000)**

```
Once upon a time, there was a little girl named Lily who found a shiny red ball in the garden.

Mist onte got was so happy. It was happy and it was so happy! She can was a big tree excited. 

He was so pred the for her and he said, "Thank you a good don't ando!wark, mowinst. thicowischideansce ow he stotheer fr thowatono itheat ive thano a an ano anisand acowathothot botowawarellllmand thasw
```

**talk v2 seed 0 (step 6,100)**

```
Once upon a time, there was a little girl named Lily who found a shiny red ball in the garden. She was to come chose and prove to the garden laughed. 

One day, she went to the train to the sun she could scared. She was so so happy that she decided to read thiedy. in thaream. to too wathe hevar the agammalllllllloup aneathear t abun t athind aro thex an atroureveanex washase frowagshex t owa
```

**talk v2 seed 1 (step 6,100)**

```
Once upon a time, there was a little girl named Lily who found a shiny red ball in the garden. She was pretending to her heavy. One day, she was so happy to her different reached her mom and they didn't want to take it. She was so happy and went something lin ootonsthe ane bumow shy on thichinder icededer hind mor bowing. ar che. stheld. thin thest hongs ting. t. ighas hicombrano s, at. ad a
```

**talk v2 seed 2 (step 6,100)**

```
Once upon a time, there was a little girl named Lily who found a shiny red ball in the garden. One day, Tom went to the sharin and a sound and saw a big fiant park. Tom was very happy. He barked and shouted, but he was so shared not he noticed.

But then, he sky thare hise it donomad his we dougould ft day idevear m thounon ay sthever war ouche t wathe is chen. the t is kn, wara flucheveven
```

**dense (step 6,100)**

```
Once upon a time, there was a little girl named Lily who found a shiny red ball in the garden. She loved to play in the store and her lesson. One day, she played on a big jar with her garden. It was a store to make a surprise. But she was stubborn and readyead bonds. tofofownes. incor fonewines. tstscofurn'ton.

On an. th an es t fito on torn toreanithegut, an. orguton on on oran fanean an a
```

## Prompt 2

_The small brown dog ran across the yard and stopped by the old wooden fence._

**hsnnm (step 6,100)**

```
The small brown dog ran across the yard and stopped by the old wooden fence. The small smiled and laughed and the pillow. Everyone was outside and had fun.
Once upon a time, there was a little girl named Lily. She loved to play with her dad what the ran off ther thersthead t am an. st andiger anin. her t. therst. higer. veanoneand an hin con ost a t amoumalst amea wiver amy
```

**talk v1, closed gate (stopped at 2,500; samples at 2,000)**

```
The small brown dog ran across the yard and stopped by the old wooden fence. They said they slow to play him and smiled asked. They all so make a sound, but say she was so inside.

The little girl was so excited. They said, "We're way, will okay. It only out ton and and amexp ind toithowand amea sha tousee id itoundothed wand and reand d meandand yowand id matowachowima the
```

**talk v2 seed 0 (step 6,100)**

```
The small brown dog ran across the yard and stopped by the old wooden fence. They were so loved to take a big bunny. They can fell and made a big tree with the back and made his bugs. They liked to take the best and make something some trees ball and wouldn't see thinde hiffow it togelllllifft thiffllour wishis aset themead inead n theacochint, t healllllleeaby thallllost y
```

**talk v2 seed 1 (step 6,100)**

```
The small brown dog ran across the yard and stopped by the old wooden fence. The dog was happy so the flox and was very happy to be her toys and tried it was so much fun. They said they were so happy and could fly outside and worked on it. The man saw his frowiney andest. fanes. ang ame and t and hot ficay t pand hice t thicheand ppand d feeermbo t ind t. bealllllllllleayeg
```

**talk v2 seed 2 (step 6,100)**

```
The small brown dog ran across the yard and stopped by the old wooden fence. The bird opened the bloom and it was very much. He learned that it was funny to grow.

The cat off the cat was able to the ball and the child he knew it was a gentle to play. It was to to thalo heat an, aloo the thealllp o imothe.









On swake hit oomon ouche ones ichilim. is y he amon id y th
```

**dense (step 6,100)**

```
The small brown dog ran across the yard and stopped by the old wooden fence. The dog was happy with the kitchen and the small boy said to his friends. 

The man and the dog waved their mom and dad at their friends. They said, "It's okay, Please Please for to youshelesteat morrin.".".". ton, wonergevestit, aton, an's torutorguraleap jut, e sto mon!". Ligo to.". gutoupellevit
```

## Prompt 3

_One sunny morning, Ben and his mom went to the park to feed the ducks by the pond._

**hsnnm (step 6,100)**

```
One sunny morning, Ben and his mom went to the park to feed the ducks by the pond. He had a lot of fun succk in the puppy, but it was too go to the little boy the spark. 

Finally, Jack said, "You are careful, Tom. That's sorry is not anyor happy. You knew thow that wit he dit yonelle y yone hone yonjow w heverest st p t, melllllld oneesesharear t igur t afr govew hanese. thadin,
```

**talk v1, closed gate (stopped at 2,500; samples at 2,000)**

```
One sunny morning, Ben and his mom went to the park to feed the ducks by the pond. She put it was happy Lily saw in a big and saw a long. 

The dog play with his favoring adventure. They were very sad on angry was a named food. They have for a big with theire, streeee id eadddachir. thit hand hid foumandide arewachewageachellllllllllle, ggead alllive at itot p sckesewan chitoncal
```

**talk v2 seed 0 (step 6,100)**

```
One sunny morning, Ben and his mom went to the park to feed the ducks by the pond. Then, he heard made a look at in a big spot that she does never day. 

Lily felt so happy to look at the little bird advented around the park, and she went outside to the truck. achon in sheewewast ad thindereat ad are oup, ad wan itot chellin t theveareareast t. t chitheaco t t waco in t moun iffo
```

**talk v2 seed 1 (step 6,100)**

```
One sunny morning, Ben and his mom went to the park to feed the ducks by the pond. He had a lot of fun in the sun wish them. He was very excited to learn his box.
Once upon a time, there was a little girl. He had very a special and cried. One day, she ran oupear fr an inin tser at bo tedundear and t sindun and amark aich ay ander t icand ay ar chicamaner thin ach, an andichancorg
```

**talk v2 seed 2 (step 6,100)**

```
One sunny morning, Ben and his mom went to the park to feed the ducks by the pond. He took the tree and quickly a started for her. His mom was so happy to have them even roder some high in the box. He knew that he could see what is not happened.

They both pas wan hised oundes int idan, fther thers flon wicher id athever as fr aneand s aber id d alelound tond ogsever. agellever s
```

**dense (step 6,100)**

```
One sunny morning, Ben and his mom went to the park to feed the ducks by the pond. But then he saw a small stick from the pond.

Benny was so happy and thanked him. He was playing with his friends and brought it back to playing. He was a girl who liked to plimathit agallllllorats ay ts alllllonene ts, ts ats and and and s ind andand and wad ay eandandand waymay, pppps andaymaymay
```

## Prompt 4

_There was a tiny bird with a blue wing who lived in a tall green tree._

**hsnnm (step 6,100)**

```
There was a tiny bird with a blue wing who lived in a tall green tree. Lily was so excited her toy.

Lily felt so happy and scared, but they loved to play with their bathter in the park. And they were so happy to the red the children cheese and said to Mom. wana. wand cowit a whond it a a a llllo and t plond t a sthit. ond. lon.






Liso fea wit a a covea t blithea
```

**talk v1, closed gate (stopped at 2,500; samples at 2,000)**

```
There was a tiny bird with a blue wing who lived in a tall green tree. As they were very cation together to car from what he toys. One day she saw a big big car can clong flowers! 

The little girl righten to be the light con on his lived to go to teat of and bad sunowa andvewa a ithexppp stowandasmeveeverfonthe ourstirourst idd. iveacoongewalle. rsthit ibowa fimead c
```

**talk v2 seed 0 (step 6,100)**

```
There was a tiny bird with a blue wing who lived in a tall green tree. But then she had to help he was a cried and decided to take a park to be careful and broken it strays.

The end.
Once upon a time, there was a father who wanted to be more her kicket. It was lonevever ind adouche ar asit lowadidergr aragan t ascoun ashex bum thifrevex. ag agan than antherowateat. a
```

**talk v2 seed 1 (step 6,100)**

```
There was a tiny bird with a blue wing who lived in a tall green tree. Every day, the squirrel was a big hug. She felt sad and explored dance, and the bird had a big hug hard and lots of for favourite toy and finished.

From then on, After a while, she felt s ga got wanchis s alind find amerer an thar ang and thamermathininnk amowad an fonnt anin thagrmamag aneso t an
```

**talk v2 seed 2 (step 6,100)**

```
There was a tiny bird with a blue wing who lived in a tall green tree. After a while, he waved to get her hands for lots of fun.
Once upon a time, there was a little girl named Lily. She liked to play with her friends. One day, she wanted to take a pille coome agut fome. ftome indin orrrrranowin. t. he oun an t arin. inon tornesin. winstowigrst.




On asquin het. owi
```

**dense (step 6,100)**

```
There was a tiny bird with a blue wing who lived in a tall green tree. 

The bird was very clever. It was hopping around in the jungle and a funny chair. The bird was so excited. But the bird came back to the chair. She ran to her friend, but she didn't want to lanco to wasto t. mo geasto fin theven owast.









On'sthen heareast traigurr t. aigair t. gait. ofowit.
```

## Prompt 5

_Sara looked out of the window and saw that everything outside was covered in soft white snow._

**hsnnm (step 6,100)**

```
Sara looked out of the window and saw that everything outside was covered in soft white snow. It was a big, and started to listen to one to, Baby went for a lot of of the park.

After a went, he little girl named Lily. She loved to play with they dress and washe are igond t.


Ond thea hon and and t sheand and t t therea t herewa t marand t band t. ico ind thes. wicr. on. t anondiseand, t a
```

**talk v1, closed gate (stopped at 2,500; samples at 2,000)**

```
Sara looked out of the window and saw that everything outside was covered in soft white snow. But the strouch you bok with her in the suld looked at a letter. 

When they don't want to cat the suif shared, "I'm was ready?" Thank, it your very hope, leased. "Do Heare Lup fon Moton fougout idddelllevefrseamow it t n thexthead junjucow! aseallinst yoot acalllllinsnd ow nd tid towhowar thefithi
```

**talk v2 seed 0 (step 6,100)**

```
Sara looked out of the window and saw that everything outside was covered in soft white snow. From that day on, Lily was so happy to her mommy and said, "Let's go close!" Sam said, "Lily, please, it is not stay for playing in the house," she said.

Finally aday, ay wadde conerse d thelinevereve ar thalllin oupeat therspead thallllllmevear ther hersespar. cousinâ€™snead t, thad thit theread
```

**talk v2 seed 1 (step 6,100)**

```
Sara looked out of the window and saw that everything outside was covered in soft white snow. Everyone was so knew he all had he found very seen anything. 

As the storm was very happy to share away. It was so happy to see where she don't want to his people ople t. thopear at ond thicofiner ar ats. s.




On thether rmond there. hesn head thathetholp be. coopothend ar ines t t. thas thead a
```

**talk v2 seed 2 (step 6,100)**

```
Sara looked out of the window and saw that everything outside was covered in soft white snow. From that day on, Lily was so happy to jump of the paper of her facet in the garden. She always played with her mom and said, "Thank you, Lily, got a cloncer dog onaran tothes the.". win the to o a aschimo s thean a theve thear the Lichistheat." dalllllllllllllllllllllllabes t tst t. o t mo t whet.
```

**dense (step 6,100)**

```
Sara looked out of the window and saw that everything outside was covered in soft white snow. She was so surprised and very sad. She jumped over to the table and felt scared.

The little boy flew to the swings and from the brave toy so that he spotted it at s heveas woffeveveat geast. f. orr ofounevealeat. wast fur an orandanevew. achit. st. weasth st. weandan, or utheanour orn. tst anit t
```

## Prompt 6

_The little boy opened the box and inside he found a toy train with a bright yellow wheel._

**hsnnm (step 6,100)**

```
The little boy opened the box and inside he found a toy train with a bright yellow wheel. The man had a big and showed him to the story and started to find his mom.

He found a whistle, and the daughter was so pretty and found the carpish and had lots of fun.

Onewalapeweast win hindig hin. t ally gon ageamp. Ticeamant on. ar. wand t. t t t. d akevin agevigear t. sthineafumbllllla wakew
```

**talk v1, closed gate (stopped at 2,500; samples at 2,000)**

```
The little boy opened the box and inside he found a toy train with a bright yellow wheel. The decided to play with his toy was them and proved it the pirl. She said they saw they are for what they all playing in her friends.
One day, Spot they started to play. sand thevexclid itoo it sthea o oureanyit t. ithito stoureand litstoo o wa bewand hea gea tono ond theameextheatheea a t cread i
```

**talk v2 seed 0 (step 6,100)**

```
The little boy opened the box and inside he found a toy train with a bright yellow wheel. The cilds was so excited to go start to share it inside and they ate they had to have a strange.

The little girl was very happy and changed. He hugged him and said, "Towhe doucarmphaloullllllll oughift thies l ikinghithickift ft finde fun. tharowamar ane aloothe ine!" the was fowareathar than bowa
```

**talk v2 seed 1 (step 6,100)**

```
The little boy opened the box and inside he found a toy train with a bright yellow wheel. The might family and watched a named Tim. Timmy loved to listen to his mom. He did not look at the box. He said they were so proud of his rock and had a smile. He did n't not noway s ithanot ceano wanot a and fllllllllllllles inoow ts atharmowane ad t arand ake arowar anjowaner. ay t t he anond war
```

**talk v2 seed 2 (step 6,100)**

```
The little boy opened the box and inside he found a toy train with a bright yellow wheel. The met boy was wrong at the camp and bear to play with the sounderstand.

The end.
The little boy was curious. He was surprised to open and started to grow. He thought at hit to walene ichead t oo he thele wapp athe thimoner it icone hey in parn outhe ithit win, wacon the forne in hithe theld fley
```

**dense (step 6,100)**

```
The little boy opened the box and inside he found a toy train with a bright yellow wheel. He was very happy.

The little boy was so happy that he was always looking for it. Toby started to cry and tried to cry. He made the crowd away strange that he found a heaccor theyw thir fo an trewo to ineasthelesteair sto ffor aithe, tr ndair astheair or thelleaito n air astran t. thireair eaingur
```

## Prompt 7

_A happy cat sat on the warm kitchen floor and watched the rain fall on the glass._

**hsnnm (step 6,100)**

```
A happy cat sat on the warm kitchen floor and watched the rain fall on the glass. Lily was so excited to shape and until it was the little bird. 

She saw a big dog named Sue. She called her mouth, but she got down the bigger, she was noticed to a big with ineldongs wak. ar aflo. ait an. ag.



Ond. st and helost wap to wasonst lo brean. an azig. hese. hist ffean bond. t t fr an
```

**talk v1, closed gate (stopped at 2,500; samples at 2,000)**

```
A happy cat sat on the warm kitchen floor and watched the rain fall on the glass. It said, "I'm ran it, ret's very just big a back with a be tree new to fast and said, "It's hadings to back becotll sorry the one."

The box walked her mom the foater and said shid, thalonk the watureat t wand iglid tono beand hand fithewo bo bexcowant and fread and icawaroumemeft torewad thid toow
```

**talk v2 seed 0 (step 6,100)**

```
A happy cat sat on the warm kitchen floor and watched the rain fall on the glass. And they were refavorite and sad, but they said to make a game for different realized that was not wants.
Once there was a little girl named Lily. She loved to play with her molld esesmon wigsotean othig fexcheet. t an heexp owin ot wachearot our t antoun toun an an owherealp thexp fin fother shexp
```

**talk v2 seed 1 (step 6,100)**

```
A happy cat sat on the warm kitchen floor and watched the rain fall on the glass. It is the bench fast. She was hoppy to be and said, "Thank you, Timmy. We can have to see a cat!"
Once upon a time, there was a little girl. She had lots off fun. She was very sispry nindesery tet chathery hand fligry cry thangochy seellloweashalllllie.




Ongeay at. t ud. in acr an. an anand and
```

**talk v2 seed 2 (step 6,100)**

```
A happy cat sat on the warm kitchen floor and watched the rain fall on the glass. But then, the wall showed the tamp and did not listen to her kind swimming in the park. He liked to play with her new park. Mommy was getting again. He wants to his friends and ppichiclas ove onge. icolllizze. ive,












On ice, hichig d t, on hot on wimoun thisatho outhe cke wathe thimomo on
```

**dense (step 6,100)**

```
A happy cat sat on the warm kitchen floor and watched the rain fall on the glass. From that day on, Timmy learned that he learned to be a good kind and be kind and made him happy.
Sara and Ben were playing in the park with their toys. The end.
Sara and Ben wenjo limeag weant rveyeachan rvew hacherered w t t t tonexpleveveveachachachanjomestesinjor stever plesw tedachandandan tes
```

## Prompt 8

_Tom and his sister walked down the path until they reached a small house with a red door._

**hsnnm (step 6,100)**

```
Tom and his sister walked down the path until they reached a small house with a red door. They thought it was shining and said, "Sorry, we didn't know, Lily?" 

Lily replied, "Yes, but it could get play outside to make her something.

Suddenly, Ben came out bld a a ffoff chexp handa thewindermeld thocove and wind hager best had alin. ffust. hand and cond t thondesad andest and hind alay
```

**talk v1, closed gate (stopped at 2,500; samples at 2,000)**

```
Tom and his sister walked down the path until they reached a small house with a red door. The little girl was about careful beling and see cared to fly and played and played with his had a gerlet.
One day, she earced to wating, he wanted to came to her house, four ade anche fr hoump thoveade herstheakewallllld t ater boone ad cotheatwad bonexeathithest thit tithiter abo o wanexexcrea fo
```

**talk v2 seed 0 (step 6,100)**

```
Tom and his sister walked down the path until they reached a small house with a red door. He liked to do on his room and said, "Thank you, you we comfort." Lily was but scared to call the tree. 

The little boy came to the car. He still and ran to the park ato to to andogeanthe peverseagop.

Sathet wst fo it an thexat theat ther thevem thear hea t therer acanin aleveak. hin thex t. t wh
```

**talk v2 seed 1 (step 6,100)**

```
Tom and his sister walked down the path until they reached a small house with a red door. They had a broken to help from the blue and their beam.

"Ow!" Ben said. "It is not a strong enough other. But I am going noise and all day."

Lily went to the park. She Sud Theread and, t fingonew Ther hin t t cher to theeeeat thead d ther the sstheeschee cheer t ad t tur sto theee theeeatst the a
```

**talk v2 seed 2 (step 6,100)**

```
Tom and his sister walked down the path until they reached a small house with a red door. The little girl was surprised to to buy the stirs too!

Tom was very excited to give her hard a new perfect. He wished they could coming the town and it was not dirty. banowineat. whin.




On. hin, to t. hino he cumo walin the. be wage walo thirr co athe o the stho o athe clathe imo s anono o thou
```

**dense (step 6,100)**

```
Tom and his sister walked down the path until they reached a small house with a red door. They felt like dinnerstand.

"No, Lily, what are you doing?" she asked. "The boy can we want to be the box to make the doctor. And it will be fast and colorful."

Lily didnoes wes njucoft ndeamand rag licagragriretes linds hes onds ur agandondontes fand land agages. wandmes ax agrves agrgex and ind
```
