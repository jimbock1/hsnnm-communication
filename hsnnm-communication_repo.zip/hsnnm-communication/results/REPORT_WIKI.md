# REPORT — Wikipedia corpus, 2 epochs (956M tokens)

Same architecture, hyperparameters and schedule as the TinyStories runs; only
the corpus changed. Char-level, vocab 6,946, 479.8M train tokens/epoch,
25.3M held-out val tokens, 2 epochs = 58,342 steps = 956M tokens, cosine over
the whole run, checkpoints every 5,834 steps (~95.6M tokens).

## Final results (full validation, 1,538 batches)

| run | subset ppl | full ppl | params | wall time | growth events |
|---|---|---|---|---|---|
| hsnnmwiki_s0 | 3.344 | **3.473** | 9.95M | 342 min | 0 |
| talkwiki_s0 | 3.329 | **3.455** | 10.15M | 503 min | 0 |
| densewiki_s0 | 3.000 | **3.109** | 9.95M | 141 min | – |

TALK is **0.5% better** in full-val ppl (3.455 vs 3.473) at equal steps and
equal tokens, using ~1.5× the wall-clock.

## The ~1% at mid-training narrows

At equal steps TALK led by up to 2.3% (step 6,000) and −0.6% by step 22,000.
Both models converged to a ~0.5% gap at the endpoint. Per-position
decomposition (400 val batches, same order for both):

| position | HSNNM ppl | TALK ppl | rel |
|---|---|---|---|
| 0–64 | 3.8909 | 3.8691 | −0.56% |
| 64–128 | 3.3968 | 3.3761 | −0.61% |
| 128–192 | 3.2972 | 3.2821 | −0.46% |
| 192–256 | 3.2346 | 3.2227 | −0.37% |
| overall | 3.4456 | 3.4285 | −0.50% |

**There is no long-horizon advantage.** If recruitment helped coherence, the
gap should grow with position; it shrinks instead. The earlier "TALK stays
sane longer" impression from samples is not supported by the numbers.

## Gate behaviour (final eval)

- Open rate 0.702 overall, but strongly **layer-specific**: 0.992 / 0.469 /
  0.493 / 0.855. The gate learned that layers 1 and 4 want recruitment and
  the middle layers mostly don't.
- Recruitment diversity 0.328; recruited neurons per token = 20 (capped).
- Open-token ppl 3.042 vs closed-token ppl 3.815; loss–gate correlation
  −0.095. The gate preferentially opens on **easier** tokens — the opposite
  of the intended "hard tokens get more compute".
- FLOPs/token at the measured 70% open rate: 12.57M (closed 12.48M, open
  12.61M) vs HSNNM 12.42M.

## Other findings

- **net2net growth never fires** (0 events in 58,342 steps). Cause is
  structural: the utilisation signal is the mean k-WTA winning fraction
  (= k/N = 0.20 by construction) and the trigger requires ≥ 0.85. Growth is
  inert until that signal is redefined.
- No non-finite losses or gradients.
- Equal-step samples (29,170 / 35,004 / 40,838) and the final samples are in
  `samples_equal_steps.txt`, `results/talkwiki_s0/samples/`,
  `results/hsnnmwiki_s0/samples/`. Qualitatively the two models are
  indistinguishable: both learn wiki formatting (See also / References) and
  both degenerate into token salad after 1–2 clauses.

## Verdict

Dense wins clearly on Wikipedia, by a wider margin than on TinyStories:

| run | full-val ppl | vs dense | wall time | params |
|---|---|---|---|---|
| densewiki_s0 | **3.109** | – | 141 min | 9.95M |
| talkwiki_s0 | 3.455 | +11.1% | 503 min | 10.15M |
| hsnnmwiki_s0 | 3.473 | +11.7% | 342 min | 9.95M |

And it does it while computing 19.49M analytic FLOPs/token vs HSNNM's 12.42M —
i.e. the *sparse* model does less nominal work and is still 2.4× slower in
wall-clock. The efficiency claim (2× fewer FLOPs) is real on paper and
inverted in practice, which is the central systems finding of this work.

TALK's gate is real and used (70% open, strongly layer-specific: 0.99 / 0.47 /
0.49 / 0.86), but its 0.5% ppl advantage over HSNNM is an order of magnitude
smaller than the 11% gap to dense. It does not rescue the architecture.

Single seed each; ±0.01–0.02 ppl is within noise, so treat the 0.5% TALK gain
as indicative and the ~11% dense gap as robust.
