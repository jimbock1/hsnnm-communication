# REPORT — TinyStories 6,100-step check (HSNNM / TALK / dense)

## Setup

- **Budget:** 6,100 steps = 99.9M tokens (2 epochs over 10% of TinyStories,
  char-level, seq 256, batch 64), matching `HSNNM/configs/phase1_novel.yaml`.
- **Differences from the Kaggle config:** seed **0** (Kaggle used 42), **bf16
  autocast** (Kaggle used fp16 on T4), Hebbian **decay 0.01** (paper's
  corrected rate; the YAML says 0.001), **0 dataloader workers**, and one seed
  for HSNNM/dense (three for TALK).
- **Runs:** `hsnnm_s0` (full 6,100), `talk_s0/s1/s2` (`--gate-init-std 1.0`,
  stop rule active), `dense_s0` (full 6,100).
- **Hardware:** RX 9060 XT 16 GB, ROCm 7.2.1, torch 2.9.1. Two jobs ran
  concurrently.
- **Outputs:** this folder. Per run: `results/<run>.json` (all metrics),
  `<run>/log.jsonl` (every 50 steps + every eval), `<run>/ckpt/` (last 3 +
  final, resumable), `<run>/samples/`, `<run>/gpu/`.

## Results

| run | steps | val ppl @2,500 | final val ppl (subset / full) | FLOPs/tok closed / open / at-rate | gate open (last eval) | active frac | recruit diversity |
|---|---|---|---|---|---|---|---|
| hsnnm_s0 | 6,100 | 2.962 | **2.641 / 2.646** | 7.18M / – / – | – | 0.201 (k-WTA) | – |
| talk_s0 | 2,500 | 2.989 | 2.989 / – | 7.24M / 7.37M / **7.24M** | **0.000** | 0.201 | 0.000 |
| talk_s1 | 2,500 | 2.935 | 2.935 / – | 7.24M / 7.37M / **7.24M** | **0.000** | 0.201 | 0.000 |
| talk_s2 | 2,500 | 2.907 | 2.907 / – | 7.24M / 7.37M / **7.24M** | **0.000** | 0.201 | 0.000 |
| dense_s0 | 6,100 | 2.450 | **2.187 / 2.190** | 14.25M / – / – | – | – | – |

- All TALK runs stopped themselves at step 2,500 under the agreed rule
  (gate open < 2% for 3 consecutive evals after step 1,500). Per instruction
  they were **not retuned or restarted**; their JSON, checkpoints and samples
  are kept. Stopped runs have no full-validation number and no final samples;
  their last samples are from step 2,000.
- 0 non-finite losses or gradients in any run.
- Parameters: hsnnm 7.33M, talk 7.53M, dense 7.33M (parameter-matched
  baseline).
- Full validation = all 582 val batches (9.53M tokens). The 50-batch subset
  and full split agree to within 0.005 ppl for complete runs.

Curves: `curves.png` (train loss, val perplexity, TALK gate open rate).

## Gate behaviour

- Calibration at init: ~50% of tokens open. By eval 500 the open rate is
  0.0003; from eval 1,000 onward it is exactly **0.000 in all four layers,
  all three seeds**.
- The gate score drifts positive (mean 0.43 at step 500 → 1.05–1.10 at
  2,500), i.e. `p = sigmoid(-score)` falls well below 0.5 everywhere. The
  open-rate penalty (0.01) and distillation (0.1) both push this direction.
- Because the gate is constant, the per-token loss vs gate-open correlation is
  0.000 by construction. **"Do hard tokens open the gate more?" cannot be
  answered from these runs** — the gate never opens, so there is no contrast
  to correlate against.
- Margin and mass are recorded but never used: margin mean ≈ 0.008, mass mean
  ≈ 0.57 (they are only read when the gate opens).

## Is TALK working?

Against the agreed criteria:

1. **Gate open clearly between 0% and 100%** — **fails.** It starts at ~50%
   after calibration and collapses to 0% within 500 steps.
2. **Recruitment varies by input** — **fails.** No token is ever open, so
   recruitment diversity is 0 and the per-lobe recruited set has no effect.
   (The sets are still computed and logged; `recruit_set_match_prev_batch`
   ≈ 0.0003 since consecutive batches differ, but they gate nothing.)
3. **Val ppl not worse than HSNNM** — at equal token budget (step 2,500),
   TALK is 2.907–2.989 (mean 2.944) vs HSNNM 2.962, i.e. indistinguishable.
   There is no full-validation number for TALK because it stopped early.

**Verdict: TALK is not working in this setup.** The reliability gate learns to
close within ~500 steps, the model degenerates to HSNNM plus unused
recruitment parameters, and there is no accuracy benefit at equal tokens.

One implementation detail matters for the FLOPs column: the analytic
closed/open numbers follow the intended semantics (recruitment work only for
open tokens), but the current implementation **computes the recruitment path
for every token and multiplies by the gate**, so the measured cost when closed
is the closed figure plus that work. There is no throughput win from closing
the gate; solo throughput was ~64k tok/s for TALK vs ~67k for HSNNM.

## Growth

**No growth event fired in any run.** No lobe met the four-signal saturation
criteria (confidence, utilisation, entropy, persistence) over 200-step windows
within 6,100 steps, so the net2net growth component was never exercised at
this budget. The growth code paths (including the TALK A/B resize) were
smoke-tested separately.

## Throughput (observed)

| run | solo tok/s | 2-job tok/s | wall time |
|---|---|---|---|
| dense_s0 | ~252,000 | – | 16.5 min |
| hsnnm_s0 | ~67,000 | 63–66k | 33.5 min |
| talk_s0–s2 | ~64,000 | 35–40k | 21–28 min to step 2,500 |

The dense baseline is ~4× faster per token to train because it skips the
lobe routing, k-WTA masks and per-lobe Hebbian bookkeeping.

## Caveats

- One seed for HSNNM and dense; TALK has three seeds. Differences of 0.03–0.06
  ppl (like TALK vs HSNNM at 2,500) are within single-seed noise — not
  evidence of a real effect either way.
- TALK runs used 40.96M tokens (stopped), not the full 99.9M, so they cannot
  be compared at the 100M-token endpoint.
- All numbers are char-level TinyStories at a small budget; they may not carry
  over to larger or harder corpora.
- The dense baseline wins clearly here (2.19 vs 2.64 at 6,100 steps). At this
  size and budget the lobe/k-WTA structure does not pay for itself; that is a
  statement about this budget, not about the paper's full-scale result.

## Notes

- Generation runs on the GPU under bf16 autocast with no_grad, using a
  dedicated CUDA generator and restoring training RNG afterwards; generation
  time is excluded from tokens/s.
- Resume was tested end to end: a run was interrupted and continued from
  `--resume latest` with optimizer, scheduler, growth-monitor windows and RNG
  restored.

---

# Addendum — TALK gate fix (v2)

## What was wrong

The original gate computed `score = w1*margin + w2*mass + b` on raw inputs.
Margin is ~0.008 and mass ~0.55, so the mass term dominated and per-token
variation was buried; the gate degenerated into a global on/off switch. On top
of that the auxiliary loss was one-sided — `0.01 * mean(p)` — which can only
push the gate closed. Measured result: calibrated to ~50% open at init,
0.03% open at step 500, 0% from step 1,000 on, in every seed.

## What changed (TALK only — data, steps, LR schedule, growth and eval are identical)

1. **Gate inputs are standardized per call** (z-score over the tokens seen by
   that gate), so margin and mass carry comparable variance and the gate can
   actually separate tokens.
2. **One-sided open penalty → two-sided rate target**: `(mean(p) − 0.5)²`
   instead of `mean(p)`. Nothing pushes the gate closed any more; nothing
   forces it open either.
3. Live gate-open rate is now logged every 50 steps (`open_rate_train`), and
   the run header prints the real step budget.

Everything else — 6,100 steps, char-level TinyStories, batch 64×256, LR 3e-4
cosine, growth settings, eval cadence, prompts — is unchanged, so the v2 runs
are directly comparable to `hsnnm_s0` and `dense_s0`.

## Results at 6,100 steps

| run | full val ppl | gate open (final) | per-layer open | diversity | loss–gate corr | ppl open / closed |
|---|---|---|---|---|---|---|
| hsnnm_s0 | 2.646 | – | – | – | – | – |
| talkv2_s0 | 2.683 | 0.565 | .54/.56/.53/.63 | 0.531 | +0.025 | 2.785 / 2.604 |
| talkv2_s1 | 2.635 | 0.557 | .56/.55/.53/.59 | 0.506 | −0.182 | 2.080 / 3.083 |
| talkv2_s2 | 2.608 | 0.589 | .67/.70/.50/.49 | 0.421 | −0.004 | 2.577 / 2.623 |
| dense_s0 | 2.190 | – | – | – | – | – |

Gate-open trajectory (v2): 0.48–0.51 at eval 500, rising to 0.56–0.59 by the
end — inside (0, 1) for the whole run, no stop-rule trigger.

FLOPs/token at the measured rate: 7.31M (closed 7.24M, open 7.37M) vs HSNNM
7.18M and dense 14.25M.

## Is TALK working now?

1. **Gate open clearly between 0% and 100%** — **passes** (48–59% throughout).
2. **Recruitment varies by input** — **passes** (diversity 0.42–0.53, i.e. the
   recruited sets differ token to token; per-layer open rates differ too,
   e.g. 0.67/0.70/0.50/0.49 in seed 2).
3. **Val ppl not worse than HSNNM** — essentially tied: mean 2.642 vs 2.646
   (−0.15%), seed range 2.608–2.683. Not a measurable improvement.

The gate opens and the recruitment path is genuinely used (open-token and
closed-token ppl differ substantially in s1: 2.08 vs 3.08). But the *selection*
is inconsistent across seeds: s1's gate preferentially opens on easier tokens
(corr −0.18), s0's is neutral (+0.03), s2's is neutral (−0.004). So the gate
is doing something, but not a stable "hard tokens get more compute" policy at
this budget.

## Caveats specific to v2

- Three seeds here; differences of ±0.04 ppl (2.608–2.683) are within seed
  noise. Do not read the 2.608 seed as a win over HSNNM.
- The recruitment path is still *computed* for every token and multiplied by
  the gate, so opening the gate does not change wall-clock cost (~64k tok/s
  solo, same as HSNNM).
- The gate fix was verified on TinyStories only at this point; the Wikipedia
  runs (below) are the harder test.

---

# Wikipedia corpus runs (running)

Setup: `wikimedia/wikipedia` 20231101.en streamed to 505M chars
(107,046 articles) — `data/wiki_20231101.jsonl`; char-level vocab of 6,946;
479.8M train tokens/epoch, 25.3M held-out val tokens.

- 2 epochs = 58,342 steps ≈ 956M tokens, cosine over the whole run,
  warmup 200 (unchanged).
- Checkpoint every 5,834 steps ≈ 95.6M tokens (1/5 epoch), last 3 + final
  kept; resumable with `--resume latest`.
- Runs: `talkwiki_s0` (v2 gate), `hsnnmwiki_s0` (baseline), `densewiki_s0`
  (starts when a slot frees). Same batch 64×256, LR 3e-4, growth settings.
- Eval every 500 steps on the 50-batch subset; final full validation over all
  1,538 val batches. Wiki-style prompts in `prompts_wiki.txt`.

Status at report time: running. Results will be written to
`REPORT_WIKI.md` when the queue completes.
