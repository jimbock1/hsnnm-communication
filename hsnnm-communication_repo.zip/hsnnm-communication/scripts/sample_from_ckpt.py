"""Generate samples from the latest checkpoint of a wiki run (read-only)."""
_REPO = __import__("pathlib").Path(__file__).resolve().parents[1]
import argparse
import sys
import time
from pathlib import Path

sys.path.insert(0, str(_REPO / "TALK"))
sys.path.insert(0, str(_REPO / "HSNNM"))

import torch  # noqa: E402
import train as T  # noqa: E402
from config import set_seed  # noqa: E402
from model.tokenizer import CharTokenizer  # noqa: E402
from talk_layer import TalkConfig  # noqa: E402

RESULTS = (_REPO / "results")
PROMPTS = (_REPO / "scripts/prompts_wiki.txt")


def latest_ckpt(run: str) -> Path:
    files = sorted((RESULTS / run / "ckpt").glob("step_*.pt"))
    if not files:
        raise SystemExit(f"no checkpoints in {RESULTS / run / 'ckpt'}")
    return files[-1]


def build_from_payload(payload, model_type: str):
    a = argparse.Namespace(**payload["args"])
    cfg = T.build_config(a)
    tok = CharTokenizer.from_dict(payload["tokenizer"])
    cfg.model.vocab_size = tok.vocab_size
    talk_cfg = TalkConfig(
        r=a.talk_r, recruit_ratio=a.talk_m_ratio, lambda_open=a.lambda_open,
        lambda_distill=a.lambda_distill, gate_init_std=a.gate_init_std,
        rate_target=getattr(a, "gate_target", 0.5))
    cfg.talk = talk_cfg
    if model_type == "talk":
        model = T.build_talk_model(cfg, talk_cfg)
    else:
        model = T.build_novel_model(cfg)
    T._rebuild_to_counts(model, payload.get("lobe_neuron_counts"))
    model.load_state_dict(payload["model_state_dict"])
    return model.cuda(), tok


def main() -> None:
    prompts = T._load_prompts(PROMPTS)[:2]
    out = []
    for run, mtype in (("hsnnmwiki_s0", "hsnnm"), ("talkwiki_s0", "talk")):
        ck = latest_ckpt(run)
        payload = torch.load(ck, map_location="cpu", weights_only=False)
        step = payload.get("step")
        set_seed(0)
        model, tok = build_from_payload(payload, mtype)
        del payload
        torch.cuda.empty_cache()
        t0 = time.time()
        texts, stats = T.generate(mtype, model, tok, prompts, n_chars=300,
                                  temperature=0.8, top_k=40, seed=1234)
        out.append(f"### {run} | checkpoint {ck.name} (step {step}) | "
                   f"{time.time()-t0:.1f}s")
        for i, (p, txt) in enumerate(zip(prompts, texts), 1):
            out.append(f"\n-- sample {i} --\nPROMPT: {p}\nCONTINUATION: {txt}")
            if stats is not None:
                o = stats["open_rate"][i - 1]
                r = stats["rec_count"][i - 1]
                out.append(f"(gate open mean {sum(o)/len(o):.3f}, "
                           f"recruited/token {sum(r)/len(r):.2f})")
        del model
        torch.cuda.empty_cache()

    text = "\n".join(out)
    dest = RESULTS / "samples_from_ckpt.txt"
    dest.write_text(text, encoding="utf-8")
    print(text)
    print(f"\nsaved -> {dest}")


if __name__ == "__main__":
    main()
