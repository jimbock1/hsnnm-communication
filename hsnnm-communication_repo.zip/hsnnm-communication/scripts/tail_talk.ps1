$host.UI.RawUI.WindowTitle = 'TALK wiki (talkwiki_s0)'
Write-Host 'talkwiki_s0 - live log (Ctrl+C detaches view; training keeps running)' -ForegroundColor Cyan
Get-Content -Path (Join-Path $PSScriptRoot '..\logs\talkwiki_s0.log') -Wait -Tail 18
