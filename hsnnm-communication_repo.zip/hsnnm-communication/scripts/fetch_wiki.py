"""Stream Wikipedia (20231101.en) into a local JSONL corpus of ~505M chars."""
_REPO = __import__("pathlib").Path(__file__).resolve().parents[1]
import json
import sys
import time
from pathlib import Path

from datasets import load_dataset

OUT = (_REPO / "data/wiki_20231101.jsonl")
META = OUT.with_suffix(".meta.json")
TARGET_CHARS = 505_000_000

OUT.parent.mkdir(parents=True, exist_ok=True)


def main() -> None:
    ds = load_dataset("wikimedia/wikipedia", "20231101.en", split="train",
                      streaming=True)
    total = 0
    n_docs = 0
    t0 = time.time()
    last_print = 0
    with open(OUT, "w", encoding="utf-8") as f:
        for row in ds:
            text = (row.get("text") or "").strip()
            if len(text) < 200:
                continue
            f.write(json.dumps({"title": row.get("title"), "text": text},
                               ensure_ascii=False) + "\n")
            total += len(text)
            n_docs += 1
            if total - last_print >= 10_000_000:
                last_print = total
                rate = total / max(1e-9, time.time() - t0)
                print(f"{total/1e6:.0f}M chars, {n_docs} docs, "
                      f"{rate/1e3:.0f}k chars/s, "
                      f"eta {(TARGET_CHARS-total)/max(1, rate)/60:.0f} min",
                      flush=True)
            if total >= TARGET_CHARS:
                break
    meta = {"dataset": "wikimedia/wikipedia", "config": "20231101.en",
            "split": "train", "chars": total, "docs": n_docs,
            "elapsed_s": round(time.time() - t0, 1)}
    META.write_text(json.dumps(meta, indent=2), encoding="utf-8")
    print(f"done: {total} chars, {n_docs} docs -> {OUT}", flush=True)


if __name__ == "__main__":
    main()
