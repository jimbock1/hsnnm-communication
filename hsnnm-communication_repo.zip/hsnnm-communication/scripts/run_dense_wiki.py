"""Run densewiki_s0 alone (deferred from the v3 queue)."""
_REPO = __import__("pathlib").Path(__file__).resolve().parents[1]
import os
import subprocess
import time
from pathlib import Path

PY = __import__("sys").executable
WORK = str(_REPO / "TALK")
ROOT = (_REPO)
LOGS = ROOT / "logs"

env = dict(os.environ)
env["TALK_RESULTS"] = str(ROOT / "results")
for k in ("TALK_NO_SAMPLER", "TALK_GEN_DEBUG", "TALK_FAULTHANDLER"):
    env.pop(k, None)

cmd = [PY, "-u", "train.py", "--run-name", "densewiki_s0",
       "--model", "dense", "--seed", "0",
       "--corpus", str(_REPO / "data/wiki_20231101.jsonl"),
       "--prompts", str(_REPO / "scripts/prompts_wiki.txt"),
       "--steps", "58342", "--ckpt-interval", "5834"]

lf = open(LOGS / "densewiki_s0.log", "ab")
t0 = time.time()
p = subprocess.Popen(cmd, cwd=WORK, env=env, stdout=lf,
                     stderr=subprocess.STDOUT)
lf.close()
with open(LOGS / "queue_v3.log", "a", encoding="utf-8") as f:
    f.write(f"[{time.strftime('%H:%M:%S')}] start densewiki_s0 (pid {p.pid})\n")
rc = p.wait()
with open(LOGS / "queue_v3.log", "a", encoding="utf-8") as f:
    f.write(f"[{time.strftime('%H:%M:%S')}] densewiki_s0 rc={rc} "
            f"after {(time.time()-t0)/60:.1f} min\n")
