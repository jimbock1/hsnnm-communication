"""Queue for the Wikipedia corpus runs: TALK (gate fix) + HSNNM + dense."""
_REPO = __import__("pathlib").Path(__file__).resolve().parents[1]
import os
import subprocess
import time
from pathlib import Path

PY = __import__("sys").executable
WORK = str(_REPO / "TALK")
ROOT = (_REPO)
RESULTS = ROOT / "results"
LOGS = ROOT / "logs"
CORPUS = str(_REPO / "data/wiki_20231101.jsonl")
PROMPTS = str(_REPO / "scripts/prompts_wiki.txt")
MAX_CONCURRENT = 2
STEPS = "58342"          # 2 epochs x 29,171 steps (479.8M tokens/epoch)
CKPT = "5834"            # 1/5 epoch ~= 95.6M tokens

COMMON = ["--corpus", CORPUS, "--prompts", PROMPTS,
          "--steps", STEPS, "--ckpt-interval", CKPT]

JOBS = [
    ("talkwiki_s0", ["--model", "talk", "--seed", "0",
                     "--gate-init-std", "1.0"]),
    ("hsnnmwiki_s0", ["--model", "hsnnm", "--seed", "0"]),
    ("densewiki_s0", ["--model", "dense", "--seed", "0"]),
]


def log(msg: str) -> None:
    line = f"[{time.strftime('%H:%M:%S')}] {msg}"
    print(line, flush=True)
    with open(LOGS / "queue_v3.log", "a", encoding="utf-8") as f:
        f.write(line + "\n")


def main() -> None:
    LOGS.mkdir(parents=True, exist_ok=True)
    env = dict(os.environ)
    env["TALK_RESULTS"] = str(RESULTS)
    for k in ("TALK_NO_SAMPLER", "TALK_GEN_DEBUG", "TALK_FAULTHANDLER"):
        env.pop(k, None)

    pending = list(JOBS)
    running = {}
    failures = []
    log(f"queue v3 start: {len(pending)} jobs, corpus={CORPUS}, steps={STEPS}")

    while pending or running:
        while pending and len(running) < MAX_CONCURRENT:
            name, extra = pending.pop(0)
            cmd = [PY, "-u", "train.py", "--run-name", name, *extra, *COMMON]
            lf = open(LOGS / f"{name}.log", "ab")
            p = subprocess.Popen(cmd, cwd=WORK, env=env, stdout=lf,
                                 stderr=subprocess.STDOUT)
            lf.close()
            running[name] = (p, time.time())
            log(f"start {name} (pid {p.pid})")

        time.sleep(15)

        for name in list(running):
            p, t0 = running[name]
            rc = p.poll()
            if rc is None:
                continue
            dur = (time.time() - t0) / 60
            del running[name]
            if rc != 0:
                failures.append((name, rc))
                log(f"EXIT {name} rc={rc} after {dur:.1f} min")
            else:
                log(f"done {name} after {dur:.1f} min")

    log(f"queue v3 finished; failures={failures}")
    (ROOT / "queue_v3_done.txt").write_text(
        f"finished {time.strftime('%Y-%m-%d %H:%M:%S')}\n"
        f"failures: {failures}\n", encoding="utf-8")


if __name__ == "__main__":
    main()
