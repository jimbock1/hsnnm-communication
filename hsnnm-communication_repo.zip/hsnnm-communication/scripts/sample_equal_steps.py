"""Wait for TALK's checkpoints and emit equal-step samples against the
preserved HSNNM snapshots (29,170 / 35,004 / 40,838)."""
_REPO = __import__("pathlib").Path(__file__).resolve().parents[1]
import sys
import time
from pathlib import Path

sys.path.insert(0, str(_REPO))
sys.path.insert(0, str(_REPO / "TALK"))
sys.path.insert(0, str(_REPO / "HSNNM"))

import torch  # noqa: E402
import sample_from_ckpt as S  # noqa: E402
import train as T  # noqa: E402
from config import set_seed  # noqa: E402

RESULTS = (_REPO / "results")
TALK_CKPT = RESULTS / "talkwiki_s0" / "ckpt"
HS_CKPT = RESULTS / "_ckpt_preserve" / "hsnnmwiki_s0"
OUT = RESULTS / "samples_equal_steps.txt"
PROMPTS = [p for p in T._load_prompts(
    (_REPO / "scripts/prompts_wiki.txt"))][:2]
STEPS = [29170, 35004, 40838]


def log(msg: str) -> None:
    print(f"[{time.strftime('%H:%M:%S')}] {msg}", flush=True)


def wait_stable(path: Path) -> None:
    while True:
        if path.exists():
            size = path.stat().st_size
            if size > 0:
                time.sleep(20)
                if path.exists() and path.stat().st_size == size:
                    return
        time.sleep(40)


def sample(run_label: str, ckpt: Path, mtype: str, step: int) -> str:
    payload = torch.load(ckpt, map_location="cpu", weights_only=False)
    set_seed(0)
    model, tok = S.build_from_payload(payload, mtype)
    del payload
    torch.cuda.empty_cache()
    texts, stats = T.generate(mtype, model, tok, PROMPTS, n_chars=300,
                              temperature=0.8, top_k=40, seed=1234)
    lines = [f"## {run_label} | step {step}"]
    for i, (p, txt) in enumerate(zip(PROMPTS, texts), 1):
        lines.append(f"\n-- sample {i} --\nPROMPT: {p}\nCONTINUATION: {txt}")
        if stats is not None:
            o = stats["open_rate"][i - 1]
            lines.append(f"(gate open mean {sum(o)/len(o):.3f})")
    del model
    torch.cuda.empty_cache()
    return "\n".join(lines)


def main() -> None:
    log("waiting for TALK checkpoints: " +
        ", ".join(str(s) for s in STEPS))
    for step in STEPS:
        talk = TALK_CKPT / f"step_{step:06d}.pt"
        hs = HS_CKPT / f"step_{step:06d}.pt"
        if not hs.exists():
            log(f"missing preserved HSNNM step {step}")
            continue
        wait_stable(talk)
        log(f"both ready at step {step}; generating")
        for attempt in range(3):
            try:
                block_hs = sample("hsnnmwiki_s0", hs, "hsnnm", step)
                block_tk = sample("talkwiki_s0", talk, "talk", step)
                with open(OUT, "a", encoding="utf-8") as f:
                    f.write(f"\n\n# ===== step {step} =====\n")
                    f.write(block_hs + "\n\n" + block_tk + "\n")
                log(f"wrote samples for step {step}")
                break
            except Exception as e:  # noqa: BLE001
                log(f"step {step} attempt {attempt+1} failed: {e}")
                time.sleep(30)
    log("done")


if __name__ == "__main__":
    main()
