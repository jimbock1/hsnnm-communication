"""Per-position validation ppl for the final wiki checkpoints.

Buckets the next-token loss by position within the 256-token window, so a
long-horizon advantage shows up even when mean ppl is identical.
"""
_REPO = __import__("pathlib").Path(__file__).resolve().parents[1]
import json
import sys
import time
from pathlib import Path

sys.path.insert(0, str(_REPO))
sys.path.insert(0, str(_REPO / "TALK"))
sys.path.insert(0, str(_REPO / "HSNNM"))

import torch  # noqa: E402
import torch.nn.functional as F  # noqa: E402
import sample_from_ckpt as S  # noqa: E402
import train as T  # noqa: E402

RESULTS = (_REPO / "results")
CORPUS = str(_REPO / "data/wiki_20231101.jsonl")
FINAL = "step_058342.pt"
BUCKETS = [(0, 64), (64, 128), (128, 192), (192, 256)]
MAX_BATCHES = 400


def log(msg: str) -> None:
    print(f"[{time.strftime('%H:%M:%S')}] {msg}", flush=True)


def wait_for(path: Path) -> None:
    while not path.exists():
        time.sleep(30)
    size = path.stat().st_size
    time.sleep(20)
    while path.stat().st_size != size:
        time.sleep(20)
        size = path.stat().st_size


def position_ppl(run: str, mtype: str, ckpt: Path, val_loader) -> dict:
    payload = torch.load(ckpt, map_location="cpu", weights_only=False)
    model, _ = S.build_from_payload(payload, mtype)
    del payload
    model.eval()
    sums = torch.zeros(len(BUCKETS), dtype=torch.float64, device="cuda")
    cnts = torch.zeros(len(BUCKETS), dtype=torch.float64, device="cuda")
    n_batches = 0
    t0 = time.time()
    with torch.no_grad(), torch.autocast(device_type="cuda",
                                         dtype=torch.bfloat16):
        for x, y in val_loader:
            x, y = x.cuda(non_blocking=True), y.cuda(non_blocking=True)
            logits = model(x, update_hebbian=False)[0]
            flat = logits.reshape(-1, logits.size(-1)).float()
            ce = F.cross_entropy(flat, y.reshape(-1), ignore_index=0,
                                 reduction="none").reshape(y.shape)
            mask = (y != 0).float()
            for b, (a, z) in enumerate(BUCKETS):
                ce_b = ce[:, a:z]
                m = mask[:, a:z]
                sums[b] += (ce_b.double() * m).sum()
                cnts[b] += m.sum()
            n_batches += 1
            if n_batches >= MAX_BATCHES:
                break
    del model
    torch.cuda.empty_cache()
    out = {}
    total_s = tot_n = 0.0
    for b, (a, z) in enumerate(BUCKETS):
        s, c = sums[b].item(), cnts[b].item()
        out[f"{a}-{z}"] = {"ppl": float(torch.exp(torch.tensor(s / max(c, 1.0)))),
                           "nll": s / max(c, 1.0), "tokens": int(c)}
        total_s += s
        tot_n += c
    out["overall"] = {"ppl": float(torch.exp(torch.tensor(total_s / max(tot_n, 1)))),
                      "nll": total_s / max(tot_n, 1), "tokens": int(tot_n)}
    log(f"{run}: {n_batches} batches in {time.time()-t0:.1f}s -> "
        + ", ".join(f"{k}={v['ppl']:.3f}" for k, v in out.items()))
    return out


def main() -> None:
    talk_final = RESULTS / "talkwiki_s0" / "ckpt" / FINAL
    log(f"waiting for {talk_final.name}")
    wait_for(talk_final)
    log("final checkpoints ready; building val loader")
    _, _, _, val_loader = T.build_loaders(
        0.1, 256, 64, 0.05, 0, None, CORPUS)
    res = {}
    for run, mtype in (("hsnnmwiki_s0", "hsnnm"), ("talkwiki_s0", "talk")):
        ck = RESULTS / run / "ckpt" / FINAL
        res[run] = position_ppl(run, mtype, ck, val_loader)
    out = RESULTS / "position_ppl.json"
    out.write_text(json.dumps(res, indent=2), encoding="utf-8")

    h, t = res["hsnnmwiki_s0"], res["talkwiki_s0"]
    lines = ["| position | HSNNM ppl | TALK ppl | TALK−HSNNM | rel |",
             "|---|---|---|---|---|"]
    for k in list(h.keys()):
        dh = t[k]["ppl"] - h[k]["ppl"]
        lines.append(f"| {k} | {h[k]['ppl']:.4f} | {t[k]['ppl']:.4f} | "
                     f"{dh:+.4f} | {100*dh/h[k]['ppl']:+.2f}% |")
    text = "\n".join(lines)
    (RESULTS / "position_ppl.md").write_text(text + "\n", encoding="utf-8")
    print(text)
    log("done")


if __name__ == "__main__":
    main()
