$host.UI.RawUI.WindowTitle = 'HSNNM wiki (hsnnmwiki_s0)'
Write-Host 'hsnnmwiki_s0 - live log (Ctrl+C detaches view; training keeps running)' -ForegroundColor Cyan
Get-Content -Path (Join-Path $PSScriptRoot '..\logs\hsnnmwiki_s0.log') -Wait -Tail 18
