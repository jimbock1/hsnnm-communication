"""Paper figures v5 -- every number is read from the run JSONs.

usage: python make_paper_figures_v5.py RESULTS_DIR OUT_DIR
"""
import json
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

RES = Path(sys.argv[1])
OUT = Path(sys.argv[2])
OUT.mkdir(parents=True, exist_ok=True)

plt.rcParams.update({
    "font.family": "serif", "font.serif": ["STIXGeneral", "DejaVu Serif"],
    "mathtext.fontset": "stix", "font.size": 10.5, "axes.labelsize": 10.5,
    "legend.fontsize": 8.8, "xtick.labelsize": 9.5, "ytick.labelsize": 9.5,
    "axes.linewidth": 0.9, "lines.linewidth": 1.6, "figure.dpi": 200,
    "savefig.dpi": 200, "savefig.bbox": "tight",
})
# Okabe-Ito (colour-blind safe)
C = dict(dense="#0072B2", hsnnm="#D55E00", talk="#009E73",
         s1="#56B4E9", s2="#CC79A7", v1="#666666")
SEED = {0: C["talk"], 1: "#E69F00", 2: C["s2"]}


def load(run):
    return json.load(open(RES / f"{run}.json"))


def curve(run):
    ev = load(run)["eval_curve"]
    return ([e["step"] for e in ev], [e["val_ppl"] for e in ev], ev)


def style(ax, xl, yl):
    ax.set_xlabel(xl); ax.set_ylabel(yl)
    ax.grid(alpha=0.25, lw=0.6)
    ax.tick_params(direction="out", length=3)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)


def plain(ax):
    ax.yaxis.set_major_formatter(FuncFormatter(lambda v, _: f"{v:g}"))
    ax.yaxis.set_minor_formatter(FuncFormatter(lambda v, _: ""))


def tag(ax, t, title=""):
    ax.set_title(f"{t}  {title}", loc="left", fontsize=10, fontweight="bold", pad=7)


def rel_to(base_run, run):
    sb, pb, _ = curve(base_run)
    s, p, _ = curve(run)
    d = dict(zip(sb, pb))
    return s, [100 * (pi / d[si] - 1) for si, pi in zip(s, p)]


def train_log(run):
    out = []
    for l in open(RES / run / "log.jsonl"):
        e = json.loads(l)
        if e.get("event") == "train_step":
            out.append(e)
    return out


def final_full(run):
    return load(run)["final_val_ppl_full"]


def end_label(ax, x, y, txt, col, dy=0):
    ax.annotate(txt, xy=(x, y), xytext=(6, dy), textcoords="offset points",
                color=col, fontsize=8.5, va="center", annotation_clip=False)


# ---- Fig 1 / 2: training cross-entropy (starts at step 50) + validation ppl --
def val_figure(runs, xmax, fname, ymax_val, groups, ymax_train=None):
    """runs: list of (run, label, colour, lw). groups: end labels."""
    fig, (a, b) = plt.subplots(1, 2, figsize=(8.2, 3.5))
    for run, lab, col, lw in runs:
        tl = train_log(run)
        a.plot([e["step"] for e in tl], [e["ce"] for e in tl], color=col, lw=lw * 0.8,
               label=lab)
        s, p, _ = curve(run)
        b.plot(s, p, color=col, lw=lw, marker="o" if len(s) < 30 else None, ms=2.6)
    a.set_xlim(0, xmax); a.set_ylim(0, ymax_train)
    style(a, "training step", "training cross-entropy (nats/char)")
    a.legend(frameon=False, loc="upper right"); tag(a, "(a)", "Training cross-entropy")
    first = min(curve(r[0])[0][0] for r in runs)
    b.set_xlim(first, xmax); b.set_ylim(0, ymax_val)
    style(b, "training step", "validation perplexity (subset)")
    tag(b, "(b)", "Validation perplexity (subset)")
    for x, y, txt, col, dy in groups:
        end_label(b, x, y, txt, col, dy)
    fig.tight_layout(); fig.savefig(OUT / fname); plt.close(fig)


ts_runs = [("dense_s0", "dense", C["dense"], 2.0), ("hsnnm_s0", "HSNNM", C["hsnnm"], 2.0)] + \
          [(f"talkv2_s{i}", f"TALK seed {i}", SEED[i], 1.1) for i in range(3)]
def last(r):
    return curve(r)[1][-1]


tks = [last(f"talkv2_s{i}") for i in range(3)]
val_figure(ts_runs, 6100, "fig_val_tinystories.png", 11,
           [(6100, last("dense_s0"), f"dense {last('dense_s0'):.2f}", C["dense"], -13),
            (6100, last("hsnnm_s0"), f"HSNNM {last('hsnnm_s0'):.2f}", C["hsnnm"], 10),
            (6100, min(tks), f"TALK {min(tks):.2f}\u2013{max(tks):.2f}", C["talk"], -2)])
wk_runs = [("densewiki_s0", "dense", C["dense"], 1.6), ("hsnnmwiki_s0", "HSNNM", C["hsnnm"], 1.6),
           ("talkwiki_s0", "TALK", C["talk"], 1.6)]
val_figure(wk_runs, 58342, "fig_val_wiki.png", 13,
           [(58342, last("densewiki_s0"), f"dense {last('densewiki_s0'):.2f}", C["dense"], -9),
            (58342, last("hsnnmwiki_s0"), f"HSNNM {last('hsnnmwiki_s0'):.2f}", C["hsnnm"], 13),
            (58342, last("talkwiki_s0"), f"TALK {last('talkwiki_s0'):.2f}", C["talk"], 2)],
           ymax_train=4)

# ---- Fig 3: gate-open rate (training-batch rate from step 50) -------------
fig, (a, b, c) = plt.subplots(1, 3, figsize=(10.4, 3.3))
for i in range(3):
    s, _, ev = curve(f"talk_s{i}")
    a.plot(s, [e["gate_open_rate_overall"] for e in ev], color=C["v1"], lw=2.0, ls="--",
           marker="o", ms=2.6, label="first gate (3 seeds, validation)" if i == 0 else None)
    tl = train_log(f"talkv2_s{i}")
    a.plot([e["step"] for e in tl], [e["open_rate_train"] for e in tl], color=SEED[i],
           lw=1.4, label=f"repaired gate, seed {i}")
a.set_xlim(0, 6100); a.set_ylim(0, 1)
style(a, "training step", "fraction of tokens with gate open")
a.legend(frameon=False, loc="center right", bbox_to_anchor=(1.0, 0.3), fontsize=7.8); tag(a, "(a)", "TinyStories gate-open rate")
tl = train_log("talkwiki_s0")
b.plot([e["step"] for e in tl], [e["open_rate_train"] for e in tl], color=C["talk"], lw=1.6)
b.set_xlim(0, 58342); b.set_ylim(0, 1)
style(b, "training step", "fraction of tokens with gate open"); tag(b, "(b)", "Wikipedia gate-open rate")
s, _, ev = curve("talkwiki_s0")
cols = ["#0072B2", "#E69F00", "#CC79A7", "#D55E00"]
for L in range(4):
    c.plot(s, [e["gate_open_rate_per_layer"][L] for e in ev], color=cols[L], lw=1.3,
           label=f"layer {L+1}")
c.set_xlim(0, 58342); c.set_ylim(0, 1)
style(c, "training step", "gate-open fraction (validation)")
c.legend(frameon=False, ncol=2, loc="lower right"); tag(c, "(c)", "Wikipedia, per layer")
fig.tight_layout(); fig.savefig(OUT / "fig_gate.png"); plt.close(fig)

# ---- Fig 4: per-position (zero-based bars, differences written as labels) --
pos = json.load(open(RES / "position_ppl.json"))
keys = ["0-64", "64-128", "128-192", "192-256", "overall"]
h = [pos["hsnnmwiki_s0"][k]["ppl"] for k in keys]
t = [pos["talkwiki_s0"][k]["ppl"] for k in keys]
rel = [100 * (ti - hi) / hi for hi, ti in zip(h, t)]
lab = ["0–64", "64–128", "128–192", "192–256", "overall"]
fig, a = plt.subplots(figsize=(6.4, 3.5))
x = list(range(len(keys))); w = 0.38
a.bar([i - w/2 for i in x], h, w, color=C["hsnnm"], label="HSNNM")
a.bar([i + w/2 for i in x], t, w, color=C["talk"], label="TALK")
for i in x:
    a.text(i, max(h[i], t[i]) + 0.08, f"TALK {rel[i]:+.2f}%", ha="center", fontsize=8.5)
a.set_xticks(x); a.set_xticklabels(lab); a.set_ylim(0, 5.3)
style(a, "token position in the 256-token window", "validation perplexity")
a.legend(frameon=False, loc="upper right", ncol=2)
tag(a, "", "Wikipedia validation perplexity by token position (TALK vs HSNNM)")
fig.tight_layout(); fig.savefig(OUT / "fig_position.png"); plt.close(fig)

# ---- Fig 5: nominal FLOPs vs measured training time (relative to dense) ----
def stats(dense, hs, talks, key):
    d = load(dense); H = load(hs); T = [load(x) for x in talks]
    return d, H, T
ts = stats("dense_s0", "hsnnm_s0", [f"talkv2_s{i}" for i in range(3)], None)
wk = stats("densewiki_s0", "hsnnmwiki_s0", ["talkwiki_s0"], None)


def rel_vals(trip):
    d, H, T = trip
    fl_d = d["flops"]["dense"]
    fl = [H["flops"]["hsnnm"] / fl_d,
          sum(t["flops"]["talk_at_measured_open_rate"] for t in T) / len(T) / fl_d]
    tt = [H["train_time_s"] / d["train_time_s"],
          sum(t["train_time_s"] for t in T) / len(T) / d["train_time_s"]]
    tt_each = [t["train_time_s"] / d["train_time_s"] for t in T]
    return fl, tt, tt_each


fig, (a, b) = plt.subplots(1, 2, figsize=(7.8, 3.5), sharey=False)
groups = [("TinyStories\n(100M tokens)", rel_vals(ts)), ("Wikipedia\n(956M tokens)", rel_vals(wk))]
w = 0.34
for ax, idx, yl in [(a, 0, "nominal FLOPs per token\n(relative to dense)"),
                    (b, 1, "training time\n(relative to dense)")]:
    ax.axhline(1.0, color=C["dense"], lw=1.6, ls="--", label="dense = 1")
    for g, (name, vals) in enumerate(groups):
        v = vals[idx]
        ax.bar(g - w/2, v[0], w, color=C["hsnnm"], label="HSNNM" if g == 0 else None)
        ax.bar(g + w/2, v[1], w, color=C["talk"], label="TALK" if g == 0 else None)
        ax.text(g - w/2, v[0] + 0.1, f"{v[0]:.2f}×", ha="center", fontsize=9)
        ax.text(g + w/2, v[1] + 0.1, f"{v[1]:.2f}×", ha="center", fontsize=9)
        if idx == 1 and len(vals[2]) > 1:
            ax.scatter([g + w/2] * len(vals[2]), vals[2], color="k", s=9, zorder=3)
    ax.set_xticks([0, 1]); ax.set_xticklabels([g[0] for g in groups])
    ax.set_ylim(0, 13 if idx else 1.6); ax.set_xlim(-0.6, 1.6)
    style(ax, "", yl)
a.legend(frameon=False, loc="upper right")
tag(a, "(a)", "FLOPs per token (nominal)"); tag(b, "(b)", "Training time (measured)")
b.legend(frameon=False, loc="upper right", bbox_to_anchor=(1.0, 1.0))
b.text(-0.55, 12.8, "dots: individual TALK seeds\n(seed 2 shared the GPU for longer)", fontsize=8, va="top")
fig.tight_layout(); fig.savefig(OUT / "fig_flops_wall.png"); plt.close(fig)

for p in sorted(OUT.glob("fig_*.png")):
    print(p.name, round(p.stat().st_size / 1024), "KB")
