Add-Type -AssemblyName System.Windows.Forms
Add-Type @"
using System;
using System.Runtime.InteropServices;
public class W {
  [DllImport("user32.dll")] public static extern bool MoveWindow(IntPtr h, int x, int y, int w, int hh, bool repaint);
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
}
"@

$logs = (Join-Path $PSScriptRoot "..\logs")
$screen = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds
$half = [int]($screen.Width / 2)

function Start-Tail($title, $logPath) {
    $cmd = "`$host.UI.RawUI.WindowTitle='$title'; " +
           "Write-Host 'live log - Ctrl+C to stop watching' -ForegroundColor Cyan; " +
           "Get-Content -Path '$logPath' -Wait -Tail 18"
    return Start-Process powershell -PassThru -WindowStyle Normal `
        -ArgumentList '-NoExit', '-NoProfile', '-Command', $cmd
}

$p1 = Start-Tail "TALK wiki (talkwiki_s0)" "$logs\talkwiki_s0.log"
$p2 = Start-Tail "HSNNM wiki (hsnnmwiki_s0)" "$logs\hsnnmwiki_s0.log"
Start-Sleep -Seconds 3

foreach ($entry in @(@($p1, 0), @($p2, $half))) {
    $proc = Get-Process -Id $entry[0].Id -ErrorAction SilentlyContinue
    if ($proc -and $proc.MainWindowHandle -ne 0) {
        [W]::MoveWindow($proc.MainWindowHandle, $entry[1], 40, $half, 700, $true) | Out-Null
    }
}

Start-Sleep -Milliseconds 500
$p2ref = Get-Process -Id $p2.Id -ErrorAction SilentlyContinue
if ($p2ref -and $p2ref.MainWindowHandle -ne 0) {
    [W]::SetForegroundWindow($p2ref.MainWindowHandle) | Out-Null
}
