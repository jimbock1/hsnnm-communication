#!/usr/bin/env python3
"""
run_pipeline.py — One-command end-to-end Phase 1 pipeline.

Run this ONCE. It will:
  1. Train the baseline model
  2. Train the novel model
  3. Compare them (loss curves + FLOPs)
  4. Run forgetting test on baseline
  5. Run forgetting test on novel
  6. Generate Hebbian strength maps for the novel model
  7. Write a final summary report

Total time: ~5 hours on RX 9060 XT.

Usage:
    python run_pipeline.py                    # full pipeline, no skipping
    python run_pipeline.py --skip-train       # skip training (use existing runs/)
    python run_pipeline.py --skip-baseline    # only train + eval novel
    python run_pipeline.py --task-steps 500   # custom forgetting test length
    python run_pipeline.py --dry-run          # print plan, don't execute

If training crashes mid-run, just re-run the script. It auto-resumes from
the last checkpoint if one exists (uses --resume flag).
"""
from __future__ import annotations

import argparse
import logging
import subprocess
import sys
import time
from pathlib import Path

# =====================================================================
# Pipeline configuration
# =====================================================================

PROJECT_ROOT = Path(__file__).resolve().parent
DOWNLOAD_DIR = PROJECT_ROOT / "download"
DOWNLOAD_DIR.mkdir(exist_ok=True)

# Each stage: (name, estimated_minutes, command_builder)
# command_builder is a function that takes the args namespace and returns
# a list of strings suitable for subprocess.run.

def baseline_cmd(args):
    cmd = [sys.executable, "-m", "training.train",
           "--config", "configs/phase1_baseline.yaml"]
    baseline_ckpt = PROJECT_ROOT / "runs" / "phase1_baseline" / "latest.pt"
    if args.resume and baseline_ckpt.exists():
        cmd += ["--resume", str(baseline_ckpt)]
    return cmd

def novel_cmd(args):
    cmd = [sys.executable, "-m", "training.train",
           "--config", "configs/phase1_novel.yaml"]
    novel_ckpt = PROJECT_ROOT / "runs" / "phase1_novel" / "latest.pt"
    if args.resume and novel_ckpt.exists():
        cmd += ["--resume", str(novel_ckpt)]
    return cmd

def compare_cmd(args):
    return [sys.executable, "-m", "evaluation.compare",
            "--baseline", "runs/phase1_baseline",
            "--novel", "runs/phase1_novel",
            "--out", "download/comparison_phase1"]

def forget_baseline_cmd(args):
    return [sys.executable, "-m", "evaluation.forgetting_test",
            "--config", "configs/forget_A_baseline.yaml",
            "--task-a-steps", str(args.task_steps),
            "--task-b-steps", str(args.task_steps),
            "--out", "download/forgetting_baseline"]

def forget_novel_cmd(args):
    return [sys.executable, "-m", "evaluation.forgetting_test",
            "--config", "configs/forget_A.yaml",
            "--task-a-steps", str(args.task_steps),
            "--task-b-steps", str(args.task_steps),
            "--out", "download/forgetting_novel"]

def strength_map_cmd(args):
    cmd = [sys.executable, "-m", "evaluation.strength_map",
           "--ckpt", "runs/phase1_novel/final.pt",
           "--run-dir", "runs/phase1_novel",
           "--out", "download/strength_map_phase1"]
    return cmd

# =====================================================================
# Stage runner
# =====================================================================

def run_stage(name: str, cmd: list, est_minutes: float, dry_run: bool = False) -> bool:
    """Run one pipeline stage. Returns True on success, False on failure."""
    print("\n" + "=" * 70)
    print(f"STAGE: {name}")
    print(f"  Estimated time: ~{est_minutes:.0f} min")
    print(f"  Command: {' '.join(cmd)}")
    print("=" * 70)

    if dry_run:
        print("  [DRY RUN] skipping execution")
        return True

    t0 = time.time()
    try:
        # Run from project root so relative paths work
        result = subprocess.run(cmd, cwd=PROJECT_ROOT, check=False)
        elapsed_min = (time.time() - t0) / 60
        if result.returncode != 0:
            print(f"\n  FAILED ({result.returncode}) after {elapsed_min:.1f} min")
            return False
        print(f"\n  Completed in {elapsed_min:.1f} min")
        return True
    except KeyboardInterrupt:
        print(f"\n  INTERRUPTED by user after {(time.time() - t0)/60:.1f} min")
        raise
    except Exception as e:
        print(f"\n  EXCEPTION: {e}")
        return False


# =====================================================================
# Final report
# =====================================================================

def write_final_report(stages_run: list, total_minutes: float) -> None:
    """Write a summary report of what ran and where the outputs are."""
    report_path = DOWNLOAD_DIR / "PIPELINE_REPORT.txt"
    lines = [
        "=" * 70,
        "PHASE 1 PIPELINE — FINAL REPORT",
        "=" * 70,
        f"Total wall-clock time: {total_minutes/60:.2f} hours",
        f"Stages completed: {sum(1 for s in stages_run if s[1])}/{len(stages_run)}",
        "",
        "Stage results:",
    ]
    for name, success in stages_run:
        status = "OK" if success else "FAILED"
        lines.append(f"  [{status}] {name}")

    lines.extend([
        "",
        "Output files (in download/):",
    ])
    for f in sorted(DOWNLOAD_DIR.iterdir()):
        if f.is_file() and f.name != "PIPELINE_REPORT.txt":
            size_kb = f.stat().st_size / 1024
            lines.append(f"  {f.name:50s} ({size_kb:.1f} KB)")

    lines.extend([
        "",
        "What to look at first:",
        "  1. download/comparison_phase1.txt — text report of baseline vs novel",
        "  2. download/comparison_phase1.png  — loss curves + FLOPs-vs-loss plot",
        "  3. download/forgetting_baseline/forgetting_result.json",
        "  4. download/forgetting_novel/forgetting_result.json",
        "     -> Compare the 'forgetting' field between these two. The smaller",
        "        number is the winner. This is the actual hypothesis test.",
        "  5. download/strength_map_phase1_*.png — Hebbian specialization heatmaps",
        "",
        "If you want to share results:",
        "  - The .txt report is copy-pasteable",
        "  - The .png files are blog-post-ready",
        "  - The .json files have raw numbers for further analysis",
        "",
    ])
    report_path.write_text("\n".join(lines))
    print(f"\nFinal report written to: {report_path}")


# =====================================================================
# Main
# =====================================================================

def main():
    parser = argparse.ArgumentParser(description="Run full Phase 1 pipeline end-to-end.")
    parser.add_argument("--skip-train", action="store_true",
                        help="Skip both training stages (use existing runs/)")
    parser.add_argument("--skip-baseline", action="store_true",
                        help="Skip baseline training + forgetting test")
    parser.add_argument("--skip-novel", action="store_true",
                        help="Skip novel training + forgetting test + strength map")
    parser.add_argument("--skip-compare", action="store_true",
                        help="Skip the comparison step")
    parser.add_argument("--task-steps", type=int, default=1000,
                        help="Number of training steps for each task in the "
                             "forgetting test (default 1000)")
    parser.add_argument("--resume", action="store_true", default=True,
                        help="Auto-resume training from latest checkpoint if it exists "
                             "(default: ON)")
    parser.add_argument("--no-resume", dest="resume", action="store_false",
                        help="Don't auto-resume; start training from scratch")
    parser.add_argument("--dry-run", action="store_true",
                        help="Print the plan without executing anything")
    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

    # Build the pipeline plan
    plan = []
    if not args.skip_train and not args.skip_baseline:
        plan.append(("Train baseline (phase1_baseline.yaml)", 120, baseline_cmd))
    if not args.skip_train and not args.skip_novel:
        plan.append(("Train novel (phase1_novel.yaml)", 120, novel_cmd))
    if not args.skip_compare:
        plan.append(("Compare baseline vs novel", 1, compare_cmd))
    if not args.skip_baseline:
        plan.append(("Forgetting test — baseline", 30, forget_baseline_cmd))
    if not args.skip_novel:
        plan.append(("Forgetting test — novel", 30, forget_novel_cmd))
    if not args.skip_novel:
        plan.append(("Strength maps (Hebbian specialization)", 1, strength_map_cmd))

    total_est = sum(p[1] for p in plan)
    print("\n" + "=" * 70)
    print("PHASE 1 PIPELINE PLAN")
    print("=" * 70)
    for i, (name, est_min, _) in enumerate(plan, 1):
        print(f"  Stage {i}: {name}  (~{est_min} min)")
    print(f"\n  Total estimated time: ~{total_est} min (~{total_est/60:.1f} hours)")
    print(f"  Auto-resume: {'ON' if args.resume else 'OFF'}")
    if args.dry_run:
        print("  Mode: DRY RUN (no execution)")
    print("=" * 70)

    if args.dry_run:
        for name, est_min, cmd_fn in plan:
            run_stage(name, cmd_fn(args), est_min, dry_run=True)
        return

    # Execute
    print("\nStarting pipeline. You can walk away. Come back in ~5 hours.")
    print("Press Ctrl-C at any time to interrupt; re-run the script to resume.")
    t0 = time.time()
    stages_run = []
    for name, est_min, cmd_fn in plan:
        success = run_stage(name, cmd_fn(args), est_min)
        stages_run.append((name, success))
        if not success:
            print(f"\nStage '{name}' failed. Stopping pipeline.")
            print("Fix the issue and re-run the script — it will auto-resume.")
            break

    total_min = time.time() - t0
    write_final_report(stages_run, total_min)

    print(f"\nPipeline finished. Total time: {total_min/60:.2f} hours.")
    print(f"Check download/PIPELINE_REPORT.txt for the summary.")
    print(f"All outputs are in: {DOWNLOAD_DIR}")


if __name__ == "__main__":
    main()
