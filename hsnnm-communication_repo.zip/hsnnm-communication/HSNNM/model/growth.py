"""
model/growth.py — CORE NOVEL COMPONENT #3: net2net-style lobe growth.

Monitors per-lobe saturation signals and, when sustained above thresholds,
adds new neurons to that lobe. New neurons are initialized by *duplicating
an existing high-strength neuron + small noise* (per spec — NOT random init),
so the model's behavior isn't disrupted at the moment of insertion.

*********************************************************************
** MULTI-SIGNAL SATURATION — see addendum #4.                      **
*********************************************************************

The original spec used confidence-gate output alone as the saturation
signal. Problem: high confidence could mean "this lobe is already good at
its job" rather than "this lobe is overloaded and needs more capacity."

The fix combines four signals, all required to stay above their thresholds
over a `persistence_ratio` fraction of the rolling window:

  1. High mean confidence    (lobe thinks it's relevant to most inputs)
  2. High neuron utilization (large fraction of neurons regularly winning k-WTA)
  3. High activation entropy (activations spread out / maxed out, no headroom)
  4. Persistence             (above conditions hold, not just spiking)

*********************************************************************
** COOLDOWN — see addendum #10.                                     **
*********************************************************************

After a growth event, a lobe cannot grow again for `minimum_growth_interval`
steps. Prevents rapid-fire growth from a persistently-saturated lobe.

*********************************************************************
** OPTIMIZER STATE PRESERVATION — see addendum #9.                  **
*********************************************************************

When a lobe grows, Adam's first/second moment buffers for the resized
parameter must be resized too. Existing neurons' moments are copied
unchanged; only the new neurons get fresh zero moments. The optimizer is
NOT reset (that would discard all accumulated momentum for the rest of
the model — a real setback for a model that's been training for a while).

The preservation is implemented in `growth.py` (not in train.py) so the
growth module owns the complete resize operation end-to-end.
"""
from __future__ import annotations

from collections import deque
from typing import List, Optional, Tuple
import logging
import math

import torch
import torch.nn as nn

from config import GrowthConfig, count_parameters

log = logging.getLogger(__name__)


# =====================================================================
# Per-lobe saturation signal tracker
# =====================================================================

class LobeSignalWindow:
    """Rolling window of (confidence, utilization, entropy) for one lobe.

    Each step the LobeLayer's diagnostics produce these three scalars per
    lobe. We push them into a deque of length `window` and expose
    `saturation_score()` returning the persistence-weighted combined score.
    """

    def __init__(self, window: int, persistence_ratio: float):
        self.window = window
        self.persistence_ratio = persistence_ratio
        self.conf = deque(maxlen=window)
        self.util = deque(maxlen=window)
        self.entr = deque(maxlen=window)

    def push(self, confidence: float, utilization: float, entropy: float) -> None:
        self.conf.append(confidence)
        self.util.append(utilization)
        self.entr.append(entropy)

    def ready(self) -> bool:
        return len(self.conf) >= self.window

    def persistence_ratio_for(self, series: deque, threshold: float) -> float:
        """Fraction of the window during which `series` exceeded `threshold`."""
        if not series:
            return 0.0
        return sum(1 for v in series if v >= threshold) / len(series)

    def combined_score(self, cfg: GrowthConfig) -> Tuple[float, dict]:
        """Return (score, detail_dict).

        `score` is the minimum of the three persistence ratios — we require
        ALL THREE signals to be persistently above threshold simultaneously.
        A score >= cfg.persistence_ratio means the lobe is saturated.
        """
        if not self.ready():
            return 0.0, {"status": "warming_up", "filled": len(self.conf)}
        p_conf = self.persistence_ratio_for(self.conf, cfg.confidence_threshold)
        p_util = self.persistence_ratio_for(self.util, cfg.utilization_threshold)
        p_entr = self.persistence_ratio_for(self.entr, cfg.entropy_threshold)
        score = min(p_conf, p_util, p_entr)
        return score, {
            "status": "ready",
            "p_conf": p_conf,
            "p_util": p_util,
            "p_entr": p_entr,
            "score": score,
        }


# =====================================================================
# Growth monitor
# =====================================================================

class GrowthMonitor:
    """Tracks per-lobe saturation and triggers growth when warranted.

    Owns one LobeSignalWindow per (layer, lobe) pair. The training loop
    calls `step(layer_idx, lobe_idx, diagnostics)` every forward pass, and
    `check_and_grow(model, optimizer)` every `check_interval_steps` steps.
    """

    def __init__(self, model, config: GrowthConfig):
        self.cfg = config
        self.model = model
        # Number of layers x lobes-per-layer windows.
        # model.layers[i] is a NovelTransformerBlock; the LobeLayer is at
        # .lobe_layer. Each LobeLayer exposes .num_lobes.
        self.num_layers = len(model.layers)
        self.num_lobes_per_layer = (model.layers[0].lobe_layer.num_lobes
                                     if self.num_layers > 0 else 0)
        self.windows: List[List[LobeSignalWindow]] = [
            [LobeSignalWindow(config.rolling_window, config.persistence_ratio)
             for _ in range(self.num_lobes_per_layer)]
            for _ in range(self.num_layers)
        ]
        # Last step at which each (layer, lobe) was grown. -1 = never.
        self.last_growth_step: List[List[int]] = [
            [-1] * self.num_lobes_per_layer for _ in range(self.num_layers)
        ]
        self.current_step = 0
        # History of growth events for logging / visualization.
        self.events: List[dict] = []

    # ------------------------------------------------------------------
    # Per-step signal push
    # ------------------------------------------------------------------
    def step(self, layer_idx: int, lobe_idx: int,
             confidence: float, utilization: float, entropy: float) -> None:
        """Push one observation into the (layer, lobe) window."""
        if layer_idx >= self.num_layers or lobe_idx >= self.num_lobes_per_layer:
            return
        self.windows[layer_idx][lobe_idx].push(confidence, utilization, entropy)

    def advance_step(self) -> None:
        self.current_step += 1

    # ------------------------------------------------------------------
    # Saturation check
    # ------------------------------------------------------------------
    def check_saturation(self, layer_idx: int, lobe_idx: int) -> Tuple[bool, dict]:
        """Returns (should_grow, detail_dict).

        A lobe should grow iff:
          1. Window is full (warmup complete)
          2. Combined score >= persistence_ratio (all 3 signals persistently high)
          3. Cooldown has elapsed since last growth on this lobe
          4. Growth would not exceed the parameter ceiling
        """
        cfg = self.cfg
        if not cfg.enabled:
            return False, {"status": "growth_disabled"}

        w = self.windows[layer_idx][lobe_idx]
        score, detail = w.combined_score(cfg)
        if score < cfg.persistence_ratio:
            return False, detail

        # Cooldown check
        last = self.last_growth_step[layer_idx][lobe_idx]
        if last >= 0 and (self.current_step - last) < cfg.minimum_growth_interval:
            return False, {**detail, "status": "cooldown",
                           "steps_since_last": self.current_step - last}

        # Parameter ceiling check
        n_new = cfg.neurons_per_growth
        # Each new neuron adds:
        #   - fc1: hidden_dim params (one row)
        #   - fc2: hidden_dim params (one column)
        # Plus the strength buffer (not a param, doesn't count).
        hidden_dim = self.model.config.model.hidden_dim
        added_params = n_new * 2 * hidden_dim
        current = count_parameters(self.model)
        if current + added_params > cfg.param_ceiling:
            log.warning(
                "Growth blocked by param ceiling: lobe (L%d, %d) wants +%d params, "
                "current=%d, ceiling=%d. Lobe is saturated but capped — expected.",
                layer_idx, lobe_idx, added_params, current, cfg.param_ceiling
            )
            return False, {**detail, "status": "capped_at_ceiling",
                           "current_params": current,
                           "would_be": current + added_params}

        return True, {**detail, "status": "grow"}

    # ------------------------------------------------------------------
    # Grow operation
    # ------------------------------------------------------------------
    def grow_lobe(self, layer_idx: int, lobe_idx: int,
                  hebbian_tracker=None, optimizer=None) -> dict:
        """Grow a specific (layer, lobe) by `neurons_per_growth` neurons.

        Steps:
          1. Pick a donor neuron (highest-strength in this lobe).
          2. Call LobeLayer.grow_lobe() which delegates to Lobe.grow_neurons().
          3. Resize the optimizer's moment buffers for the affected params.
          4. Update last_growth_step.
          5. Append to event log.

        # OPT-STATE-PRESERVE: optimizer states for existing neurons are
        # copied unchanged. Only the new neurons get fresh zero moments.
        """
        cfg = self.cfg
        n_new = cfg.neurons_per_growth
        # model.layers[layer_idx] is a NovelTransformerBlock; the LobeLayer
        # is at .lobe_layer; lobes are at .lobe_layer.lobes[lobe_idx].
        layer = self.model.layers[layer_idx].lobe_layer
        lobe = layer.lobes[lobe_idx]

        # 1. Pick donor — argmax of strength (or 0 if strengths are all 0)
        with torch.no_grad():
            s = lobe.strength
            if s.numel() == 0 or s.max() <= 0:
                donor_idx = 0
            else:
                donor_idx = int(s.argmax().item())

        # 2. Capture OLD params BEFORE recreating the Linear. After
        #    Lobe.grow_neurons runs, lobe.fc1 / lobe.fc2 will be NEW Linear
        #    modules with NEW parameter tensors. The OLD tensors are still
        #    referenced by the optimizer's state dict and param_groups, so
        #    we need to swap them out explicitly (see step 3).
        old_fc1_param = lobe.fc1.weight
        old_fc2_param = lobe.fc2.weight
        old_ffn_dim = lobe.ffn_dim
        old_params = {
            "fc1": (old_fc1_param.shape[0], old_fc1_param.shape[1]),
            "fc2": (old_fc2_param.shape[0], old_fc2_param.shape[1]),
        }

        layer.grow_lobe(lobe_idx, n_new, donor_idx=donor_idx,
                        noise_scale=0.01)
        new_ffn_dim = lobe.ffn_dim

        # 3. Resize optimizer state for affected params (Adam exp_avg / exp_avg_sq).
        #    This also swaps the OLD params out of optimizer.param_groups and
        #    inserts the NEW params in their place — otherwise the new params
        #    would never receive gradient updates.
        opt_state_resized = False
        if optimizer is not None:
            opt_state_resized = self._resize_optimizer_state(
                optimizer, lobe, old_fc1_param, old_fc2_param,
                old_ffn_dim, n_new, donor_idx
            )

        # 4. Notify hebbian tracker (currently a no-op, but explicit)
        if hebbian_tracker is not None:
            hebbian_tracker.on_lobe_grown(lobe_idx, new_ffn_dim, donor_idx)

        # 5. Bookkeeping
        self.last_growth_step[layer_idx][lobe_idx] = self.current_step
        event = {
            "step": self.current_step,
            "layer": layer_idx,
            "lobe": lobe_idx,
            "old_ffn_dim": old_ffn_dim,
            "new_ffn_dim": new_ffn_dim,
            "n_new": n_new,
            "donor_idx": donor_idx,
            "donor_strength": lobe.strength[donor_idx].item(),
            "optimizer_state_resized": opt_state_resized,
            "old_param_shapes": old_params,
            "total_params_after": count_parameters(self.model),
        }
        self.events.append(event)
        log.info("GROWTH: %s", event)
        return event

    # ------------------------------------------------------------------
    # Optimizer state resize — addendum #9
    # ------------------------------------------------------------------
    def _resize_optimizer_state(self, optimizer, lobe,
                                old_fc1_param, old_fc2_param,
                                old_ffn_dim: int, n_new: int,
                                donor_idx: int) -> bool:
        """Resize Adam moment buffers for the two resized params of `lobe`,
        AND swap the new params into the optimizer's param_groups.

        For each of {fc1.weight, fc2.weight}:
          - Move optimizer.state[old_param] -> optimizer.state[new_param]
            with buffers padded along the neuron axis (existing entries
            preserved unchanged, new entries zero).
          - Find old_param in optimizer.param_groups[*]['params'] and
            replace it with new_param. Without this step, the new param
            would never receive gradient updates.

        # OPT-STATE-PRESERVE: existing neurons' moments are copied
        # unchanged. Only the new neurons get fresh zero moments.

        Returns True if any state was actually transferred/resized.
        """
        if optimizer is None:
            return False

        resized_any = False
        for old_param, new_param, axis in [
            (old_fc1_param, lobe.fc1.weight, 0),  # fc1: (out=ffn, in=hidden) -> axis 0
            (old_fc2_param, lobe.fc2.weight, 1),  # fc2: (out=hidden, in=ffn) -> axis 1
        ]:
            # 1. Transfer state from old -> new (with buffer resize).
            if old_param in optimizer.state:
                old_state = optimizer.state[old_param]
                new_state = {}
                for key, val in old_state.items():
                    if key in ("exp_avg", "exp_avg_sq"):
                        # Pad with zeros along the neuron axis.
                        pad_shape = list(val.shape)
                        pad_shape[axis] = n_new
                        zeros = torch.zeros(pad_shape, dtype=val.dtype,
                                            device=val.device)
                        new_state[key] = torch.cat([val, zeros], dim=axis)
                        resized_any = True
                    else:
                        # 'step' counter etc. — copy as-is.
                        new_state[key] = val
                optimizer.state[new_param] = new_state
                del optimizer.state[old_param]
            # If old_param had no state, new_param will get state on the
            # next optimizer.step() automatically.

            # 2. Swap the param in optimizer.param_groups[*]['params'].
            for group in optimizer.param_groups:
                new_params = []
                for p in group["params"]:
                    if p is old_param:
                        new_params.append(new_param)
                    else:
                        new_params.append(p)
                group["params"] = new_params

        return resized_any

    # ------------------------------------------------------------------
    # Bulk check — called periodically from the training loop
    # ------------------------------------------------------------------
    def check_and_grow(self, hebbian_tracker=None, optimizer=None) -> List[dict]:
        """Check all lobes for saturation and grow any that warrant it.

        Returns the list of growth events that fired this call.
        """
        if not self.cfg.enabled:
            return []
        events = []
        for li in range(self.num_layers):
            for lj in range(self.num_lobes_per_layer):
                should, _ = self.check_saturation(li, lj)
                if should:
                    ev = self.grow_lobe(li, lj, hebbian_tracker, optimizer)
                    events.append(ev)
        return events

    # ------------------------------------------------------------------
    # Total params — required by spec interface
    # ------------------------------------------------------------------
    def total_params(self, model=None) -> int:
        m = model if model is not None else self.model
        return count_parameters(m)
