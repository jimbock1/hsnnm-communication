"""
model/tokenizer.py — Character-level tokenizer.

Vocabulary is *derived from the training data* (per the spec) — not a fixed
assumed alphabet — so unusual punctuation, accented chars, etc. are handled
correctly. Two reserved IDs:
    0  -> <pad>
    1  -> <unk>      (any char not seen during vocab construction)

The vocab is saved alongside every checkpoint (see training/checkpoint.py) so
decode always matches the vocab the model was trained with.
"""
from __future__ import annotations

from pathlib import Path
from typing import Iterable, List, Sequence
import json


PAD_ID = 0
UNK_ID = 1
SPECIAL_TOKENS = ["<pad>", "<unk>"]


class CharTokenizer:
    """Minimal char-level tokenizer with save/load."""

    def __init__(self, vocab: Sequence[str] | None = None):
        # vocab is an ordered list; index in list == token id.
        # First two slots are reserved.
        if vocab is None:
            self._vocab: List[str] = list(SPECIAL_TOKENS)
            self._stoi: dict = {tok: i for i, tok in enumerate(self._vocab)}
        else:
            assert vocab[:2] == SPECIAL_TOKENS, \
                "Vocab must start with <pad>, <unk> in that order."
            self._vocab = list(vocab)
            self._stoi = {tok: i for i, tok in enumerate(self._vocab)}

    # ------------------------------------------------------------------
    # Construction
    # ------------------------------------------------------------------
    @classmethod
    def from_texts(cls, texts: Iterable[str]) -> "CharTokenizer":
        """Build a vocab from an iterable of strings. Order is determined by
        first-appearance then sorted by codepoint — deterministic so two
        runs on the same data produce identical vocabs."""
        seen = set()
        for text in texts:
            for ch in text:
                seen.add(ch)
        # Deterministic ordering: sorted by codepoint. Specials first.
        ordered = SPECIAL_TOKENS + sorted(seen)
        return cls(vocab=ordered)

    # ------------------------------------------------------------------
    # Encode / decode
    # ------------------------------------------------------------------
    @property
    def vocab_size(self) -> int:
        return len(self._vocab)

    @property
    def pad_id(self) -> int:
        return PAD_ID

    @property
    def unk_id(self) -> int:
        return UNK_ID

    def encode(self, text: str) -> List[int]:
        stoi = self._stoi
        unk = UNK_ID
        return [stoi.get(ch, unk) for ch in text]

    def decode(self, ids: Iterable[int]) -> str:
        vocab = self._vocab
        out = []
        for i in ids:
            i = int(i)
            if i == PAD_ID:
                # Skip padding on decode — it carries no semantic content.
                continue
            if 0 <= i < len(vocab):
                out.append(vocab[i])
            else:
                out.append("<unk>")
        return "".join(out)

    # ------------------------------------------------------------------
    # Serialization — vocab is stored as a JSON list of strings.
    # ------------------------------------------------------------------
    def save(self, path: str | Path) -> None:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(self._vocab, ensure_ascii=False))

    @classmethod
    def load(cls, path: str | Path) -> "CharTokenizer":
        vocab = json.loads(Path(path).read_text())
        return cls(vocab=vocab)

    def to_dict(self) -> dict:
        return {"vocab": list(self._vocab)}

    @classmethod
    def from_dict(cls, d: dict) -> "CharTokenizer":
        return cls(vocab=d["vocab"])
