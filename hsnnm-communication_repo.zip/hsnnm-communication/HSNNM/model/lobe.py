"""
model/lobe.py — CORE NOVEL COMPONENT #1: the Lobe.

A "lobe" is a single self-scoring expert sub-network with internal k-Winners-
Take-All (k-WTA) sparsity. Each lobe has:

  1. A confidence gate: hidden_dim -> 1 scalar, cheap, computed for every
     lobe on every input.
  2. An expert FFN: a 2-layer MLP (hidden_dim -> ffn_dim -> hidden_dim) with
     GELU.
  3. k-WTA inside the FFN: after computing all ffn_dim activations, keep only
     the top-k by magnitude, zero the rest, THEN apply the second linear.

*********************************************************************
** THE TWO LEVELS OF SPARSITY MUST NOT BE CONFLATED. READ THIS.    **
*********************************************************************

  OUTER LEVEL (lobe selection — across lobes):
    Unselected lobes' sub-networks are *not computed at all*. The forward
    pass is genuinely skipped — we index the batch by which lobe each token
    routed to, and only the chosen lobes execute. This is what gives the
    real MoE-style compute savings. Search for `# OUTER-SKIP` comments.

  INNER LEVEL (k-WTA — inside a chosen lobe):
    All ffn_dim neuron activations are computed first, then the top-k mask
    zeros out the rest BEFORE the second linear. This is NOT a real compute
    skip in Phase 1 — the matmul still happens at full width, we just zero
    activations. True sparse-matmul skipping here is a stretch goal. Search
    for `# INNER-NO-SKIP` comments.

The `winning_neuron_mask` returned from forward is consumed by
`model/hebbian.py` to update strength values — only neurons that survived
k-WTA get a strength bump.
"""
from __future__ import annotations

from typing import Tuple, Optional
import math

import torch
import torch.nn as nn
import torch.nn.functional as F


# =====================================================================
# Helpers
# =====================================================================

def kwta_topk_mask(activations: torch.Tensor, k: int) -> torch.Tensor:
    """Build a boolean mask of shape (..., ffn_dim) selecting the top-k
    activations by magnitude along the last dim.

    # INNER-NO-SKIP: this is applied AFTER the dense matmul. The matmul
    # still computes every neuron; this mask just zeros most of them.

    `k` is clamped to [1, ffn_dim-1]. We never keep 0 (would zero the whole
    layer) and never keep all (would defeat the sparsity purpose).
    """
    ffn_dim = activations.shape[-1]
    k = max(1, min(k, ffn_dim - 1))
    # topk over magnitude; .values gives the k-th largest magnitude. Then
    # mask = magnitude >= threshold. We use >= not > so ties at the boundary
    # are kept (rare with continuous activations, but defensible).
    mag = activations.abs()
    if k >= ffn_dim:
        return torch.ones_like(activations, dtype=torch.bool)
    kth_val = mag.topk(k, dim=-1).values[..., -1:]
    mask = mag >= kth_val
    return mask


# =====================================================================
# Single lobe
# =====================================================================

class Lobe(nn.Module):
    """One expert sub-network + its confidence gate.

    The forward returns:
      output                (B', hidden_dim)  — the lobe's contribution
                                                for the B' tokens routed
                                                to it (B' may be < B).
      confidence_score      (B', 1)           — gate output for these tokens
      winning_neuron_mask   (B', ffn_dim) bool — which neurons survived k-WTA

    The caller (lobe_layer.py / novel_model.py) is responsible for combining
    outputs across chosen lobes and scattering them back to the original
    (B, T) layout.
    """

    def __init__(
        self,
        hidden_dim: int,
        ffn_dim: int,
        kwta_ratio: float = 0.2,
        use_kwta: bool = True,
    ):
        super().__init__()
        self.hidden_dim = hidden_dim
        self.ffn_dim = ffn_dim
        self.use_kwta = use_kwta
        # k = ceil(ffn_dim * ratio). Stored as int — fixed at construction.
        # Growth can change ffn_dim, in which case k is recomputed.
        self._set_k(ffn_dim, kwta_ratio)

        # --- Confidence gate (cheap) ---
        self.gate = nn.Linear(hidden_dim, 1, bias=True)
        # Init gate to small values so initial routing isn't dominated by
        # one lobe.
        nn.init.normal_(self.gate.weight, mean=0.0, std=0.02)
        nn.init.zeros_(self.gate.bias)

        # --- Expert FFN ---
        self.fc1 = nn.Linear(hidden_dim, ffn_dim, bias=False)
        self.fc2 = nn.Linear(ffn_dim, hidden_dim, bias=False)
        nn.init.normal_(self.fc1.weight, mean=0.0, std=0.02)
        nn.init.normal_(self.fc2.weight, mean=0.0, std=0.02)

        # Strength buffer (set externally by HebbianTracker via set_strength).
        # Shape (ffn_dim,). Registered as buffer so it moves with .to(device)
        # but is NOT a parameter (not updated by backprop).
        self.register_buffer("strength", torch.zeros(ffn_dim))

        # Track whether this lobe's FFN was actually executed in the last
        # forward — used by tests and by saturation monitoring. Updated
        # only when forward_subnetwork is called.
        self.last_executed = False

    def _set_k(self, ffn_dim: int, kwta_ratio: float) -> None:
        self.kwta_k = max(1, int(math.ceil(ffn_dim * kwta_ratio)))

    # ------------------------------------------------------------------
    # Forward primitives
    # ------------------------------------------------------------------
    def compute_confidence(self, x: torch.Tensor) -> torch.Tensor:
        """Cheap gate score. x: (..., hidden_dim) -> (..., 1).

        Always computed for every lobe on every input — that's the cost of
        the routing decision. Sigmoid so the score is in (0, 1) and can be
        interpreted as 'confidence'.
        """
        return torch.sigmoid(self.gate(x))

    def forward_subnetwork(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """Run the FFN with k-WTA applied internally.

        x: (B', hidden_dim)
        returns:
          output: (B', hidden_dim)
          winning_neuron_mask: (B', ffn_dim) bool  — which neurons survived

        # INNER-NO-SKIP: all ffn_dim activations are computed by fc1 first,
        # then the mask zeros most of them, then fc2 runs. This is the
        # documented non-skip behavior for the inner level.

        Strength modulation: the activation is multiplied by (1 + strength)
        BEFORE k-WTA selection, so high-strength neurons have larger
        magnitudes and are more likely to be in the top-k. This is how
        Hebbian tracking influences behavior. The scaling is differentiable
        w.r.t. base weights (strength is a buffer, treated as a constant
        during backprop).
        """
        self.last_executed = True
        h = self.fc1(x)                                  # (B', ffn_dim)
        a = F.gelu(h)                                    # (B', ffn_dim)

        # Hebbian strength modulation (differentiable w.r.t. weights;
        # strength is a buffer treated as constant).
        # Reshape strength to broadcast over batch dim.
        a = a * (1.0 + self.strength)                    # (B', ffn_dim)

        if self.use_kwta:
            mask = kwta_topk_mask(a, self.kwta_k)        # (B', ffn_dim) bool
            a = a * mask.to(a.dtype)                     # zero out losers
        else:
            mask = torch.ones_like(a, dtype=torch.bool)

        out = self.fc2(a)                                # (B', hidden_dim)
        return out, mask

    # ------------------------------------------------------------------
    # Convenience: full forward for a *selected* set of tokens.
    # ------------------------------------------------------------------
    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """Run gate + sub-network on a batch of tokens routed to this lobe.

        Returns (output, confidence_score, winning_neuron_mask).
        """
        conf = self.compute_confidence(x)                # (B', 1)
        out, mask = self.forward_subnetwork(x)
        return out, conf, mask

    # ------------------------------------------------------------------
    # Growth support — called by model/growth.py
    # ------------------------------------------------------------------
    def grow_neurons(self, n_new: int, donor_strength_idx: int = 0,
                     noise_scale: float = 0.01) -> None:
        """Add n_new neurons to this lobe's FFN.

        New neurons are initialized by *duplicating an existing high-strength
        neuron plus small noise* — per spec, NOT random init — so the model's
        behavior isn't disrupted at the moment of insertion.

        `donor_strength_idx` is the index of the neuron to use as the donor.
        The caller (GrowthMonitor) is responsible for picking a high-strength
        neuron; here we just accept the index.

        Resizes:
          self.fc1.weight   (ffn_dim, hidden_dim) -> (ffn_dim+n_new, hidden_dim)
          self.fc2.weight   (hidden_dim, ffn_dim) -> (hidden_dim, ffn_dim+n_new)
          self.strength     (ffn_dim,)             -> (ffn_dim+n_new,)
        """
        if n_new <= 0:
            return
        device = self.fc1.weight.device
        dtype = self.fc1.weight.dtype

        # --- fc1: (out, in) — append rows for new neurons ---
        donor_w1 = self.fc1.weight[donor_strength_idx:donor_strength_idx+1]  # (1, hidden)
        noise1 = torch.randn(n_new, self.hidden_dim, device=device, dtype=dtype) * noise_scale
        new_w1 = donor_w1 + noise1
        new_fc1_w = torch.cat([self.fc1.weight.data, new_w1], dim=0)

        # --- fc2: (out=hidden, in=ffn) — append columns for new neurons ---
        donor_w2 = self.fc2.weight[:, donor_strength_idx:donor_strength_idx+1]  # (hidden, 1)
        noise2 = torch.randn(self.hidden_dim, n_new, device=device, dtype=dtype) * noise_scale
        new_w2 = donor_w2 + noise2
        new_fc2_w = torch.cat([self.fc2.weight.data, new_w2], dim=1)

        # --- strength: copy donor's strength (no noise on strength itself) ---
        donor_s = self.strength[donor_strength_idx:donor_strength_idx+1]
        new_strength = torch.cat([self.strength.data, donor_s.expand(n_new)])

        # Rebuild the linears with the new shape (in-place resize of
        # nn.Linear.weight is awkward — recreation is safer).
        self.fc1 = nn.Linear(self.hidden_dim, self.ffn_dim + n_new, bias=False).to(device=device, dtype=dtype)
        self.fc2 = nn.Linear(self.ffn_dim + n_new, self.hidden_dim, bias=False).to(device=device, dtype=dtype)
        with torch.no_grad():
            self.fc1.weight.copy_(new_fc1_w)
            self.fc2.weight.copy_(new_fc2_w)

        # Strength is a buffer — direct assign works.
        self.strength = new_strength.to(device=device, dtype=dtype)

        self.ffn_dim = self.ffn_dim + n_new
        self._set_k(self.ffn_dim, self.kwta_k / max(1, self.ffn_dim - n_new))  # preserve ratio
        # ^ _set_k recomputes k from current ffn_dim and the saved ratio.
        # We pass the original ratio back; the math in _set_k redoes the ceil.

    def reset_execution_flag(self) -> None:
        self.last_executed = False

    # ------------------------------------------------------------------
    # Extra info exposed for tests / debugging.
    # ------------------------------------------------------------------
    def extra_repr(self) -> str:
        return (f"hidden_dim={self.hidden_dim}, ffn_dim={self.ffn_dim}, "
                f"kwta_k={self.kwta_k}, use_kwta={self.use_kwta}")


# =====================================================================
# Lobe layer — the per-block wrapper that handles routing
# =====================================================================

class LobeLayer(nn.Module):
    """A stack of N lobes that replaces a single dense FFN in a transformer
    block. Handles routing (top-k lobe selection), real outer compute-skip,
    and combining outputs.

    Routing modes (per AblationConfig.routing_mode):
      "learned" — top-k lobes by confidence score (default; the only mode
                  that gives real compute savings proportional to (1 - top_k/N))
      "random"  — random top-k per token (sanity check)
      "dense"   — all lobes always run (isolates effect of sparsity itself;
                  no compute saving)

    Output combination (when top_k > 1):
      Weighted sum over selected lobes by softmax(confidence scores).
      When top_k == 1, no weighting needed — the single lobe's output IS
      the layer's output (modulo residual).
    """

    def __init__(
        self,
        hidden_dim: int,
        ffn_dim: int,
        num_lobes: int,
        top_k: int,
        kwta_ratio: float,
        use_kwta: bool = True,
        routing_mode: str = "learned",
    ):
        super().__init__()
        self.hidden_dim = hidden_dim
        self.num_lobes = num_lobes
        self.top_k = max(1, min(top_k, num_lobes))
        self.routing_mode = routing_mode
        self.kwta_ratio = kwta_ratio
        self.use_kwta = use_kwta

        self.lobes = nn.ModuleList([
            Lobe(hidden_dim, ffn_dim, kwta_ratio, use_kwta=use_kwta)
            for _ in range(num_lobes)
        ])

    # ------------------------------------------------------------------
    # Routing decisions
    # ------------------------------------------------------------------
    def _route(self, x_flat: torch.Tensor) -> torch.Tensor:
        """Return lobe indices of shape (B*T, top_k) for the flattened input.

        x_flat: (N, hidden_dim), N = B*T
        Returns: long tensor (N, top_k) in [0, num_lobes).

        For each routing mode:
          "learned" — compute every lobe's gate (cheap), take top-k per row
          "random"  — random sample of k distinct lobes per row
          "dense"   — all lobes for every row (top_k is forced to num_lobes)
        """
        N = x_flat.shape[0]
        device = x_flat.device

        if self.routing_mode == "dense":
            # All lobes always — return a (N, num_lobes) tile.
            idx = torch.arange(self.num_lobes, device=device).unsqueeze(0).expand(N, -1)
            # Override top_k for this forward so the rest of the code knows.
            self._effective_top_k = self.num_lobes
            return idx

        if self.routing_mode == "random":
            # Sample k distinct lobe indices per row. torch.randint gives
            # independent samples; for distinctness we use torch.topk on a
            # random score tensor.
            rand_scores = torch.rand(N, self.num_lobes, device=device)
            idx = rand_scores.topk(self.top_k, dim=-1).indices
            self._effective_top_k = self.top_k
            return idx

        # Default: learned routing. Compute every lobe's gate score.
        # Cost: num_lobes * (hidden_dim + 1) matmuls of size (N, hidden_dim).
        # This is the unavoidable price of routing.
        scores = torch.stack([lobe.compute_confidence(x_flat).squeeze(-1)
                              for lobe in self.lobes], dim=-1)  # (N, num_lobes)
        idx = scores.topk(self.top_k, dim=-1).indices             # (N, top_k)
        self._effective_top_k = self.top_k
        # Stash scores for combine step (weighted sum by softmax confidence).
        self._last_scores = scores
        return idx

    # ------------------------------------------------------------------
    # Forward
    # ------------------------------------------------------------------
    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, dict]:
        """x: (B, T, hidden_dim) -> output: (B, T, hidden_dim).

        Returns (output, diagnostics_dict). Diagnostics include:
          - selected_lobe_indices: (B, T, top_k) long
          - per_lobe_execution_count: list[int] length num_lobes — how many
            tokens each lobe actually processed this forward
          - per_lobe_winning_masks: list[Tensor or None] — winning_neuron_mask
            for each lobe that ran, or None if it didn't run

        # OUTER-SKIP: lobes whose indices are not in `selected` never have
        forward_subnetwork
        # called. We slice the batch by which lobe each token routed to,
        # and only execute the lobes that have at least one token.
        """
        B, T, C = x.shape
        x_flat = x.reshape(B * T, C)
        N = B * T

        # Reset execution flags for diagnostics
        for lobe in self.lobes:
            lobe.reset_execution_flag()

        # --- Routing decision ---
        sel = self._route(x_flat)                              # (N, top_k)
        effective_k = self._effective_top_k

        # Build output accumulator
        out_flat = torch.zeros_like(x_flat)                    # (N, C)
        per_lobe_count = [0] * self.num_lobes
        per_lobe_masks: list = [None] * self.num_lobes
        per_lobe_conf: list = [None] * self.num_lobes

        # For each chosen lobe position (k-th slot in top-k), gather the
        # tokens that selected that lobe at that slot and run the lobe ONLY
        # on those tokens. The same lobe may be selected at multiple slots
        # of the same token (rare with random routing, impossible with
        # topk); we deduplicate per (lobe, token) by processing each slot
        # independently and accumulating.

        # Precompute softmax weights over the top-k for the weighted-sum
        # combine (only meaningful when effective_k > 1 AND routing_mode ==
        # "learned"; for dense and random we use uniform weighting).
        if self.routing_mode == "learned" and effective_k > 1:
            # Gather scores at selected indices
            sel_scores = self._last_scores.gather(-1, sel)     # (N, top_k)
            weights = F.softmax(sel_scores, dim=-1)            # (N, top_k)
        else:
            weights = torch.full((N, effective_k), 1.0 / effective_k,
                                 device=x.device, dtype=x.dtype)

        for k_slot in range(effective_k):
            lobe_ids = sel[:, k_slot]                          # (N,)
            for lobe_idx in range(self.num_lobes):
                token_mask = (lobe_ids == lobe_idx)            # (N,) bool
                if not token_mask.any():
                    continue
                # OUTER-SKIP: only tokens routed to this lobe are passed
                # through its FFN. The lobe's forward_subnetwork is not
                # called at all for tokens it didn't win.
                x_subset = x_flat[token_mask]                  # (N', C)
                lobe = self.lobes[lobe_idx]
                out_sub, mask, _ = self._run_lobe(lobe, x_subset)  # (N', C)
                w = weights[token_mask, k_slot].unsqueeze(-1)  # (N', 1)
                out_flat[token_mask] += w * out_sub

                per_lobe_count[lobe_idx] += int(token_mask.sum().item())
                # Stash one representative winning mask per lobe (last seen).
                per_lobe_masks[lobe_idx] = mask.detach()
                per_lobe_conf[lobe_idx] = lobe.compute_confidence(x_subset).detach()

        out = out_flat.view(B, T, C)

        diagnostics = {
            "selected_lobe_indices": sel.view(B, T, effective_k),
            "per_lobe_execution_count": per_lobe_count,
            "per_lobe_winning_masks": per_lobe_masks,
            "per_lobe_confidence_mean": [
                (c.mean().item() if c is not None else 0.0) for c in per_lobe_conf
            ],
            "effective_top_k": effective_k,
            "routing_mode": self.routing_mode,
        }
        return out, diagnostics

    def _run_lobe(self, lobe: Lobe, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """Wrapper that calls lobe.forward — exists so it can be monkey-
        patched in tests to detect unwanted calls (the OUTER-SKIP test)."""
        return lobe.forward(x)

    # ------------------------------------------------------------------
    # Growth support
    # ------------------------------------------------------------------
    def grow_lobe(self, lobe_idx: int, n_new: int, donor_idx: int = 0,
                  noise_scale: float = 0.01) -> None:
        """Grow a specific lobe's neuron count. Delegates to Lobe.grow_neurons."""
        self.lobes[lobe_idx].grow_neurons(n_new, donor_idx, noise_scale)

    def lobe_neuron_counts(self) -> list:
        return [l.ffn_dim for l in self.lobes]

    # ------------------------------------------------------------------
    # Hebbian support — expose lobes for strength buffer access
    # ------------------------------------------------------------------
    def get_strength_buffers(self) -> list:
        """Return list of (lobe_idx, strength_tensor) for all lobes."""
        return [(i, l.strength) for i, l in enumerate(self.lobes)]

    def set_strength_buffer(self, lobe_idx: int, value: torch.Tensor) -> None:
        self.lobes[lobe_idx].strength = value
