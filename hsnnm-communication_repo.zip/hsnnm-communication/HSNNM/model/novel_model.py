"""
model/novel_model.py — Full novel model.

Per addendum #1: the novel model is a standard transformer in every respect
EXCEPT the FFN sublayer is replaced by a LobeLayer (which contains N lobes,
each with k-WTA + Hebbian strength modulation). Attention is preserved
untouched — the lobe mechanism does NOT replace attention.

Resulting block structure:
    Input -> LN -> Self-Attention -> Residual
           -> LN -> LobeLayer (replaces dense FFN) -> Residual -> Output

Wires in:
  - HebbianTracker: updates strength buffers after each forward pass,
    based on the winning_neuron_masks returned by each LobeLayer.
  - GrowthMonitor: instantiated but only invoked from the training loop
    (every N steps, not every forward pass).
  - Ablation flags from AblationConfig: toggles use_kwta, use_hebbian,
    use_growth, routing_mode per the ablation matrix in the README.

The forward returns both the logits AND a diagnostics dict — the
diagnostics feed the expanded logging (addendum #12), strength map
visualization, and growth monitor's saturation signals.
"""
from __future__ import annotations

from typing import Tuple, List, Optional
import math

import torch
import torch.nn as nn
import torch.nn.functional as F

from config import Config, count_parameters
from model.embedding import TokenPositionalEmbedding
from model.baseline_model import CausalSelfAttention  # reuse — attention is identical
from model.lobe import LobeLayer
from model.hebbian import HebbianTracker, build_hebbian_tracker
from model.growth import GrowthMonitor


# =====================================================================
# Novel transformer block: attention + LobeLayer (instead of dense FFN)
# =====================================================================

class NovelTransformerBlock(nn.Module):
    """Pre-LN transformer block with LobeLayer as the FFN replacement."""

    def __init__(self, config: Config):
        super().__init__()
        mcfg = config.model
        self.ln1 = nn.LayerNorm(mcfg.hidden_dim, eps=mcfg.layernorm_eps)
        self.attn = CausalSelfAttention(mcfg.hidden_dim, mcfg.num_heads, mcfg.dropout)
        self.ln2 = nn.LayerNorm(mcfg.hidden_dim, eps=mcfg.layernorm_eps)
        self.lobe_layer = LobeLayer(
            hidden_dim=mcfg.hidden_dim,
            ffn_dim=mcfg.ffn_dim,
            num_lobes=mcfg.lobes_per_layer,
            top_k=mcfg.top_k_lobes,
            kwta_ratio=mcfg.kwta_ratio,
            use_kwta=config.ablation.use_kwta,
            routing_mode=config.ablation.routing_mode,
        )
        self.drop = nn.Dropout(mcfg.dropout)

    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, dict]:
        x = x + self.drop(self.attn(self.ln1(x)))
        lobe_out, lobe_diag = self.lobe_layer(self.ln2(x))
        x = x + self.drop(lobe_out)
        return x, lobe_diag


# =====================================================================
# Full novel model
# =====================================================================

class NovelModel(nn.Module):
    """Standard transformer with LobeLayer FFNs + Hebbian + growth hooks."""

    def __init__(self, config: Config):
        super().__init__()
        self.config = config
        mcfg = config.model

        self.embed = TokenPositionalEmbedding(
            vocab_size=mcfg.vocab_size,
            hidden_dim=mcfg.hidden_dim,
            max_seq_len=mcfg.max_seq_len,
            dropout=mcfg.dropout,
        )
        self.layers = nn.ModuleList([
            NovelTransformerBlock(config) for _ in range(mcfg.num_layers)
        ])
        self.ln_f = nn.LayerNorm(mcfg.hidden_dim, eps=mcfg.layernorm_eps)
        if mcfg.tie_embeddings:
            self._lm_head_weight = self.embed.tok.weight  # tied
            self.lm_head = lambda x: F.linear(x, self._lm_head_weight)
        else:
            self.lm_head = nn.Linear(mcfg.hidden_dim, mcfg.vocab_size, bias=False)

        # Hebbian trackers: one per layer (one per LobeLayer).
        self.hebbian_trackers: List[HebbianTracker] = [
            build_hebbian_tracker(layer.lobe_layer, config.hebbian)
            for layer in self.layers
        ]
        # Whether to actually run Hebbian updates (controlled by ablation flag).
        self._hebbian_enabled = config.hebbian.enabled and config.ablation.use_hebbian

        # Growth monitor: instantiated lazily — needs to be set externally
        # by the training loop because it requires a reference to `self`.
        # We do NOT instantiate it here to avoid a circular reference during
        # __init__. The training loop calls `attach_growth_monitor()`.
        self.growth_monitor: Optional[GrowthMonitor] = None

    def attach_growth_monitor(self) -> GrowthMonitor:
        """Create and attach the GrowthMonitor. Called by the training loop
        after model construction (only if config.growth.enabled and
        config.ablation.use_growth are both True)."""
        if self.config.growth.enabled and self.config.ablation.use_growth:
            self.growth_monitor = GrowthMonitor(self, self.config.growth)
        return self.growth_monitor

    # ------------------------------------------------------------------
    # Forward
    # ------------------------------------------------------------------
    def forward(self, input_ids: torch.Tensor,
                update_hebbian: Optional[bool] = None
                ) -> Tuple[torch.Tensor, dict]:
        """input_ids: (B, T) -> (logits, diagnostics).

        Args:
          update_hebbian: if None, defaults to self._hebbian_enabled AND
            self.training. Pass True/False to override (e.g. eval should
            pass False to avoid mutating state).

        Diagnostics dict contains per-layer info that downstream consumers
        (training logging, strength_map, growth monitor) need.
        """
        do_hebbian = (self._hebbian_enabled if update_hebbian is None
                      else update_hebbian) and self.training

        x = self.embed(input_ids)
        per_layer_diag = []
        all_winning_masks: List[List[Optional[torch.Tensor]]] = []
        for li, layer in enumerate(self.layers):
            x, ldiag = layer(x)
            per_layer_diag.append(ldiag)
            # Collect winning masks for Hebbian update.
            all_winning_masks.append(ldiag["per_lobe_winning_masks"])

        x = self.ln_f(x)
        logits = self.lm_head(x)

        # Hebbian update — happens AFTER forward, BEFORE backward (so the
        # strength values are updated for the next step, not the current one).
        # Done under no_grad inside the tracker.
        if do_hebbian:
            for li, tracker in enumerate(self.hebbian_trackers):
                tracker.update(all_winning_masks[li])

        diagnostics = {
            "per_layer": per_layer_diag,
            "hebbian_enabled": do_hebbian,
            "hebbian_stats": [t.get_strength_stats() for t in self.hebbian_trackers],
        }
        return logits, diagnostics

    # ------------------------------------------------------------------
    # Growth monitor signal extraction
    # ------------------------------------------------------------------
    def push_growth_signals(self, diagnostics: dict, growth_monitor: GrowthMonitor) -> None:
        """Extract per-(layer, lobe) saturation signals from diagnostics
        and push them into the growth monitor's rolling windows.

        Called by the training loop every forward pass (cheap). The actual
        growth check happens less frequently (see train.py).
        """
        if growth_monitor is None:
            return
        for li, ldiag in enumerate(diagnostics["per_layer"]):
            conf_means = ldiag["per_lobe_confidence_mean"]  # list[float] len num_lobes
            masks = ldiag["per_lobe_winning_masks"]         # list[Tensor or None]
            counts = ldiag["per_lobe_execution_count"]      # list[int]
            for lj in range(len(conf_means)):
                conf = conf_means[lj]
                # Utilization: fraction of this lobe's neurons that won k-WTA,
                # averaged across the tokens it processed.
                if masks[lj] is not None and masks[lj].numel() > 0:
                    util = masks[lj].float().mean().item()
                    # Entropy of the per-neuron winning frequency, normalized
                    # by log(ffn_dim) so it lands in [0, 1].
                    freq = masks[lj].float().mean(dim=0)         # (ffn_dim,)
                    freq = freq.clamp(min=1e-8)
                    ent = -(freq * freq.log()).sum().item()
                    max_ent = math.log(masks[lj].shape[-1])
                    ent_norm = ent / max_ent if max_ent > 0 else 0.0
                else:
                    util = 0.0
                    ent_norm = 0.0
                growth_monitor.step(li, lj, conf, util, ent_norm)

    # ------------------------------------------------------------------
    # Inspection
    # ------------------------------------------------------------------
    def get_strength_maps(self) -> List[List[torch.Tensor]]:
        """Return [layer][lobe] strength tensors for visualization."""
        return [t.get_strength_map() for t in self.hebbian_trackers]

    def get_lobe_neuron_counts(self) -> List[List[int]]:
        return [layer.lobe_layer.lobe_neuron_counts() for layer in self.layers]

    # ------------------------------------------------------------------
    # Parameter accounting — same shape as baseline so they can be diffed.
    # ------------------------------------------------------------------
    def parameter_report(self) -> dict:
        report = {
            "embedding_token": self.embed.tok.weight.numel(),
            "embedding_pos":   self.embed.pos.weight.numel(),
            "per_layer": [],
            "lm_head": self.embed.tok.weight.numel() if self.config.model.tie_embeddings
                       else sum(p.numel() for p in self.lm_head.parameters()) if hasattr(self.lm_head, "parameters")
                       else 0,
            "total": count_parameters(self),
        }
        for i, layer in enumerate(self.layers):
            attn = count_parameters(layer.attn)
            # Lobe layer: gates + fc1 + fc2 for each lobe
            lobe_params = 0
            per_lobe = []
            for lj, lobe in enumerate(layer.lobe_layer.lobes):
                lp = count_parameters(lobe)
                lobe_params += lp
                per_lobe.append({"lobe": lj, "ffn_dim": lobe.ffn_dim, "params": lp})
            ln = count_parameters(layer.ln1) + count_parameters(layer.ln2)
            report["per_layer"].append({
                "layer": i, "attn": attn, "lobe_layer": lobe_params,
                "ln": ln, "layer_total": attn + lobe_params + ln,
                "per_lobe": per_lobe,
            })
        return report


# =====================================================================
# Convenience: build from config
# =====================================================================

def build_novel_model(config: Config) -> NovelModel:
    return NovelModel(config)
