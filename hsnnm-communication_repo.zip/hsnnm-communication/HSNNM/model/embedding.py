"""
model/embedding.py — Token + learned positional embeddings.

Not a novel component — text-to-vector conversion has no alternative
mechanism (per the design discussion in the spec). This is the unavoidable
infrastructure that both the baseline and novel models share.

Learned positional embeddings are used (simpler to implement/debug than
rotary or sinusoidal). Can be swapped for RoPE later without touching the
rest of the model.
"""
from __future__ import annotations

import torch
import torch.nn as nn


class TokenPositionalEmbedding(nn.Module):
    """Token embedding + learned positional embedding.

    Forward: input (B, T) long -> output (B, T, hidden_dim) float.
    """

    def __init__(
        self,
        vocab_size: int,
        hidden_dim: int,
        max_seq_len: int,
        dropout: float = 0.1,
        pad_id: int = 0,
    ):
        super().__init__()
        if vocab_size <= 0:
            raise ValueError(f"vocab_size must be > 0, got {vocab_size}")
        if max_seq_len <= 0:
            raise ValueError(f"max_seq_len must be > 0, got {max_seq_len}")

        self.tok = nn.Embedding(vocab_size, hidden_dim, padding_idx=pad_id)
        self.pos = nn.Embedding(max_seq_len, hidden_dim)
        self.drop = nn.Dropout(dropout)
        self.max_seq_len = max_seq_len

        # Init: token embedding with N(0, 0.02) (GPT-style), pos with zeros
        # so the model starts as if positions don't matter (learned from
        # scratch rather than imposed).
        nn.init.normal_(self.tok.weight, mean=0.0, std=0.02)
        nn.init.zeros_(self.pos.weight)
        # padding_idx is forced to zero by nn.Embedding; re-assert after init.
        with torch.no_grad():
            self.tok.weight[pad_id].fill_(0.0)

    def forward(self, input_ids: torch.Tensor) -> torch.Tensor:
        B, T = input_ids.shape
        if T > self.max_seq_len:
            raise ValueError(
                f"Sequence length {T} exceeds max_seq_len {self.max_seq_len}. "
                f"Increase config.model.max_seq_len."
            )
        positions = torch.arange(T, device=input_ids.device).unsqueeze(0).expand(B, T)
        x = self.tok(input_ids) + self.pos(positions)
        return self.drop(x)
