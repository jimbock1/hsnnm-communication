"""
model/hebbian.py — CORE NOVEL COMPONENT #2: Hebbian strength tracking.

A non-gradient usage counter per neuron. Winners of k-WTA get a small strength
bump; everyone else decays. Strength scales each neuron's activation (applied
inside `Lobe.forward_subnetwork`), so frequently-used pathways amplify over
time.

*********************************************************************
** UPDATE RULE — see addendum #2.                                  **
*********************************************************************

The original spec had an unbounded additive rule
(strength[winner] += inc; strength[loser] -= decay). That blows up over long
runs. The CLAMP-FIX rule implemented here is:

    strength = strength * (1 - decay_rate)            # multiplicative decay, all neurons
    strength = strength + winning_mask * increment    # additive nudge, winners only
    strength = clamp(strength, clamp_min, clamp_max)  # hard ceiling

With defaults (decay=0.001, increment=0.01, clamp=[0, 2]), strength stays in
[0, 2] forever regardless of training length. The activation scaling factor
is (1 + strength), so it lives in [1, 3] — activations can never vanish from
strength undershoot and never explode from strength overshoot.

The strength tensor is a buffer (not nn.Parameter), so it:
  - Moves with .to(device) / .cuda()
  - Is saved in state_dict (so it survives checkpointing)
  - Is NOT updated by optimizer.step() (backprop gradients never touch it)
  - IS updated manually here via tensor in-place ops under torch.no_grad()
"""
from __future__ import annotations

from typing import List, Tuple, Optional
import torch

from config import HebbianConfig


class HebbianTracker:
    """Per-lobe, per-neuron strength tracking.

    Not an nn.Module — operates on the lobe buffers directly so we don't
    duplicate state. One tracker per LobeLayer.
    """

    def __init__(self, lobes: list, config: HebbianConfig):
        """`lobes` is a list of Lobe modules. Each must have a `.strength`
        buffer of shape (ffn_dim,)."""
        self.lobes = lobes
        self.cfg = config
        # Sanity: ensure each lobe has the strength buffer initialized.
        for i, l in enumerate(lobes):
            assert hasattr(l, "strength") and isinstance(l.strength, torch.Tensor), \
                f"Lobe {i} missing .strength buffer"
            assert l.strength.ndim == 1, f"Lobe {i} strength must be 1-D"

    # ------------------------------------------------------------------
    # Update rule — the CLAMP-FIX from addendum #2.
    # ------------------------------------------------------------------
    @torch.no_grad()
    def update(self, winning_masks: List[Optional[torch.Tensor]]) -> None:
        """Apply one Hebbian update step.

        Args:
            winning_masks: list of length len(lobes). Each entry is either
              None (lobe didn't run this step — no update) or a tensor of
              shape (N, ffn_dim) bool where N is the number of tokens the
              lobe processed.

        For lobes that didn't run, only the decay step is applied (no
        winner increment — there were no winners). For lobes that ran,
        the per-neuron winning frequency is computed across the N tokens
        and used as the increment weight (so a neuron that won for every
        token gets the full increment; one that won for half the tokens
        gets half).

        # CLAMP-FIX: see module docstring.
        """
        cfg = self.cfg
        for lobe, mask in zip(self.lobes, winning_masks):
            if not self.cfg.enabled:
                continue

            s = lobe.strength                              # (ffn_dim,)

            # 1. Multiplicative decay applied to ALL neurons.
            s.mul_(1.0 - cfg.decay_rate)

            # 2. Additive nudge for winners. If the lobe didn't run (mask is
            #    None) or N == 0, skip this — no winners to reward.
            if mask is not None and mask.numel() > 0:
                # mask shape (N, ffn_dim). Average across N to get a per-neuron
                # winning frequency in [0, 1].
                win_freq = mask.float().mean(dim=0)         # (ffn_dim,)
                s.add_(win_freq * cfg.increment)

            # 3. Hard clamp — guarantees strength stays in [clamp_min, clamp_max]
            #    forever, regardless of training length.
            s.clamp_(min=cfg.clamp_min, max=cfg.clamp_max)

    # ------------------------------------------------------------------
    # Inspection / visualization
    # ------------------------------------------------------------------
    def get_strength_map(self) -> List[torch.Tensor]:
        """Return list of per-lobe strength tensors (each shape (ffn_dim,)).

        Used by evaluation/strength_map.py to render the heatmap.
        """
        return [l.strength.detach().clone() for l in self.lobes]

    def get_strength_stats(self) -> dict:
        """Return summary statistics across all lobes — for logging."""
        all_s = torch.cat([l.strength.detach() for l in self.lobes])
        return {
            "mean": all_s.mean().item(),
            "std": all_s.std().item(),
            "min": all_s.min().item(),
            "max": all_s.max().item(),
            "frac_at_max": (all_s >= self.cfg.clamp_max - 1e-6).float().mean().item(),
            "frac_at_min": (all_s <= self.cfg.clamp_min + 1e-6).float().mean().item(),
        }

    # ------------------------------------------------------------------
    # Growth support
    # ------------------------------------------------------------------
    def on_lobe_grown(self, lobe_idx: int, new_ffn_dim: int,
                      donor_idx: int = 0) -> None:
        """Hook called by GrowthMonitor after a lobe's neurons have been
        resized. The lobe's strength buffer has already been resized by
        Lobe.grow_neurons (the donor's strength is copied for the new
        neurons); this is just a notification so the tracker can update
        any internal bookkeeping if needed.

        Currently a no-op — the tracker reads `lobe.strength` live.
        """
        pass


# =====================================================================
# Convenience: build from a LobeLayer
# =====================================================================

def build_hebbian_tracker(lobe_layer, config: HebbianConfig) -> HebbianTracker:
    """Build a HebbianTracker bound to a LobeLayer's lobes."""
    return HebbianTracker(lobe_layer.lobes, config)
