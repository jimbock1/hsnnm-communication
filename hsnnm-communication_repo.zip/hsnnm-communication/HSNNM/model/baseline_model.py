"""
model/baseline_model.py — Standard dense transformer decoder, the
"known-good" comparison model.

Per addendum #1: this is a *completely standard* transformer — multi-head
self-attention + dense FFN + LayerNorm + residuals. No lobes, no k-WTA, no
Hebbian tracking, no growth. The novel model is identical except its FFN
sublayer is swapped for the lobe mechanism.

The parameter count is configured to roughly match the novel model. The
exact accounting is documented in `parameter_report()` below and logged at
training start so the comparison is provably fair.
"""
from __future__ import annotations

from dataclasses import dataclass
import math

import torch
import torch.nn as nn
import torch.nn.functional as F

from config import Config, count_parameters
from model.embedding import TokenPositionalEmbedding


# =====================================================================
# Building blocks
# =====================================================================

class CausalSelfAttention(nn.Module):
    """Standard multi-head causal self-attention."""

    def __init__(self, hidden_dim: int, num_heads: int, dropout: float):
        super().__init__()
        assert hidden_dim % num_heads == 0, \
            f"hidden_dim ({hidden_dim}) must be divisible by num_heads ({num_heads})"
        self.h = num_heads
        self.d_head = hidden_dim // num_heads
        self.qkv = nn.Linear(hidden_dim, 3 * hidden_dim, bias=False)
        self.proj = nn.Linear(hidden_dim, hidden_dim, bias=False)
        self.drop = nn.Dropout(dropout)
        # causal mask buffer (not a parameter)
        self.register_buffer(
            "causal_mask",
            torch.tril(torch.ones(1, 1, 1024, 1024, dtype=torch.bool)),
            persistent=False,
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        B, T, C = x.shape
        qkv = self.qkv(x)                              # (B, T, 3C)
        q, k, v = qkv.split(C, dim=-1)                  # each (B, T, C)
        # reshape to (B, h, T, d_head)
        q = q.view(B, T, self.h, self.d_head).transpose(1, 2)
        k = k.view(B, T, self.h, self.d_head).transpose(1, 2)
        v = v.view(B, T, self.h, self.d_head).transpose(1, 2)

        # Scaled dot-product attention with causal mask. PyTorch 2.0+
        # provides fused SDPA — it works on ROCm and is significantly faster
        # than a manual implementation.
        mask = self.causal_mask[:, :, :T, :T]
        out = F.scaled_dot_product_attention(
            q, k, v,
            attn_mask=mask,
            dropout_p=self.drop.p if self.training else 0.0,
            is_causal=False,  # we pass an explicit mask
        )
        out = out.transpose(1, 2).contiguous().view(B, T, C)
        return self.drop(self.proj(out))


class DenseFFN(nn.Module):
    """Standard 2-layer MLP FFN with GELU."""

    def __init__(self, hidden_dim: int, ffn_dim: int):
        super().__init__()
        self.fc1 = nn.Linear(hidden_dim, ffn_dim, bias=False)
        self.fc2 = nn.Linear(ffn_dim, hidden_dim, bias=False)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.fc2(F.gelu(self.fc1(x)))


class TransformerBlock(nn.Module):
    """Pre-LN transformer block: Attention then FFN, each with residual.

    Input -> LN -> Self-Attention -> Residual
          -> LN -> FFN             -> Residual -> Output
    """

    def __init__(self, hidden_dim: int, num_heads: int, ffn_dim: int,
                 dropout: float, ln_eps: float):
        super().__init__()
        self.ln1 = nn.LayerNorm(hidden_dim, eps=ln_eps)
        self.attn = CausalSelfAttention(hidden_dim, num_heads, dropout)
        self.ln2 = nn.LayerNorm(hidden_dim, eps=ln_eps)
        self.ffn = DenseFFN(hidden_dim, ffn_dim)
        self.drop = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = x + self.drop(self.attn(self.ln1(x)))
        x = x + self.drop(self.ffn(self.ln2(x)))
        return x


# =====================================================================
# Full baseline model
# =====================================================================

class BaselineModel(nn.Module):
    """Standard dense transformer LM."""

    def __init__(self, config: Config):
        super().__init__()
        self.config = config
        mcfg = config.model

        self.embed = TokenPositionalEmbedding(
            vocab_size=mcfg.vocab_size,
            hidden_dim=mcfg.hidden_dim,
            max_seq_len=mcfg.max_seq_len,
            dropout=mcfg.dropout,
        )
        self.blocks = nn.ModuleList([
            TransformerBlock(
                hidden_dim=mcfg.hidden_dim,
                num_heads=mcfg.num_heads,
                ffn_dim=mcfg.ffn_dim,
                dropout=mcfg.dropout,
                ln_eps=mcfg.layernorm_eps,
            ) for _ in range(mcfg.num_layers)
        ])
        self.ln_f = nn.LayerNorm(mcfg.hidden_dim, eps=mcfg.layernorm_eps)
        # Output projection: hidden -> vocab. Tied to input embedding by default.
        if mcfg.tie_embeddings:
            self.lm_head = lambda x: F.linear(x, self.embed.tok.weight)
        else:
            self.lm_head = nn.Linear(mcfg.hidden_dim, mcfg.vocab_size, bias=False)

    def forward(self, input_ids: torch.Tensor) -> torch.Tensor:
        """input_ids: (B, T) long -> logits: (B, T, V) float."""
        x = self.embed(input_ids)
        for block in self.blocks:
            x = block(x)
        x = self.ln_f(x)
        return self.lm_head(x)

    # ------------------------------------------------------------------
    # Parameter accounting — the entire basis for a fair comparison.
    # ------------------------------------------------------------------
    def parameter_report(self) -> dict:
        """Return a structured per-component parameter count.

        The novel model has an identically-shaped method, so the two can
        be diffed to confirm fairness.
        """
        report = {
            "embedding_token": self.embed.tok.weight.numel(),
            "embedding_pos":   self.embed.pos.weight.numel(),
            "per_layer": [],
            "lm_head": self.embed.tok.weight.numel() if self.config.model.tie_embeddings
                       else sum(p.numel() for p in self.lm_head.parameters()) if hasattr(self.lm_head, "parameters")
                       else 0,
            "total": count_parameters(self),
        }
        for i, block in enumerate(self.blocks):
            attn = count_parameters(block.attn)
            ffn = count_parameters(block.ffn)
            ln = count_parameters(block.ln1) + count_parameters(block.ln2)
            report["per_layer"].append({
                "layer": i, "attn": attn, "ffn": ffn, "ln": ln, "layer_total": attn + ffn + ln,
            })
        return report


# =====================================================================
# Convenience: build from config
# =====================================================================

def build_baseline_model(config: Config) -> BaselineModel:
    return BaselineModel(config)
