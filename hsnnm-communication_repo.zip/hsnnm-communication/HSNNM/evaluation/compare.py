"""
evaluation/compare.py — Side-by-side comparison of trained models.

Loads N checkpoints (baseline + one or more novel variants from the ablation
grid), parses their training logs, and produces:
  - A text summary report (loss curves, val loss, param count, FLOPs/token,
    training wall-clock time).
  - A matplotlib plot overlaying training loss curves and a FLOPs-vs-loss
    scatter.

Output goes to /home/z/my-project/download/ per the project conventions.

Usage:
    python -m evaluation.compare \
        --baseline runs/phase1_baseline \
        --novel runs/phase1_novel \
        [--novel runs/phase1_novel_no_hebbian] \
        [--novel runs/phase1_novel_no_growth] \
        --out download/comparison_phase1
"""
from __future__ import annotations

from pathlib import Path
import argparse
import json
import logging
import sys

import matplotlib
matplotlib.use("Agg")  # no display
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm

# CJK font fallback (per project rule #7)
try:
    fm.fontManager.addfont('/usr/share/fonts/truetype/chinese/NotoSansSC-Regular.ttf')
except Exception:
    pass
try:
    fm.fontManager.addfont('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf')
except Exception:
    pass
plt.rcParams['font.sans-serif'] = ['Noto Sans SC', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from config import Config, count_parameters
from training.checkpoint import load_checkpoint
from training.train import estimate_flops_per_token

log = logging.getLogger("compare")


# =====================================================================
# Log parsing
# =====================================================================

def parse_jsonl_log(run_dir: Path) -> dict:
    """Parse runs/<name>/log.jsonl into structured arrays."""
    log_path = run_dir / "log.jsonl"
    if not log_path.exists():
        return {"available": False, "run_dir": str(run_dir)}

    train_steps, train_losses = [], []
    eval_steps, eval_losses = [], []
    growth_events = []
    init_record = None
    done_record = None

    for line in log_path.read_text().splitlines():
        if not line.strip():
            continue
        try:
            r = json.loads(line)
        except json.JSONDecodeError:
            continue
        ev = r.get("event")
        if ev == "init":
            init_record = r
        elif ev == "train_step":
            train_steps.append(r["step"])
            train_losses.append(r["loss"])
        elif ev == "eval":
            eval_steps.append(r["step"])
            eval_losses.append(r["val_loss"])
        elif ev == "growth":
            growth_events.append(r)
        elif ev == "train_done":
            done_record = r

    return {
        "available": True,
        "run_dir": str(run_dir),
        "init": init_record,
        "train_steps": train_steps,
        "train_losses": train_losses,
        "eval_steps": eval_steps,
        "eval_losses": eval_losses,
        "growth_events": growth_events,
        "done": done_record,
    }


# =====================================================================
# Report
# =====================================================================

def build_report(run_name: str, parsed: dict) -> str:
    if not parsed.get("available"):
        return f"## {run_name}\n(log not found at {parsed['run_dir']})\n"

    init = parsed.get("init") or {}
    done = parsed.get("done") or {}
    final_train_loss = parsed["train_losses"][-1] if parsed["train_losses"] else float("nan")
    final_val_loss = parsed["eval_losses"][-1] if parsed["eval_losses"] else float("nan")
    n_growth = len(parsed.get("growth_events", []))

    lines = [
        f"## {run_name}",
        f"  Run dir:           {parsed['run_dir']}",
        f"  Total params:      {init.get('total_params', '?')}",
        f"  FLOPs/token:       {init.get('flops_per_token', '?')}",
        f"  Vocab size:        {init.get('vocab_size', '?')}",
        f"  Final train loss:  {final_train_loss:.4f}",
        f"  Final val loss:    {final_val_loss:.4f}",
        f"  Growth events:     {n_growth}",
        f"  Training time:     {done.get('total_time_s', '?')}s",
    ]
    return "\n".join(lines) + "\n"


# =====================================================================
# Plot
# =====================================================================

def plot_comparison(runs: list, out_path: Path) -> None:
    """`runs` is a list of (name, parsed_dict) tuples."""
    fig, axes = plt.subplots(1, 2, figsize=(14, 5), constrained_layout=True)

    # Left: training loss curves
    ax = axes[0]
    for name, p in runs:
        if not p.get("available"):
            continue
        ax.plot(p["train_steps"], p["train_losses"], label=name, alpha=0.8)
        # Mark growth events with vertical lines
        for ev in p.get("growth_events", []):
            ax.axvline(ev["step"], color="gray", linestyle=":", alpha=0.3)
    ax.set_xlabel("Training step")
    ax.set_ylabel("Loss (cross-entropy)")
    ax.set_title("Training loss curves")
    ax.legend(loc="upper right")
    ax.set_yscale("log")
    ax.grid(True, alpha=0.3)

    # Right: FLOPs/token vs final val loss
    ax = axes[1]
    names, flops, vlosses = [], [], []
    for name, p in runs:
        if not p.get("available"):
            continue
        init = p.get("init") or {}
        if not p["eval_losses"]:
            continue
        names.append(name)
        flops.append(init.get("flops_per_token", 0))
        vlosses.append(p["eval_losses"][-1])
    ax.scatter(flops, vlosses, s=120)
    for n, f, v in zip(names, flops, vlosses):
        ax.annotate(n, (f, v), xytext=(7, 7), textcoords="offset points", fontsize=9)
    ax.set_xlabel("FLOPs / token (estimated)")
    ax.set_ylabel("Final validation loss")
    ax.set_title("Compute vs. quality (lower-left is better)")
    ax.grid(True, alpha=0.3)

    out_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_path, dpi=120)
    plt.close(fig)
    log.info("Plot saved: %s", out_path)


# =====================================================================
# CLI
# =====================================================================

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--baseline", required=True, help="Path to baseline run dir")
    parser.add_argument("--novel", action="append", default=[],
                        help="Path(s) to novel run dir(s). May be repeated.")
    parser.add_argument("--out", default="download/comparison",
                        help="Output path prefix (no extension)")
    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

    runs = [("baseline", parse_jsonl_log(Path(args.baseline)))]
    for i, npath in enumerate(args.novel):
        runs.append((Path(npath).name, parse_jsonl_log(Path(npath))))

    out_prefix = Path(args.out)
    report_text = "# Model comparison\n\n"
    for name, parsed in runs:
        report_text += build_report(name, parsed) + "\n"
    out_prefix.parent.mkdir(parents=True, exist_ok=True)
    out_prefix.with_suffix(".txt").write_text(report_text)
    print(report_text)

    plot_comparison(runs, out_prefix.with_suffix(".png"))


if __name__ == "__main__":
    main()
