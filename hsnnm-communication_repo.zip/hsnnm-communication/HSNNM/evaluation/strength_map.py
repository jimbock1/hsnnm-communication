"""
evaluation/strength_map.py — Visualize Hebbian strength + selection patterns.

Produces a multi-panel figure:
  - Row 1: per-layer, per-lobe strength heatmaps (one panel per layer).
    Each panel is a (lobes x max_ffn_dim) grid; color = strength value.
  - Row 2: per-lobe selection frequency over training (line plot per lobe).
  - Row 3: Hebbian strength distribution histogram (all neurons pooled).
  - Row 4 (optional): when --text-samples are provided, a heatmap showing
    which lobes light up for each sample (one row per sample).

Output goes to /home/z/my-project/download/.

Usage:
    python -m evaluation.strength_map \\
        --ckpt runs/phase1_novel/final.pt \\
        --text-samples samples_dialogue.txt samples_descriptive.txt \\
        --out download/strength_map_phase1
"""
from __future__ import annotations

from pathlib import Path
import argparse
import json
import logging
import sys

import torch
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm

try:
    fm.fontManager.addfont('/usr/share/fonts/truetype/chinese/NotoSansSC-Regular.ttf')
except Exception:
    pass
try:
    fm.fontManager.addfont('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf')
except Exception:
    pass
plt.rcParams['font.sans-serif'] = ['Noto Sans SC', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from config import Config
from training.checkpoint import load_checkpoint

log = logging.getLogger("strength_map")


# =====================================================================
# Load model + extract strength maps
# =====================================================================

def load_strengths(ckpt_path: str, device: str = "cpu") -> tuple:
    """Returns (model, config, tokenizer, strength_maps) where strength_maps
    is a list[layer] of list[lobe] of 1-D tensors."""
    payload = load_checkpoint(ckpt_path, model=None, optimizer=None, device=device)
    model = payload["model"]
    if not hasattr(model, "get_strength_maps"):
        raise ValueError("Checkpoint is not a novel model — no strength maps to visualize.")
    model.eval()
    return model, payload["config"], payload["tokenizer"], model.get_strength_maps()


# =====================================================================
# Plot 1: per-layer strength heatmap
# =====================================================================

def plot_strength_heatmaps(strength_maps: list, out_path: Path) -> None:
    n_layers = len(strength_maps)
    fig, axes = plt.subplots(1, n_layers, figsize=(5 * n_layers, 4),
                             constrained_layout=True)
    if n_layers == 1:
        axes = [axes]
    for li, layer in enumerate(strength_maps):
        n_lobes = len(layer)
        max_ffn = max(s.shape[0] for s in layer)
        grid = torch.zeros(n_lobes, max_ffn)
        for lj, s in enumerate(layer):
            grid[lj, :s.shape[0]] = s.cpu()
        im = axes[li].imshow(grid.numpy(), aspect="auto", cmap="viridis")
        axes[li].set_title(f"Layer {li}: lobe strengths\n(n_lobes={n_lobes})")
        axes[li].set_xlabel("neuron index")
        axes[li].set_ylabel("lobe index")
        fig.colorbar(im, ax=axes[li], fraction=0.046, pad=0.04)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_path, dpi=120)
    plt.close(fig)
    log.info("Strength heatmap saved: %s", out_path)


# =====================================================================
# Plot 2: lobe selection frequency over training (parsed from log.jsonl)
# =====================================================================

def plot_lobe_selection_freq(run_dir: Path, out_path: Path) -> None:
    log_path = Path(run_dir) / "log.jsonl"
    if not log_path.exists():
        log.warning("log.jsonl not found at %s — skipping selection-freq plot.", log_path)
        return
    # Parse per-step lobe_execution_counts.
    # Format: list[layer] of list[lobe] of int.
    steps = []
    by_layer_lobe = {}  # (li, lj) -> list of counts over time
    for line in log_path.read_text().splitlines():
        try:
            r = json.loads(line)
        except json.JSONDecodeError:
            continue
        if r.get("event") != "train_step" or "lobe_execution_counts" not in r:
            continue
        steps.append(r["step"])
        for li, layer_counts in enumerate(r["lobe_execution_counts"]):
            for lj, c in enumerate(layer_counts):
                by_layer_lobe.setdefault((li, lj), []).append(c)

    if not by_layer_lobe:
        log.warning("No lobe_execution_counts found in log — skipping selection-freq plot.")
        return

    n_layers = max(k[0] for k in by_layer_lobe) + 1
    n_lobes = max(k[1] for k in by_layer_lobe) + 1
    fig, axes = plt.subplots(n_layers, 1, figsize=(10, 2.5 * n_layers),
                             constrained_layout=True, squeeze=False)
    for li in range(n_layers):
        ax = axes[li, 0]
        for lj in range(n_lobes):
            series = by_layer_lobe.get((li, lj), [])
            if len(series) == len(steps):
                ax.plot(steps, series, label=f"lobe {lj}", alpha=0.8)
        ax.set_title(f"Layer {li}: lobe selection frequency (tokens per step)")
        ax.set_xlabel("Training step")
        ax.set_ylabel("Tokens routed")
        ax.legend(loc="upper right", fontsize=8)
        ax.grid(True, alpha=0.3)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_path, dpi=120)
    plt.close(fig)
    log.info("Lobe selection frequency plot saved: %s", out_path)


# =====================================================================
# Plot 3: strength distribution histogram
# =====================================================================

def plot_strength_histogram(strength_maps: list, out_path: Path) -> None:
    all_s = torch.cat([s for layer in strength_maps for s in layer]).cpu().numpy()
    fig, ax = plt.subplots(1, 1, figsize=(8, 4), constrained_layout=True)
    ax.hist(all_s, bins=50, color="steelblue", edgecolor="white")
    ax.set_xlabel("Hebbian strength value")
    ax.set_ylabel("# neurons")
    ax.set_title(f"Strength distribution across all lobes (n={len(all_s)})")
    ax.grid(True, alpha=0.3)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_path, dpi=120)
    plt.close(fig)
    log.info("Strength histogram saved: %s", out_path)


# =====================================================================
# Plot 4: which lobes light up for different text samples
# =====================================================================

def plot_lobe_activation_by_text(model, tokenizer, sample_texts: list,
                                 out_path: Path, device: str = "cpu") -> None:
    """For each sample text, run a forward pass and record which lobes
    processed the most tokens. Produces a (samples x lobes) heatmap."""
    model.eval()
    n_layers = len(model.layers)
    n_lobes = model.layers[0].lobe_layer.num_lobes
    grid = torch.zeros(len(sample_texts), n_layers, n_lobes)

    with torch.no_grad():
        for si, text in enumerate(sample_texts):
            ids = tokenizer.encode(text[:256])  # truncate to seq_len
            if len(ids) < 4:
                continue
            x = torch.tensor(ids, dtype=torch.long, device=device).unsqueeze(0)
            try:
                _, diag = model(x, update_hebbian=False)
            except TypeError:
                # baseline model — no diag
                continue
            for li, ld in enumerate(diag["per_layer"]):
                counts = ld["per_lobe_execution_count"]
                total = sum(counts) or 1
                for lj, c in enumerate(counts[:n_lobes]):
                    grid[si, li, lj] = c / total

    # Plot: one panel per layer
    fig, axes = plt.subplots(1, n_layers, figsize=(4 * n_layers, max(4, len(sample_texts) * 0.4)),
                             constrained_layout=True, squeeze=False)
    for li in range(n_layers):
        ax = axes[0, li]
        im = ax.imshow(grid[:, li, :].numpy(), aspect="auto", cmap="magma")
        ax.set_title(f"Layer {li}: lobe activation by sample")
        ax.set_xlabel("lobe index")
        ax.set_ylabel("sample index")
        ax.set_yticks(range(len(sample_texts)))
        ax.set_yticklabels([f"s{i}" for i in range(len(sample_texts))])
        fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_path, dpi=120)
    plt.close(fig)
    log.info("Lobe activation by text saved: %s", out_path)


# =====================================================================
# CLI
# =====================================================================

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--ckpt", required=True, help="Path to novel model checkpoint")
    parser.add_argument("--run-dir", default=None,
                        help="Run dir containing log.jsonl (for selection freq plot)")
    parser.add_argument("--text-samples", nargs="*", default=[],
                        help="Files containing sample text (one per file)")
    parser.add_argument("--out", default="download/strength_map", help="Output prefix")
    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
    device = "cuda" if torch.cuda.is_available() else "cpu"
    model, config, tokenizer, strengths = load_strengths(args.ckpt, device)

    out_prefix = Path(args.out)
    plot_strength_heatmaps(strengths, out_prefix.with_name(out_prefix.name + "_heatmaps.png"))
    plot_strength_histogram(strengths, out_prefix.with_name(out_prefix.name + "_hist.png"))
    if args.run_dir:
        plot_lobe_selection_freq(Path(args.run_dir),
                                 out_prefix.with_name(out_prefix.name + "_selection_freq.png"))

    if args.text_samples:
        samples = []
        for f in args.text_samples:
            try:
                samples.append(Path(f).read_text(encoding="utf-8")[:512])
            except Exception as e:
                log.warning("Could not read sample %s: %s", f, e)
        if samples:
            plot_lobe_activation_by_text(model, tokenizer, samples,
                                         out_prefix.with_name(out_prefix.name + "_by_text.png"),
                                         device=device)


if __name__ == "__main__":
    main()
