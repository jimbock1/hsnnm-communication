"""
evaluation/forgetting_test.py — Catastrophic forgetting A -> B test.

This is the make-or-break evaluation. The hypothesis: Hebbian strengthening
consolidates frequently-used pathways, so learning Task B should disturb
Task A *less* than in a pure-backprop baseline.

Procedure:
  1. Train (or load a checkpoint) on Task A.
  2. Evaluate baseline Task-A validation loss -> loss_A_pre.
  3. Continue training on Task B (different subset/style of TinyStories).
  4. Re-evaluate Task-A validation loss -> loss_A_post.
  5. Forgetting = loss_A_post - loss_A_pre.
  6. Compare baseline_model vs novel_model forgetting.

We report the result honestly whether it confirms or refutes the hypothesis.

Task A vs Task B construction:
  - Task A: stories whose first sentence starts with "Once upon a time"
  - Task B: stories whose first sentence starts with "One day" or "There was"
  These subsets are stylistically distinct, share the same vocabulary, and
  both exist in TinyStories. The split is deterministic given a seed.

Usage:
    python -m evaluation.forgetting_test \\
        --config configs/forget_A.yaml \\
        --config2 configs/forget_B.yaml \\
        --variant baseline
    python -m evaluation.forgetting_test \\
        --config configs/forget_A.yaml \\
        --config2 configs/forget_B.yaml \\
        --variant novel
"""
from __future__ import annotations

from pathlib import Path
import argparse
import json
import logging
import sys
import random

import torch

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from config import Config, set_seed, count_parameters
from model.tokenizer import CharTokenizer
from model.baseline_model import build_baseline_model
from model.novel_model import build_novel_model
from data.dataset_loader import _load_tinystories_texts, CharLMDataset
from training.losses import lm_loss
from training.train import build_optimizer, build_lr_scheduler, AMPContext, device_type_str
from training.checkpoint import save_checkpoint, load_checkpoint

log = logging.getLogger("forgetting")


# =====================================================================
# Task A / Task B construction
# =====================================================================

def split_tinystories_by_style(texts: list, seed: int = 42) -> tuple:
    """Split TinyStories into two stylistically-distinct subsets.

    Task A: stories starting with "Once upon a time"
    Task B: stories starting with "One day" or "There was"
    Stories that match neither (or both) are discarded.

    Returns (texts_A, texts_B).
    """
    a, b = [], []
    for t in texts:
        s = t.lstrip()[:30]
        if s.startswith("Once upon a time"):
            a.append(t)
        elif s.startswith("One day") or s.startswith("There was"):
            b.append(t)
    rng = random.Random(seed)
    rng.shuffle(a)
    rng.shuffle(b)
    log.info("Task A: %d stories, Task B: %d stories", len(a), len(b))
    return a, b


# =====================================================================
# Train on one task for N steps
# =====================================================================

def train_on_texts(model, optimizer, scheduler, amp, tokenizer, texts,
                   config: Config, steps: int, device: str,
                   log_every: int = 50) -> list:
    """Train `model` on `texts` for `steps` optimizer steps. Returns a list
    of (step, loss) tuples for the training curve."""
    ds = CharLMDataset(texts, tokenizer, config.data.seq_len,
                       is_validation=False, val_fraction=0.05, seed=config.train.seed)
    if len(ds) == 0:
        raise RuntimeError("Empty dataset for training task.")
    loader = torch.utils.data.DataLoader(
        ds, batch_size=config.train.batch_size, shuffle=True,
        drop_last=True, num_workers=config.data.num_workers,
    )
    model.train()
    history = []
    step = 0
    while step < steps:
        for batch in loader:
            if step >= steps:
                break
            x, y = batch[0].to(device), batch[1].to(device)
            with amp.autocast():
                if config.model_type == "novel":
                    logits, _ = model(x)
                else:
                    logits = model(x)
                loss = lm_loss(logits, y)
            optimizer.zero_grad()
            scaled = amp.scale_loss(loss)
            scaled.backward()
            amp.unscale_and_step(optimizer, model, config.train.grad_clip)
            scheduler.step()
            if step % log_every == 0:
                log.info("  step %d/%d  loss=%.4f", step, steps, loss.item())
                history.append((step, loss.item()))
            step += 1
    return history


# =====================================================================
# Eval on one task
# =====================================================================

def eval_on_texts(model, tokenizer, texts, config: Config, device: str,
                  amp=None, max_batches: int = 50) -> float:
    if len(texts) == 0:
        return float("nan")
    ds = CharLMDataset(texts, tokenizer, config.data.seq_len,
                       is_validation=True, val_fraction=0.5, seed=config.train.seed)
    if len(ds) == 0:
        return float("nan")
    loader = torch.utils.data.DataLoader(
        ds, batch_size=config.train.batch_size, shuffle=False,
        drop_last=False, num_workers=config.data.num_workers,
    )
    model.eval()
    total, n = 0.0, 0
    with torch.no_grad():
        for i, batch in enumerate(loader):
            if i >= max_batches:
                break
            x, y = batch[0].to(device), batch[1].to(device)
            ctx = amp.autocast() if amp else torch.no_grad()
            with ctx:
                if config.model_type == "novel":
                    logits, _ = model(x, update_hebbian=False)
                else:
                    logits = model(x)
                loss = lm_loss(logits, y)
            total += loss.item() * x.size(0)
            n += x.size(0)
    return total / max(1, n)


# =====================================================================
# Main forgetting test
# =====================================================================

def run_forgetting_test(config: Config, task_a_steps: int, task_b_steps: int,
                        out_dir: Path) -> dict:
    set_seed(config.train.seed)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    amp = AMPContext(config.train.use_amp, device_type_str(device))
    out_dir.mkdir(parents=True, exist_ok=True)

    # Load texts, split by style.
    texts = _load_tinystories_texts(config.data.data_fraction, config.data.cache_dir)
    texts_a, texts_b = split_tinystories_by_style(texts, seed=config.train.seed)

    # Build tokenizer from BOTH tasks so vocab is shared.
    tokenizer = CharTokenizer.from_texts(texts_a + texts_b)
    config.model.vocab_size = tokenizer.vocab_size

    # Build model.
    if config.model_type == "baseline":
        model = build_baseline_model(config)
    else:
        model = build_novel_model(config)
    model.to(device)
    optimizer = build_optimizer(model, config)
    total_steps = task_a_steps + task_b_steps
    scheduler = build_lr_scheduler(optimizer, config, total_steps)

    log.info("=== Phase 1: Train on Task A (Once upon a time) for %d steps ===",
             task_a_steps)
    train_history_a = train_on_texts(model, optimizer, scheduler, amp,
                                     tokenizer, texts_a, config,
                                     task_a_steps, device)
    log.info("=== Phase 2: Eval on Task A (pre-forgetting) ===")
    loss_a_pre = eval_on_texts(model, tokenizer, texts_a, config, device, amp)
    log.info("  loss_A_pre = %.4f", loss_a_pre)

    log.info("=== Phase 3: Train on Task B (One day / There was) for %d steps ===",
             task_b_steps)
    train_history_b = train_on_texts(model, optimizer, scheduler, amp,
                                     tokenizer, texts_b, config,
                                     task_b_steps, device)
    log.info("=== Phase 4: Eval on Task A (post-forgetting) ===")
    loss_a_post = eval_on_texts(model, tokenizer, texts_a, config, device, amp)
    log.info("  loss_A_post = %.4f", loss_a_post)

    forgetting = loss_a_post - loss_a_pre
    result = {
        "variant": config.model_type,
        "ablation": config.ablation.__dict__,
        "loss_a_pre": loss_a_pre,
        "loss_a_post": loss_a_post,
        "forgetting": forgetting,
        "forgetting_pct": (forgetting / loss_a_pre) if loss_a_pre > 0 else 0.0,
        "task_a_steps": task_a_steps,
        "task_b_steps": task_b_steps,
        "total_params": count_parameters(model),
        "train_history_a": train_history_a,
        "train_history_b": train_history_b,
    }
    log.info("=== RESULT (%s) ===", config.model_type)
    log.info("  Forgetting: %.4f (%.1f%% of pre-loss)",
             forgetting, result["forgetting_pct"] * 100)

    # Save
    save_checkpoint(out_dir / "final.pt", model, optimizer, tokenizer,
                    config, step=total_steps, epoch=0,
                    extra={"forgetting_result": result})
    (out_dir / "forgetting_result.json").write_text(json.dumps(result, indent=2))
    return result


# =====================================================================
# CLI
# =====================================================================

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True, help="Task A + model config")
    parser.add_argument("--task-a-steps", type=int, default=1000)
    parser.add_argument("--task-b-steps", type=int, default=1000)
    parser.add_argument("--out", default="download/forgetting")
    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
    config = Config.load(args.config)
    run_forgetting_test(config, args.task_a_steps, args.task_b_steps, Path(args.out))


if __name__ == "__main__":
    main()
