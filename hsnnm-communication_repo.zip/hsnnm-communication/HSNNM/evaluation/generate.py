"""
evaluation/generate.py — Sample text generation from trained checkpoints.

Loads both baseline and novel models, generates text from the same prompts,
and saves a side-by-side comparison. Used in the final report to make the
loss curves concrete — reviewers can see what "loss=2.0" actually looks like.

Usage:
    python -m evaluation.generate \
        --baseline-ckpt runs/phase1_baseline/final.pt \
        --novel-ckpt runs/phase1_novel/final.pt \
        --out download/samples.txt

If you only have one checkpoint:
    python -m evaluation.generate --novel-ckpt runs/phase1_novel/final.pt \
        --out download/samples.txt
"""
from __future__ import annotations

from pathlib import Path
import argparse
import logging
import sys

import torch
import torch.nn.functional as F

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from training.checkpoint import load_checkpoint

log = logging.getLogger("generate")


# Default prompts — designed to test both Task A and Task B styles
DEFAULT_PROMPTS = [
    "Once upon a time",        # Task A style (forgetting test)
    "One day",                 # Task B style (forgetting test)
    "The dog ran",             # Generic test
]


@torch.no_grad()
def generate(
    model,
    tokenizer,
    prompt: str,
    max_new_chars: int = 200,
    temperature: float = 0.7,
    top_k: int = 10,
    device: str = "cuda:0",
) -> str:
    """Greedy/sample generation with top-k filtering.

    Char-level generation: each step predicts one char. Top-k sampling keeps
    only the k highest-probability chars, then samples from them with the
    given temperature.
    """
    model.eval()
    ids = tokenizer.encode(prompt)
    if len(ids) == 0:
        ids = [tokenizer.unk_id]

    x = torch.tensor(ids, dtype=torch.long, device=device).unsqueeze(0)

    generated = list(ids)
    for _ in range(max_new_chars):
        # Truncate to max_seq_len if needed
        x_in = x[:, -model.config.model.max_seq_len:] if x.size(1) > model.config.model.max_seq_len else x

        # Forward pass
        if hasattr(model, "hebbian_trackers"):
            # Novel model — disable Hebbian updates during generation
            logits, _ = model(x_in, update_hebbian=False)
        else:
            logits = model(x_in)

        # Take logits at the last position
        next_logits = logits[0, -1] / max(temperature, 1e-6)

        # Top-k filtering
        if top_k > 0 and top_k < next_logits.numel():
            topk_vals, topk_idx = next_logits.topk(top_k)
            mask = torch.full_like(next_logits, float("-inf"))
            mask[topk_idx] = topk_vals
            next_logits = mask

        probs = F.softmax(next_logits, dim=-1)
        next_id = torch.multinomial(probs, num_samples=1).item()

        generated.append(next_id)
        x = torch.cat([x, torch.tensor([[next_id]], dtype=torch.long, device=device)], dim=1)

        # Stop on end-of-story markers (common in TinyStories)
        decoded_so_far = tokenizer.decode(generated[-5:])
        if "<|endoftext|>" in decoded_so_far:
            break

    return tokenizer.decode(generated)


def generate_samples_for_model(ckpt_path: str, prompts: list, device: str = "cuda:0") -> dict:
    """Load a checkpoint and generate samples for each prompt. Returns dict of
    {prompt: generated_text}."""
    if not Path(ckpt_path).exists():
        log.warning("Checkpoint not found: %s", ckpt_path)
        return {}

    payload = load_checkpoint(ckpt_path, model=None, optimizer=None, device=device)
    model = payload["model"]
    tokenizer = payload["tokenizer"]

    samples = {}
    for prompt in prompts:
        log.info("  Generating for prompt: %r", prompt)
        try:
            text = generate(model, tokenizer, prompt, max_new_chars=200,
                            temperature=0.7, top_k=10, device=device)
            samples[prompt] = text
        except Exception as e:
            samples[prompt] = f"[GENERATION FAILED: {e}]"
    return samples


def write_comparison(
    out_path: Path,
    baseline_samples: dict,
    novel_samples: dict,
):
    """Write side-by-side comparison to a text file."""
    out_path.parent.mkdir(parents=True, exist_ok=True)
    lines = [
        "=" * 70,
        "HSNNM 1 'Planck' (Sprout) — Sample Generation Comparison",
        "=" * 70,
        "",
        "Both models trained on the same 10% TinyStories slice, same param count",
        "(~7M each), same seed. Samples generated with temperature=0.7, top_k=10.",
        "",
    ]

    all_prompts = list(set(list(baseline_samples.keys()) + list(novel_samples.keys())))
    for prompt in all_prompts:
        lines.append("-" * 70)
        lines.append(f"PROMPT: {prompt!r}")
        lines.append("-" * 70)
        if prompt in baseline_samples:
            lines.append("\nBASELINE (dense transformer):")
            lines.append(f'  "{baseline_samples[prompt]}"')
        else:
            lines.append("\nBASELINE: (not provided)")
        if prompt in novel_samples:
            lines.append("\nHSNNM 1 'Planck' (Sprout):")
            lines.append(f'  "{novel_samples[prompt]}"')
        else:
            lines.append("\nNOVEL: (not provided)")
        lines.append("")

    lines.extend([
        "=" * 70,
        "Notes:",
        "- Both models are 7M params, char-level. Output will be broken English",
        "  with spelling errors — this is expected and documented in the paper.",
        "- The point is to compare relative quality, not absolute fluency.",
        "- If Hebbian specialization is working, the novel model's outputs may",
        "  show different stylistic patterns than the baseline.",
        "=" * 70,
    ])
    out_path.write_text("\n".join(lines))
    log.info("Samples written to: %s", out_path)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--baseline-ckpt", default=None,
                        help="Path to baseline model checkpoint")
    parser.add_argument("--novel-ckpt", default=None,
                        help="Path to HSNNM 1 'Planck' (Sprout) checkpoint")
    parser.add_argument("--prompts", nargs="*", default=DEFAULT_PROMPTS,
                        help="Prompts to generate from (default: 3 test prompts)")
    parser.add_argument("--out", default="download/samples.txt",
                        help="Output file path")
    parser.add_argument("--device", default=None,
                        help="Device (default: cuda:0 if available, else cpu)")
    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
    device = args.device or ("cuda:0" if torch.cuda.is_available() else "cpu")
    log.info("Device: %s", device)

    if not args.baseline_ckpt and not args.novel_ckpt:
        log.error("Provide at least one of --baseline-ckpt or --novel-ckpt")
        sys.exit(1)

    baseline_samples = {}
    novel_samples = {}

    if args.baseline_ckpt:
        log.info("Loading baseline: %s", args.baseline_ckpt)
        baseline_samples = generate_samples_for_model(args.baseline_ckpt, args.prompts, device)

    if args.novel_ckpt:
        log.info("Loading HSNNM 1 'Planck': %s", args.novel_ckpt)
        novel_samples = generate_samples_for_model(args.novel_ckpt, args.prompts, device)

    write_comparison(Path(args.out), baseline_samples, novel_samples)
    print(f"\nSamples saved to: {args.out}")


if __name__ == "__main__":
    main()
