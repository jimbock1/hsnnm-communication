# SETUP — ROCm + PyTorch install guide (AMD RX 9060 XT, 16GB)

This document records the **only** install path that has been validated for this
project. ROCm support in PyTorch is fragile — small version mismatches will
cause silent kernel failures, `hip` errors, or fall-back to CPU. Follow this
exactly.

---

## 1. System prerequisites (Ubuntu 24.04 LTS recommended)

```bash
# ROCm 7.2 stack (amdgpu + rocm-core). The kernel driver must match.
# Install from AMD's official ROCm repo — see:
#   https://rocm.docs.amd.com/projects/install-on-linux/en/latest/
sudo apt update
sudo apt install -y rocm-dev rocm-libs rocm-utils hip-dev
# Confirm the GPU is visible to ROCm:
rocminfo | grep -E "Marketing Name|Name:"
# Expected: AMD Radeon RX 9060 XT (gfx1200)
```

ROCm 7.x has **native support for gfx1200** (RDNA 4 / Navi 48) — your RX
9060 XT works out of the box with no `HSA_OVERRIDE_GFX_VERSION` workaround
needed. (On older ROCm 6.x you would have had to override; that's no longer
necessary.)

If `rocminfo` does not list the GPU, **stop** — fix the driver first. None of
the steps below will work otherwise.

---

## 2. Python environment

```bash
python3.12 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip==25.2 setuptools==80.9.0 wheel==0.45.1
```

ROCm 6.4 PyTorch wheels are built for Python 3.12. Python 3.11 also works
but 3.12 is the modern default.

---

## 3. PyTorch with ROCm — the canonical install line

```bash
# The +rocm7.2 suffix is mandatory. Plain `pip install torch` will pull the
# CUDA build, which is useless on AMD hardware.
pip install torch==2.12.1 torchvision==0.26.1 --index-url https://download.pytorch.org/whl/rocm7.2
```

### Verify the install actually uses ROCm (NOT CUDA, NOT CPU)

```python
python -c "import torch; print(torch.__version__); print('HIP available:', torch.cuda.is_available()); print('Device:', torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'CPU')"
```

Expected output on a working setup:

```
2.12.1+rocm7.2
HIP available: True
Device: AMD Radeon RX 9060 XT
```

`torch.cuda.is_available()` returns `True` on ROCm because PyTorch reuses the
CUDA API surface — this is expected, not a bug.

---

## 4. Remaining dependencies

```bash
pip install -r requirements.txt
```

`requirements.txt` deliberately does **not** contain torch (see §3).

---

## 5. Mixed precision

The training loop uses `torch.autocast(device_type="cuda", dtype=torch.bfloat16)`
when available, falling back to `torch.float16` with `GradScaler`, and finally
to plain fp32. On RX 9060 XT + ROCm 7.2 / PyTorch 2.12.1, **bf16 is supported**
and is the documented default for this project (see `config.py`).

If you see NaN losses mid-training, the first thing to try is forcing fp32
(`config.use_amp = "fp32"`) to rule out a precision issue.

---

## 6. Common ROCm pitfalls (project-specific notes)

| Symptom | Cause | Fix |
|---|---|---|
| `hipErrorNoBinaryForGpu` on first kernel | Kernel cache built for a different gfx arch | On ROCm 7.x this should not occur for gfx1200 (RX 9060 XT). If it does, `export HSA_OVERRIDE_GFX_VERSION=12.0.0` (verify against `rocminfo`) |
| OOM during growth resize | New neuron count pushes past 16GB | Lower `growth.neurons_per_growth` or `growth.param_ceiling` in `config.py` |
| Random kernel crashes only inside lobe forward | Likely an unsupported op in the masked sub-network path | Set `config.use_amp = "fp32"` and rerun; if it stops, file an issue with the op name |
| Training 10x slower than expected | PyTorch fell back to CPU silently | Re-run §3 verification; check `echo $CUDA_VISIBLE_DEVICES` is unset or set to `0` |

---

## 7. First-run sanity check

```bash
pytest tests/ -v
python -m training.train --config configs/smoke.yaml --dry-run
```

`--dry-run` builds both models, runs one forward + backward on a tiny batch,
and exits — proves the install is sound before committing to a real run.
