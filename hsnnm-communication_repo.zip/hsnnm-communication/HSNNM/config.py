"""
config.py — Centralized configuration for the entire project.

All hyperparameters live here. No module reads hyperparameters from its own
constants; everything flows from a `Config` instance. This is required by
addendum #5 (centralized config) and is what makes the ablation grid in the
README runnable without code edits.

Usage:
    from config import Config, load_config
    cfg = load_config("configs/phase1_novel.yaml")
    # or
    cfg = Config.smoke()           # tiny config for smoke tests
    cfg = Config.phase1_novel()    # Phase 1 novel model defaults

Ablation flags (addendum #3) live in `AblationConfig`. The full grid is:
    use_kwta      in {True, False}
    use_hebbian   in {True, False}
    use_growth    in {True, False}
    routing_mode  in {"learned", "random", "dense"}
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Optional
import json
import random
import yaml


# =====================================================================
# Sub-configs
# =====================================================================

@dataclass
class DataConfig:
    """Dataset / tokenization."""
    dataset_name: str = "roneneldan/TinyStories"   # HF dataset id
    data_fraction: float = 0.05                     # 5% slice for Phase 1 fast iteration
    seq_len: int = 256                              # chars per training sequence
    val_fraction: float = 0.05                      # 5% of the slice for validation
    num_workers: int = 4
    cache_dir: Optional[str] = None                 # HF cache override
    vocab_path: Optional[str] = None                # where to dump the learned char vocab


@dataclass
class ModelConfig:
    """Architecture. Shared by baseline and novel — only the FFN mechanism
    differs. The baseline is a standard transformer (attention + dense FFN);
    the novel model swaps the dense FFN for the lobe stack. See addendum #1.
    """
    # Embedding
    vocab_size: int = 0          # populated at runtime from tokenizer
    hidden_dim: int = 384
    max_seq_len: int = 512       # must be >= DataConfig.seq_len

    # Transformer block (shared)
    num_layers: int = 4
    num_heads: int = 6
    dropout: float = 0.1
    layernorm_eps: float = 1e-5

    # FFN dimensionality — interpreted differently per model:
    #   baseline: single dense FFN of size `ffn_dim` per layer
    #   novel:    each lobe's sub-network has `ffn_dim` neurons (before k-WTA);
    #             total novel FFN params = num_lobes * (hidden_dim * ffn_dim * 2)
    ffn_dim: int = 1024

    # Novel-only: lobe structure
    lobes_per_layer: int = 4
    top_k_lobes: int = 1                # how many lobes actually run per token (outer skip)
    kwta_ratio: float = 0.2             # keep top 20% of intra-lobe neurons (inner)

    # Tie output projection to input embedding (saves params; standard practice)
    tie_embeddings: bool = True


@dataclass
class HebbianConfig:
    """Per addendum #2: clamped, multiplicative-decay update rule."""
    enabled: bool = True
    increment: float = 0.01              # additive nudge for k-WTA winners
    decay_rate: float = 0.001            # multiplicative decay applied to ALL neurons each step
    clamp_min: float = 0.0
    clamp_max: float = 2.0               # documented choice: scale factor = (1+strength) ∈ [1, 3]


@dataclass
class GrowthConfig:
    """Per addendum #4: multi-signal saturation; per addendum #10: cooldown."""
    enabled: bool = True
    check_interval_steps: int = 500     # how often `check_saturation` is called per lobe
    rolling_window: int = 200           # batches averaged for the saturation signal
    confidence_threshold: float = 0.75  # mean confidence above this counts as saturated
    utilization_threshold: float = 0.85 # fraction of neurons regularly winning
    entropy_threshold: float = 0.90     # 0..1 normalized entropy of activations
    persistence_ratio: float = 0.95     # fraction of the rolling window that must exceed thresholds
    neurons_per_growth: int = 32        # new neurons added per growth event
    param_ceiling: int = 1_000_000_000  # hard cap: 1B params (Phase 2 ceiling)
    minimum_growth_interval: int = 5000 # cooldown steps between growth events on the SAME lobe


@dataclass
class AblationConfig:
    """Per addendum #3: full ablation grid as toggleable flags.

    The baseline_model ignores these entirely (it has no lobes/Hebbian/growth).
    The novel_model reads them to disable individual mechanisms.
    """
    use_kwta: bool = True
    use_hebbian: bool = True
    use_growth: bool = True
    # routing_mode:
    #   "learned" — confidence gate scores, top-k chosen (default)
    #   "random"  — random top-k assignment each forward (sanity check)
    #   "dense"   — all lobes run, no selection (isolates whether sparsity helps)
    routing_mode: str = "learned"


@dataclass
class TrainConfig:
    """Training loop hyperparameters."""
    seed: int = 42
    batch_size: int = 64
    grad_accum_steps: int = 1
    epochs: int = 2
    lr: float = 3e-4
    weight_decay: float = 0.1
    warmup_steps: int = 200
    lr_schedule: str = "cosine"          # "cosine" | "linear" | "constant"
    grad_clip: float = 1.0               # addendum #8

    # Mixed precision — addendum #7. ROCm bf16 is supported on RX 9060 XT.
    # Options: "bf16", "fp16", "fp32"
    use_amp: str = "bf16"

    # Logging
    log_interval_steps: int = 25
    eval_interval_steps: int = 500
    checkpoint_interval_steps: int = 1000
    run_dir: str = "runs/default"
    log_expanded: bool = True            # addendum #12: lobe conf, selection freq, etc.
    log_flops: bool = True               # addendum #13: hardware-independent compute metric


# =====================================================================
# Top-level config
# =====================================================================

@dataclass
class Config:
    data: DataConfig = field(default_factory=DataConfig)
    model: ModelConfig = field(default_factory=ModelConfig)
    hebbian: HebbianConfig = field(default_factory=HebbianConfig)
    growth: GrowthConfig = field(default_factory=GrowthConfig)
    ablation: AblationConfig = field(default_factory=AblationConfig)
    train: TrainConfig = field(default_factory=TrainConfig)

    # Which model variant this config builds: "baseline" or "novel"
    model_type: str = "novel"
    name: str = "default"
    notes: str = ""

    # ---------------------------------------------------------------
    # Constructors for common configs
    # ---------------------------------------------------------------
    @staticmethod
    def smoke() -> "Config":
        """Tiny config for smoke tests — fits in CPU memory, runs in seconds."""
        c = Config()
        c.name = "smoke"
        c.model_type = "novel"
        c.data.data_fraction = 0.001
        c.data.seq_len = 64
        c.data.num_workers = 0
        c.model.vocab_size = 128
        c.model.hidden_dim = 64
        c.model.max_seq_len = 128
        c.model.num_layers = 2
        c.model.num_heads = 4
        c.model.ffn_dim = 128
        c.model.lobes_per_layer = 4
        c.model.top_k_lobes = 1
        c.model.kwta_ratio = 0.25
        c.train.batch_size = 8
        c.train.epochs = 1
        c.train.lr = 3e-4
        c.train.use_amp = "fp32"
        c.train.log_interval_steps = 5
        c.train.eval_interval_steps = 20
        c.train.checkpoint_interval_steps = 50
        c.train.run_dir = "runs/smoke"
        c.growth.check_interval_steps = 10
        c.growth.rolling_window = 5
        c.growth.minimum_growth_interval = 20
        c.growth.neurons_per_growth = 4
        return c

    @staticmethod
    def phase1_baseline() -> "Config":
        """Phase 1 baseline — standard dense transformer, ~25M params."""
        c = Config()
        c.name = "phase1_baseline"
        c.model_type = "baseline"
        c.data.data_fraction = 0.05
        c.data.seq_len = 256
        c.model.hidden_dim = 384
        c.model.max_seq_len = 512
        c.model.num_layers = 4
        c.model.num_heads = 6
        c.model.ffn_dim = 1536
        c.train.batch_size = 64
        c.train.epochs = 2
        c.train.run_dir = "runs/phase1_baseline"
        c.train.use_amp = "bf16"
        return c

    @staticmethod
    def phase1_novel() -> "Config":
        """Phase 1 novel — lobes + k-WTA + Hebbian + growth, ~25M params.

        Tuned so total params roughly match phase1_baseline. The match is
        not exact (see baseline_model.py for the exact accounting) — we
        document the discrepancy in the training log.
        """
        c = Config()
        c.name = "phase1_novel"
        c.model_type = "novel"
        c.data.data_fraction = 0.05
        c.data.seq_len = 256
        c.model.hidden_dim = 384
        c.model.max_seq_len = 512
        c.model.num_layers = 4
        c.model.num_heads = 6
        c.model.ffn_dim = 384               # per-lobe (smaller; 4 lobes = 4x dense equiv)
        c.model.lobes_per_layer = 4
        c.model.top_k_lobes = 1
        c.model.kwta_ratio = 0.2
        c.train.batch_size = 64
        c.train.epochs = 2
        c.train.run_dir = "runs/phase1_novel"
        c.train.use_amp = "bf16"
        return c

    # ---------------------------------------------------------------
    # Serialization
    # ---------------------------------------------------------------
    def to_dict(self) -> dict:
        return asdict(self)

    def to_yaml(self) -> str:
        return yaml.safe_dump(self.to_dict(), default_flow_style=False, sort_keys=False)

    def save(self, path: str | Path) -> None:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(self.to_yaml())

    @classmethod
    def from_dict(cls, d: dict) -> "Config":
        c = cls()
        c.data = DataConfig(**d.get("data", {}))
        c.model = ModelConfig(**d.get("model", {}))
        c.hebbian = HebbianConfig(**d.get("hebbian", {}))
        c.growth = GrowthConfig(**d.get("growth", {}))
        c.ablation = AblationConfig(**d.get("ablation", {}))
        c.train = TrainConfig(**d.get("train", {}))
        c.model_type = d.get("model_type", c.model_type)
        c.name = d.get("name", c.name)
        c.notes = d.get("notes", c.notes)
        return c

    @classmethod
    def from_yaml(cls, yaml_str: str) -> "Config":
        return cls.from_dict(yaml.safe_load(yaml_str))

    @classmethod
    def load(cls, path: str | Path) -> "Config":
        return cls.from_yaml(Path(path).read_text())


# =====================================================================
# Reproducibility helpers — addendum #6
# =====================================================================

def set_seed(seed: int) -> None:
    """Set every relevant RNG so a run is bit-reproducible (modulo GPU
    non-determinism, which is documented separately in SETUP.md)."""
    random.seed(seed)
    try:
        import numpy as np
        np.random.seed(seed)
    except ImportError:
        pass
    try:
        import torch
        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)
        # Favor determinism for debugging; can be disabled for speed.
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
    except ImportError:
        pass


# =====================================================================
# Convenience: parameter counter (used everywhere)
# =====================================================================

def count_parameters(module) -> int:
    """Total trainable parameter count for a module."""
    try:
        import torch.nn as nn
        if isinstance(module, nn.Module):
            return sum(p.numel() for p in module.parameters() if p.requires_grad)
    except ImportError:
        pass
    return 0
