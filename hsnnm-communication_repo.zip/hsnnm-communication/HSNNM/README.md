# HSNNM 1 "Planck" (codename Sprout) — Brain-Inspired Language Model

**HSNNM** = **H**ebbian **S**parse **N**eural **N**etwork **M**odel — the architecture name.

**HSNNM 1 "Planck"** is the first-generation implementation:
- **1** = first generation (this is the prototype)
- **Planck** = the smallest meaningful scale in physics — a 7M-param model is vanishingly
  tiny compared to frontier LLMs (Llama 3 8B is 1,000× larger)
- **Codename "Sprout"** = double meaning: (a) the model literally grows new neurons
  via the net2net growth mechanism, and (b) it's the seedling that will grow into
  HSNNM 2, 3, etc.

A from-scratch (random init, no pretraining, no distillation) text-generation
architecture that layers three brain-inspired mechanisms on top of a standard
transformer backbone:

1. **Lobes with k-Winners-Take-All sparsity** (`model/lobe.py`) — replaces the
   dense FFN sublayer with N parallel experts. Each lobe scores its own
   relevance; only the top-k lobes actually run their FFN (real compute skip,
   not zero-after-compute). Inside each chosen lobe, k-WTA keeps only the
   top-k neuron activations.
2. **Hebbian strength tracking** (`model/hebbian.py`) — a non-gradient usage
   counter per neuron. Winners of k-WTA get a small strength bump; everyone
   else decays. Strength scales each neuron's activation, so frequently-used
   pathways amplify over time. Strictly clamped to a fixed range to prevent
   unbounded growth.
3. **Net2net growth** (`model/growth.py`) — when a lobe saturates (high
   confidence + high utilization + high entropy, sustained over a window),
   new neurons are added by duplicating a high-strength existing neuron plus
   small noise — not random init — so behavior isn't disrupted. Capped at a
   hard parameter ceiling.

A standard dense transformer (`model/baseline_model.py`) with **identical
parameter count** is included for fair comparison.

---

## The actual research question

> Does a sparse, Hebbian-strengthened, growth-capable FFN outperform a dense
> FFN of the same parameter count — measured on (a) final loss, (b) compute
> per token, (c) **catastrophic forgetting** on a sequential A→B task?

The forgetting test (`evaluation/forgetting_test.py`) is the make-or-break
evaluation. The hypothesis: Hebbian strengthening consolidates frequently-used
pathways, so learning Task B should disturb Task A less than in a pure-backprop
baseline. Whether the result confirms or refutes this, we report it honestly.

---

## Status

- **Phase 1** (10–50M params, TinyStories slice, char-level): implemented.
- **Phase 2** (≤1B params, full TinyStories, online surprise-triggered
  updates): scaffolded in `continual/online_update.py`, **not enabled** until
  Phase 1 validates.

---

## File map

```
data/dataset_loader.py    TinyStories loading, char tokenizer, batching
model/tokenizer.py         Char-level tokenizer (encode/decode/vocab)
model/embedding.py         Token + learned positional embeddings
model/lobe.py              CORE #1: lobe = confidence gate + k-WTA sparse FFN
model/hebbian.py           CORE #2: clamped Hebbian strength tracking
model/growth.py            CORE #3: net2net lobe growth with cooldown
model/novel_model.py       Full novel model (attention + lobe-FFN stack)
model/baseline_model.py    Standard dense transformer, matched param count
training/losses.py         Cross-entropy LM loss
training/checkpoint.py     Save/load with shape reconstruction + pre-update ckpts
training/train.py          Training loop (mixed precision, grad clip, ablations)
evaluation/compare.py      Side-by-side comparison + FLOPs/token
evaluation/forgetting_test.py  Catastrophic forgetting A→B test
evaluation/strength_map.py Hebbian strength heatmaps + expanded viz
continual/online_update.py Phase 2 surprise-triggered post-training updates
tests/                     Unit tests for all core novel components
config.py                  Centralized config (dataclass + YAML load)
```

---

## Quick start

```bash
# 1. Environment — follow SETUP.md (ROCm + torch 2.4.1+rocm6.1)
# 2. Install non-torch deps
pip install -r requirements.txt

# 3. Sanity-check the install
pytest tests/ -v

# 4. Smoke run (one forward+backward, both models, tiny config)
python -m training.train --config configs/smoke.yaml --dry-run

# 5. Phase 1 training — baseline vs. novel, side by side
python -m training.train --config configs/phase1_baseline.yaml
python -m training.train --config configs/phase1_novel.yaml
python -m evaluation.compare --baseline runs/phase1_baseline --novel runs/phase1_novel

# 6. Forgetting test (the real hypothesis)
python -m evaluation.forgetting_test --config configs/forget_A.yaml \
                                     --config2 configs/forget_B.yaml \
                                     --variant baseline
python -m evaluation.forgetting_test --config configs/forget_A.yaml \
                                     --config2 configs/forget_B.yaml \
                                     --variant novel

# 7. Visualize Hebbian specialization
python -m evaluation.strength_map --ckpt runs/phase1_novel/final.pt \
                                  --text-samples samples_dialogue.txt samples_descriptive.txt
```

---

## Ablation matrix

The config system supports the full ablation grid required by the spec
(see `config.py` → `AblationConfig`):

| Variant | `use_kwta` | `use_hebbian` | `use_growth` | `routing_mode` |
|---|---|---|---|---|
| Baseline (dense transformer) | — | — | — | — |
| Full novel | true | true | true | learned |
| No Hebbian | true | false | true | learned |
| No growth | true | true | false | learned |
| No k-WTA | false | true | true | learned |
| Random routing | true | true | true | random |
| Dense routing (all lobes) | true | true | true | dense |

Each row is a separate training run. `evaluation/compare.py` accepts multiple
`--variant` flags and overlays them on a single comparison plot.

---

## Critical implementation notes (read before touching the lobe code)

- **Outer compute-skip is real.** When a lobe is not selected by top-k routing,
  its FFN forward is *not executed at all* — the batch is sliced, only chosen
  lobes run, and outputs are scattered back. This is the only thing that gives
  the novel model a real FLOP advantage. Search `lobe.py` for `# OUTER-SKIP`
  comments.
- **Inner k-WTA is NOT a compute-skip in Phase 1.** Inside a chosen lobe, all
  neurons compute, then the top-k mask zeros out the rest. True sparse-matmul
  here is a stretch goal. Search `lobe.py` for `# INNER-NO-SKIP` comments.
- **Hebbian update is multiplicative-decay + clamped**, not the original
  unbounded additive rule. Search `hebbian.py` for `# CLAMP-FIX`.
- **Growth preserves optimizer state.** Adam moment buffers for existing
  neurons are copied unchanged; only the new neurons get fresh zero moments.
  Search `growth.py` for `# OPT-STATE-PRESERVE`.

---

## Honest expectations

This is a research project. It is not expected to beat any existing LLM on
fluency or benchmarks. Success means: the novel architecture behaves
**measurably differently** from the matched-parameter dense baseline — on loss
curves, on FLOPs/token, and especially on the catastrophic-forgetting test —
in whichever direction the data points. Negative results are valid and will
be reported as such.
