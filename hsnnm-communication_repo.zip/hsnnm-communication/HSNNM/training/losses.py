"""
training/losses.py — Standard cross-entropy LM loss.

Nothing novel. Shared by both baseline and novel models. The next-token
prediction target is `target_ids[:, 1:]` against logits from
`input_ids[:, :-1]`, but we pre-shifted in dataset_loader.py — so the
shapes already line up: logits (B, T, V), targets (B, T).

We ignore padding positions (target == pad_id) so they don't pollute the
loss.
"""
from __future__ import annotations

import torch
import torch.nn.functional as F


PAD_ID = 0  # matches model/tokenizer.py


def lm_loss(logits: torch.Tensor, targets: torch.Tensor,
            ignore_index: int = PAD_ID) -> torch.Tensor:
    """Standard cross-entropy loss for next-token prediction.

    Args:
      logits:  (B, T, V) float
      targets: (B, T) long
      ignore_index: target value to skip (default 0 = <pad>)

    Returns: scalar tensor (mean cross-entropy over non-pad positions).
    """
    B, T, V = logits.shape
    assert targets.shape == (B, T), \
        f"target shape {targets.shape} != ({B}, {T})"
    # Flatten for F.cross_entropy which expects (N, C) and (N,)
    return F.cross_entropy(
        logits.reshape(-1, V),
        targets.reshape(-1),
        ignore_index=ignore_index,
    )


def compute_token_accuracy(logits: torch.Tensor, targets: torch.Tensor,
                           ignore_index: int = PAD_ID) -> float:
    """Token-level top-1 accuracy, ignoring pad positions. For logging only."""
    preds = logits.argmax(dim=-1)                        # (B, T)
    mask = targets != ignore_index
    if mask.sum().item() == 0:
        return 0.0
    correct = (preds == targets) & mask
    return correct.sum().item() / mask.sum().item()
