"""
training/checkpoint.py — Save/load model + optimizer + Hebbian + lobe shapes.

The novel model's architecture changes over time (lobes grow), so loading
a checkpoint requires *reconstructing the model architecture at the saved
shape first*, then loading weights into it. We store per-lobe neuron
counts in the checkpoint for this purpose.

Also provides:
  - save_pre_update_checkpoint() — called before any growth event or any
    online update, so a bad update can be rolled back. Per spec:
    "bad updates are always revertible."
"""
from __future__ import annotations

from dataclasses import asdict
from pathlib import Path
from typing import Optional, Any
import json
import logging
import shutil
import time

import torch

from config import Config
from model.tokenizer import CharTokenizer

log = logging.getLogger(__name__)


# =====================================================================
# Save
# =====================================================================

def save_checkpoint(
    path: str | Path,
    model: torch.nn.Module,
    optimizer: Optional[torch.optim.Optimizer],
    tokenizer: CharTokenizer,
    config: Config,
    step: int,
    epoch: int,
    extra: Optional[dict] = None,
) -> None:
    """Save a full checkpoint.

    Contents:
      - model_state_dict   (weights + Hebbian strength buffers)
      - optimizer_state_dict (if optimizer given)
      - lobe_neuron_counts  (per-layer per-lobe ffn_dim — needed to rebuild
                              the architecture on load before loading weights)
      - tokenizer           (vocab JSON)
      - config              (full Config as YAML)
      - step, epoch
      - extra               (anything else the caller wants to stash)
    """
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)

    payload = {
        "model_state_dict": model.state_dict(),
        "optimizer_state_dict": optimizer.state_dict() if optimizer is not None else None,
        "step": int(step),
        "epoch": int(epoch),
        "extra": extra or {},
    }

    # Lobe neuron counts — needed to rebuild novel model architecture on load.
    lobe_counts = None
    if hasattr(model, "get_lobe_neuron_counts"):
        lobe_counts = model.get_lobe_neuron_counts()
    payload["lobe_neuron_counts"] = lobe_counts

    # Save tokenizer vocab inline (as a list of strings under "vocab").
    payload["tokenizer"] = tokenizer.to_dict()

    # Save config alongside (so a checkpoint is fully self-describing).
    payload["config"] = config.to_dict()

    # Use a tmp file + atomic rename so a crash mid-save can't corrupt
    # the existing checkpoint.
    tmp = path.with_suffix(path.suffix + ".tmp")
    torch.save(payload, tmp)
    tmp.replace(path)
    log.info("Checkpoint saved: %s (step=%d, epoch=%d, lobe_counts=%s)",
             path, step, epoch, lobe_counts)


# =====================================================================
# Pre-update checkpoint — for rollback safety
# =====================================================================

def save_pre_update_checkpoint(
    run_dir: str | Path,
    model: torch.nn.Module,
    optimizer: Optional[torch.optim.Optimizer],
    tokenizer: CharTokenizer,
    config: Config,
    step: int,
    epoch: int,
    tag: str,
) -> Path:
    """Save a pre-update checkpoint to `<run_dir>/pre_update_<tag>_<timestamp>.pt`.

    `tag` describes the kind of update that's about to happen (e.g.
    "growth_L0_l2", "online_update_batch42"). Used by:
      - train.py before any growth event
      - continual/online_update.py before any post-training update

    Returns the path saved to. Caller should keep this path so a bad
    update can be rolled back.
    """
    run_dir = Path(run_dir)
    ts = int(time.time())
    fname = f"pre_update_{tag}_{ts}.pt"
    path = run_dir / fname
    save_checkpoint(path, model, optimizer, tokenizer, config, step, epoch,
                    extra={"pre_update_tag": tag, "pre_update_timestamp": ts})
    return path


# =====================================================================
# Load
# =====================================================================

def load_checkpoint(
    path: str | Path,
    model: Optional[torch.nn.Module] = None,
    optimizer: Optional[torch.optim.Optimizer] = None,
    config: Optional[Config] = None,
    reconstruct_novel_model: bool = True,
    device: str | torch.device = "cpu",
) -> dict:
    """Load a checkpoint.

    If `model` is None, we reconstruct it from the saved config + lobe
    neuron counts (this is how we recover after growth has changed the
    architecture). The reconstructed model is returned in the payload dict
    under "model".

    Returns a dict with at least: {model, optimizer (or None), tokenizer,
    config, step, epoch, extra, lobe_neuron_counts}.
    """
    path = Path(path)
    payload = torch.load(path, map_location=device, weights_only=False)

    saved_cfg = Config.from_dict(payload["config"])

    # Reconstruct model if not provided.
    if model is None:
        model = _reconstruct_model(saved_cfg, payload.get("lobe_neuron_counts"))

    # Load weights.
    model.load_state_dict(payload["model_state_dict"])
    model.to(device)

    # Optimizer.
    if optimizer is not None and payload["optimizer_state_dict"] is not None:
        try:
            optimizer.load_state_dict(payload["optimizer_state_dict"])
        except (ValueError, KeyError) as e:
            log.warning("Optimizer state load failed (%s) — starting fresh optimizer.", e)

    # Tokenizer.
    tokenizer = CharTokenizer.from_dict(payload["tokenizer"])

    return {
        "model": model,
        "optimizer": optimizer,
        "tokenizer": tokenizer,
        "config": saved_cfg,
        "step": payload["step"],
        "epoch": payload["epoch"],
        "extra": payload.get("extra", {}),
        "lobe_neuron_counts": payload.get("lobe_neuron_counts"),
    }


def _reconstruct_model(config: Config, lobe_neuron_counts) -> torch.nn.Module:
    """Build a fresh model from config, then resize each LobeLayer's lobes
    to match the saved per-lobe ffn_dim (which may have grown during the
    saved run). This must happen BEFORE load_state_dict so shapes match.
    """
    if config.model_type == "baseline":
        from model.baseline_model import build_baseline_model
        m = build_baseline_model(config)
        return m
    elif config.model_type == "novel":
        from model.novel_model import build_novel_model
        m = build_novel_model(config)
        if lobe_neuron_counts is not None:
            # Resize each lobe to its saved neuron count. We use grow_neurons
            # with donor_idx=0 — the actual donor doesn't matter here because
            # we're about to overwrite the weights from the state_dict.
            for li, layer_counts in enumerate(lobe_neuron_counts):
                # model.layers[li] is a NovelTransformerBlock; the LobeLayer
                # is at .lobe_layer; lobes are at .lobe_layer.lobes.
                lobe_layer = m.layers[li].lobe_layer
                for lj, target_ffn_dim in enumerate(layer_counts):
                    current = lobe_layer.lobes[lj].ffn_dim
                    if target_ffn_dim > current:
                        n_new = target_ffn_dim - current
                        lobe_layer.grow_lobe(lj, n_new, donor_idx=0, noise_scale=0.0)
                    elif target_ffn_dim < current:
                        # Shouldn't happen (we never shrink), but handle gracefully.
                        log.warning("Saved lobe ffn_dim %d < current %d — not shrinking.",
                                    target_ffn_dim, current)
        return m
    else:
        raise ValueError(f"Unknown model_type: {config.model_type}")


# =====================================================================
# Rollback
# =====================================================================

def rollback_to_pre_update(
    pre_update_path: str | Path,
    current_run_dir: str | Path,
    optimizer_factory,
    device: str | torch.device = "cpu",
) -> dict:
    """Restore model + optimizer + tokenizer from a pre-update checkpoint.

    Used when a growth event or online update degrades the model. The
    caller passes an `optimizer_factory` (callable that takes the model
    and returns a fresh optimizer) because we don't know which optimizer
    class was in use.
    """
    log.warning("ROLLBACK: restoring from %s", pre_update_path)
    payload = load_checkpoint(pre_update_path, model=None,
                              optimizer=None, device=device)
    model = payload["model"]
    optimizer = optimizer_factory(model)
    # Try to restore optimizer state too.
    if payload["optimizer_state_dict"] is not None:  # need to reload with optimizer
        payload2 = load_checkpoint(pre_update_path, model=model,
                                   optimizer=optimizer, device=device)
        optimizer = payload2["optimizer"]
    # Overwrite the current "latest" checkpoint with the rolled-back state.
    save_checkpoint(Path(current_run_dir) / "latest.pt", model, optimizer,
                    payload["tokenizer"], payload["config"],
                    payload["step"], payload["epoch"],
                    extra={"rolled_back_from": str(pre_update_path)})
    return {"model": model, "optimizer": optimizer, **payload}
