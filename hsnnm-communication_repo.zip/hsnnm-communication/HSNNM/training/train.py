"""
training/train.py — Training loop, shared by baseline and novel models.

Features (per addenda):
  - #7 Mixed precision: bf16 on ROCm (default), fp16 with GradScaler fallback, fp32.
  - #8 Gradient clipping (max_norm=1.0 default).
  - #3 Ablation flags honored via config.ablation — every variant in the
        README matrix is runnable from this same script.
  - #6 Seed set at start of every run; seed saved with every checkpoint.
  - #10 Growth cooldown enforced inside GrowthMonitor.
  - #9 Optimizer state preserved across growth (handled inside GrowthMonitor).
  - #11 Pre-update checkpoints before every growth event — for rollback.
  - #12 Expanded logging: per-layer lobe conf, selection freq, Hebbian
        histograms, growth events, current param count, lr, tokens/sec,
        wall-clock per step, GPU mem.
  - #13 FLOPs/token tracked (hardware-independent compute metric).
  - Resume from checkpoint.
  - --dry-run mode: builds both models, runs one fwd+bwd on a tiny batch,
        exits. Used by SETUP.md sanity check.

Usage:
    python -m training.train --config configs/phase1_novel.yaml
    python -m training.train --config configs/smoke.yaml --dry-run
    python -m training.train --config configs/phase1_novel.yaml --resume runs/phase1_novel/latest.pt
"""
from __future__ import annotations

from dataclasses import asdict
from pathlib import Path
import argparse
import json
import logging
import math
import os
import sys
import time
from typing import Optional

import torch
import torch.nn as nn

# Make project root importable when running as `python -m training.train`.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from config import Config, set_seed, count_parameters
from model.tokenizer import CharTokenizer
from model.baseline_model import build_baseline_model
from model.novel_model import build_novel_model
from training.losses import lm_loss, compute_token_accuracy
from training.checkpoint import save_checkpoint, load_checkpoint, save_pre_update_checkpoint
from data.dataset_loader import make_dataloaders

log = logging.getLogger("train")


# =====================================================================
# Optimizer + LR scheduler
# =====================================================================

def build_optimizer(model: nn.Module, config: Config) -> torch.optim.Optimizer:
    """AdamW with weight decay applied only to weight matrices (not biases
    or LayerNorm gains)."""
    decay, no_decay = [], []
    for name, p in model.named_parameters():
        if not p.requires_grad:
            continue
        if p.ndim < 2 or name.endswith(".bias") or "ln" in name.lower() or "layernorm" in name.lower():
            no_decay.append(p)
        else:
            decay.append(p)
    return torch.optim.AdamW(
        [
            {"params": decay, "weight_decay": config.train.weight_decay},
            {"params": no_decay, "weight_decay": 0.0},
        ],
        lr=config.train.lr,
        betas=(0.9, 0.95),
        eps=1e-8,
    )


def build_lr_scheduler(optimizer, config: Config, total_steps: int):
    """Cosine schedule with linear warmup."""
    warmup = config.train.warmup_steps
    if config.train.lr_schedule == "constant":
        return torch.optim.lr_scheduler.LambdaLR(optimizer, lambda s: 1.0)
    if config.train.lr_schedule == "linear":
        def f(s):
            if s < warmup:
                return s / max(1, warmup)
            return max(0.0, (total_steps - s) / max(1, total_steps - warmup))
        return torch.optim.lr_scheduler.LambdaLR(optimizer, f)
    # default: cosine
    def f(s):
        if s < warmup:
            return s / max(1, warmup)
        progress = (s - warmup) / max(1, total_steps - warmup)
        return 0.5 * (1.0 + math.cos(math.pi * progress))
    return torch.optim.lr_scheduler.LambdaLR(optimizer, f)


# =====================================================================
# Pre-update checkpoint cleanup — prevent disk fill
# =====================================================================

def _cleanup_pre_update_checkpoints(run_dir: Path, keep_per_lobe: int = 3) -> None:
    """Keep only the latest `keep_per_lobe` pre-update checkpoints per
    (layer, lobe) pair. Older ones are deleted.

    Filenames look like: pre_update_growth_L{layer}_l{lobe}_step{N}_{ts}.pt
    """
    if not run_dir.exists():
        return
    # Group by (layer, lobe).
    from collections import defaultdict
    by_lobe = defaultdict(list)
    for p in run_dir.glob("pre_update_growth_*.pt"):
        # Parse: pre_update_growth_L0_l2_step1460_1783168528.pt
        name = p.stem  # without .pt
        parts = name.split("_")
        try:
            # ['pre', 'update', 'growth', 'L0', 'l2', 'step1460', '1783168528']
            layer_lobe = (parts[3], parts[4])
            step = int(parts[5].replace("step", ""))
            by_lobe[layer_lobe].append((step, p))
        except (IndexError, ValueError):
            continue
    for key, entries in by_lobe.items():
        if len(entries) <= keep_per_lobe:
            continue
        # Sort by step descending, keep the latest `keep_per_lobe`.
        entries.sort(key=lambda x: x[0], reverse=True)
        for _, p in entries[keep_per_lobe:]:
            try:
                p.unlink()
            except OSError:
                pass


# =====================================================================
# Mixed precision context (addendum #7)
# =====================================================================

class AMPContext:
    """Wraps torch.autocast + GradScaler in a single object so the training
    loop doesn't have to branch on precision mode every step.

    On ROCm: bf16 is the documented default for RX 9060 XT (see SETUP.md).
    Fallback chain: bf16 -> fp16 (with GradScaler) -> fp32.
    """

    def __init__(self, mode: str, device: str):
        self.mode = mode
        self.device = device
        self.scaler = torch.amp.GradScaler(device) if mode == "fp16" else None

    def autocast(self):
        if self.mode == "bf16":
            return torch.autocast(device_type=self.device, dtype=torch.bfloat16)
        if self.mode == "fp16":
            return torch.autocast(device_type=self.device, dtype=torch.float16)
        # fp32 — no-op context manager
        from contextlib import nullcontext
        return nullcontext()

    def scale_loss(self, loss: torch.Tensor) -> torch.Tensor:
        if self.scaler is not None:
            return self.scaler.scale(loss)
        return loss

    def unscale_and_step(self, optimizer, model, max_norm: float):
        if self.scaler is not None:
            self.scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm)
            self.scaler.step(optimizer)
            self.scaler.update()
        else:
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm)
            optimizer.step()


# =====================================================================
# FLOPs estimation (addendum #13)
# =====================================================================

def estimate_flops_per_token(model: nn.Module, config: Config) -> int:
    """Rough FLOPs/token estimate. Hardware-independent.

    Counts matmul FLOPs (2 * M * N * K per matmul of shapes (M,K)x(K,N)).
    Ignores LayerNorm, softmax, activations — they're <5% of total.

    For the baseline: 2*H*H*3 (QKV) + 2*H*H (proj) + 2*H*F + 2*H*F (FFN) per layer
                     + 2*H*V (lm_head)
    For the novel:    2*H*H*3 + 2*H*H (attention, same) +
                      per layer, per lobe: 2*H*F + 2*H*F (FFN of size F)
                      but only `top_k` lobes run per token, so multiply by top_k.
                      + gate cost: num_lobes * 2*H*1 per token.
                      + 2*H*V (lm_head)
    """
    m = config.model
    H = m.hidden_dim
    V = m.vocab_size
    F = m.ffn_dim
    L = m.num_layers
    if config.model_type == "baseline":
        per_layer = 2*H*H*3 + 2*H*H + 2*H*F + 2*H*F
        return per_layer * L + 2*H*V
    else:
        # Novel: attention same; FFN replaced by lobe layer
        n_lobes = m.lobes_per_layer
        top_k = m.top_k_lobes if config.ablation.routing_mode == "learned" else (
            n_lobes if config.ablation.routing_mode == "dense" else m.top_k_lobes
        )
        # gate cost (all lobes always compute gate)
        gate = n_lobes * 2 * H * 1
        # ffn cost (only top_k lobes run)
        ffn = top_k * (2*H*F + 2*H*F)
        per_layer = 2*H*H*3 + 2*H*H + gate + ffn
        return per_layer * L + 2*H*V


# =====================================================================
# Logger
# =====================================================================

class RunLogger:
    """Per-step structured logging to a JSONL file + TensorBoard if available."""

    def __init__(self, run_dir: Path, use_tb: bool = True):
        self.run_dir = run_dir
        self.run_dir.mkdir(parents=True, exist_ok=True)
        self.jsonl_path = run_dir / "log.jsonl"
        self.jsonl_file = open(self.jsonl_path, "a", buffering=1)  # line-buffered
        self.tb = None
        if use_tb:
            try:
                from torch.utils.tensorboard import SummaryWriter
                self.tb = SummaryWriter(log_dir=str(run_dir / "tb"))
            except Exception as e:
                log.warning("TensorBoard init failed: %s", e)

    def log(self, record: dict) -> None:
        self.jsonl_file.write(json.dumps(record) + "\n")
        if self.tb is not None:
            step = record.get("step", 0)
            for k, v in record.items():
                if isinstance(v, (int, float)) and k != "step":
                    self.tb.add_scalar(k, v, step)

    def close(self) -> None:
        self.jsonl_file.close()
        if self.tb is not None:
            self.tb.close()


# =====================================================================
# Main training loop
# =====================================================================

def train(config: Config, resume_path: Optional[str] = None,
          dry_run: bool = False) -> None:
    set_seed(config.train.seed)
    # Explicitly pin to cuda:0 (single GPU). On multi-GPU machines you'd
    # want to parameterize this, but for this project (one GPU) we hard-pin
    # to avoid any cross-device tensor mismatches. Equivalent to device_map={"": 0}
    # in HuggingFace parlance — our code uses vanilla PyTorch, not HF.
    device = "cuda:0" if torch.cuda.is_available() else "cpu"
    log.info("Device: %s", device)
    if device != "cpu":
        log.info("GPU: %s", torch.cuda.get_device_name(0))

    run_dir = Path(config.train.run_dir)
    run_dir.mkdir(parents=True, exist_ok=True)
    config.save(run_dir / "config.yaml")
    run_logger = RunLogger(run_dir, use_tb=config.train.log_expanded)

    # --- Build dataloaders ---
    tokenizer, train_loader, val_loader = make_dataloaders(
        fraction=config.data.data_fraction,
        seq_len=config.data.seq_len,
        batch_size=config.train.batch_size,
        val_fraction=config.data.val_fraction,
        num_workers=config.data.num_workers,
        cache_dir=config.data.cache_dir,
        seed=config.train.seed,
    )
    # Update config with the realized vocab size (in case it was 0 in the YAML).
    config.model.vocab_size = tokenizer.vocab_size

    # --- Build model ---
    if config.model_type == "baseline":
        model = build_baseline_model(config)
    elif config.model_type == "novel":
        model = build_novel_model(config)
    else:
        raise ValueError(f"Unknown model_type: {config.model_type}")
    model.to(device)

    optimizer = build_optimizer(model, config)
    total_steps = config.train.epochs * len(train_loader) // config.train.grad_accum_steps
    scheduler = build_lr_scheduler(optimizer, config, total_steps)
    amp = AMPContext(config.train.use_amp, device_type_str(device))  # noqa: B028

    # --- Growth monitor (novel only) ---
    growth_monitor = None
    if config.model_type == "novel" and config.growth.enabled and config.ablation.use_growth:
        growth_monitor = model.attach_growth_monitor()
        log.info("Growth monitor attached.")

    # --- Resume ---
    start_step, start_epoch = 0, 0
    if resume_path:
        payload = load_checkpoint(resume_path, model=model, optimizer=optimizer,
                                  config=config, device=device)
        start_step = payload["step"]
        start_epoch = payload["epoch"]
        log.info("Resumed from %s at step=%d epoch=%d", resume_path, start_step, start_epoch)

    # --- Param report ---
    param_report = model.parameter_report()
    flops_per_token = estimate_flops_per_token(model, config)
    log.info("Parameter report:\n%s", json.dumps(param_report, indent=2))
    log.info("Total trainable params: %d", count_parameters(model))
    log.info("Estimated FLOPs/token: %d", flops_per_token)
    run_logger.log({
        "event": "init",
        "step": start_step,
        "param_report": param_report,
        "total_params": count_parameters(model),
        "flops_per_token": flops_per_token,
        "config": config.to_dict(),
        "vocab_size": tokenizer.vocab_size,
    })

    # --- Dry run: one fwd+bwd, then exit ---
    if dry_run:
        log.info("DRY RUN: executing one fwd+bwd and exiting.")
        batch = next(iter(train_loader))
        x, y = batch[0].to(device), batch[1].to(device)
        with amp.autocast():
            if config.model_type == "novel":
                logits, diag = model(x)
            else:
                logits = model(x)
                diag = {}
            loss = lm_loss(logits, y)
        optimizer.zero_grad()
        scaled = amp.scale_loss(loss)
        scaled.backward()
        amp.unscale_and_step(optimizer, model, config.train.grad_clip)
        log.info("DRY RUN OK. loss=%.4f", loss.item())
        run_logger.close()
        return

    # --- Training loop ---
    step = start_step
    accum = 0
    train_start = time.time()
    for epoch in range(start_epoch, config.train.epochs):
        model.train()
        for batch in train_loader:
            x, y = batch[0].to(device, non_blocking=True), batch[1].to(device, non_blocking=True)
            t0 = time.time()
            with amp.autocast():
                if config.model_type == "novel":
                    logits, diag = model(x)  # Hebbian update happens inside
                else:
                    logits = model(x)
                    diag = {}
                loss = lm_loss(logits, y) / config.train.grad_accum_steps

            scaled = amp.scale_loss(loss)
            # NaN/Inf guard — bf16 can occasionally produce NaN losses,
            # especially early in training or after a growth event. Skip
            # the step (don't update weights) rather than poisoning Adam's
            # moment buffers with NaN gradients.
            if not torch.isfinite(scaled):
                log.warning("Non-finite loss (%.4f) at step %d — skipping update.",
                            loss.item(), step + 1)
                optimizer.zero_grad()
                accum = 0
                continue
            scaled.backward()
            accum += 1

            if accum >= config.train.grad_accum_steps:
                amp.unscale_and_step(optimizer, model, config.train.grad_clip)
                optimizer.zero_grad()
                scheduler.step()
                accum = 0
                step += 1

                # Per-step logging (expanded — addendum #12)
                if step % config.train.log_interval_steps == 0:
                    record = {
                        "event": "train_step",
                        "step": step,
                        "epoch": epoch,
                        "loss": loss.item() * config.train.grad_accum_steps,
                        "lr": scheduler.get_last_lr()[0],
                        "tokens_per_sec": (config.train.batch_size * config.data.seq_len) / (time.time() - t0),
                        "wall_clock_per_step_s": time.time() - t0,
                        "grad_accum_steps": config.train.grad_accum_steps,
                    }
                    if device != "cpu":
                        record["gpu_mem_alloc_mb"] = torch.cuda.memory_allocated() / 1e6
                        record["gpu_mem_peak_mb"] = torch.cuda.max_memory_allocated() / 1e6
                    if config.model_type == "novel" and config.train.log_expanded:
                        record["hebbian_stats"] = diag.get("hebbian_stats", [])
                        # Per-layer lobe selection frequency
                        lobe_counts_all = []
                        for li, ld in enumerate(diag["per_layer"]):
                            lobe_counts_all.append(ld["per_lobe_execution_count"])
                        record["lobe_execution_counts"] = lobe_counts_all
                        record["effective_top_k"] = diag["per_layer"][0]["effective_top_k"]
                    run_logger.log(record)

                # Periodic eval + checkpoint
                if step % config.train.eval_interval_steps == 0:
                    val_loss, val_acc = evaluate(model, val_loader, device, amp, config)
                    model.train()
                    run_logger.log({
                        "event": "eval",
                        "step": step,
                        "val_loss": val_loss,
                        "val_token_accuracy": val_acc,
                    })
                    log.info("step=%d epoch=%d loss=%.4f val_loss=%.4f val_acc=%.3f",
                             step, epoch, loss.item() * config.train.grad_accum_steps,
                             val_loss, val_acc)

                if step % config.train.checkpoint_interval_steps == 0:
                    save_checkpoint(run_dir / "latest.pt", model, optimizer,
                                    tokenizer, config, step, epoch)

                # Push growth signals EVERY step (cheap — just appends to a
                # deque). The actual growth CHECK happens less frequently
                # (see `if step % config.growth.check_interval_steps == 0`
                # below). This way the rolling_window is in units of STEPS,
                # not checks — so window=200 means "last 200 steps", which
                # is what the config semantics imply.
                if (growth_monitor is not None and config.model_type == "novel"
                        and "per_layer" in diag):
                    model.push_growth_signals(diag, growth_monitor)
                    growth_monitor.advance_step()

                # Growth check (novel only) — addendum #4 + #10 + #11
                # Per spec: "Checkpointing before any growth event — save
                # model state right before a growth trigger fires, so a bad
                # growth event can be rolled back and logged as a data point."
                if (growth_monitor is not None
                        and step % config.growth.check_interval_steps == 0):

                    # Pre-check every (layer, lobe) individually so we can
                    # save a pre-update checkpoint BEFORE the resize happens.
                    # Then grow. Any growth event is logged with its pre-
                    # update checkpoint path for rollback.
                    events = []
                    for li in range(growth_monitor.num_layers):
                        for lj in range(growth_monitor.num_lobes_per_layer):
                            should, detail = growth_monitor.check_saturation(li, lj)
                            if not should:
                                continue
                            # Pre-update checkpoint for rollback safety.
                            tag = f"growth_L{li}_l{lj}_step{step}"
                            pre_path = save_pre_update_checkpoint(
                                run_dir, model, optimizer, tokenizer,
                                config, step, epoch, tag=tag,
                            )
                            # Grow.
                            ev = growth_monitor.grow_lobe(
                                li, lj,
                                hebbian_tracker=(model.hebbian_trackers[li]
                                                  if li < len(model.hebbian_trackers) else None),
                                optimizer=optimizer,
                            )
                            ev["pre_update_checkpoint"] = str(pre_path)
                            ev["saturation_detail"] = detail
                            events.append(ev)

                    for ev in events:
                        run_logger.log({"event": "growth", **ev, "step": step})
                        log.warning(
                            "GROWTH EVENT at step %d: layer=%d lobe=%d old_ffn=%d new_ffn=%d "
                            "(pre-update checkpoint: %s)",
                            step, ev["layer"], ev["lobe"],
                            ev["old_ffn_dim"], ev["new_ffn_dim"],
                            ev["pre_update_checkpoint"],
                        )

                    # Pre-update checkpoint cleanup: keep only the latest
                    # `max_pre_update_ckpts` per (layer, lobe) to prevent
                    # disk fill in pathological saturation cases.
                    _cleanup_pre_update_checkpoints(run_dir, keep_per_lobe=3)

                if step >= total_steps:
                    break

        # End of epoch — always checkpoint
        save_checkpoint(run_dir / f"epoch{epoch}.pt", model, optimizer,
                        tokenizer, config, step, epoch)

    # Final checkpoint
    save_checkpoint(run_dir / "final.pt", model, optimizer, tokenizer,
                    config, step, epoch)
    run_logger.log({
        "event": "train_done",
        "step": step,
        "total_time_s": time.time() - train_start,
        "total_params": count_parameters(model),
    })
    run_logger.close()
    log.info("Training complete. Total time: %.1fs", time.time() - train_start)


def device_type_str(device: str) -> str:
    """torch.autocast wants device_type without index, e.g. 'cuda' not 'cuda:0'."""
    return device.split(":")[0]


# =====================================================================
# Eval
# =====================================================================

def evaluate(model, val_loader, device, amp, config: Config) -> tuple:
    model.eval()
    total_loss, total_acc, n = 0.0, 0.0, 0
    with torch.no_grad():
        for batch in val_loader:
            x, y = batch[0].to(device), batch[1].to(device)
            with amp.autocast():
                if config.model_type == "novel":
                    logits, _ = model(x, update_hebbian=False)
                else:
                    logits = model(x)
                loss = lm_loss(logits, y)
            total_loss += loss.item() * x.size(0)
            total_acc += compute_token_accuracy(logits, y) * x.size(0)
            n += x.size(0)
            if n >= 50 * config.train.batch_size:  # cap eval batches for speed
                break
    return total_loss / max(1, n), total_acc / max(1, n)


# =====================================================================
# CLI
# =====================================================================

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True, help="Path to YAML config")
    parser.add_argument("--resume", default=None, help="Path to checkpoint to resume from")
    parser.add_argument("--dry-run", action="store_true",
                        help="Build model, run one fwd+bwd, exit (sanity check)")
    parser.add_argument("--log-level", default="INFO")
    args = parser.parse_args()

    logging.basicConfig(
        level=args.log_level,
        format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
        handlers=[logging.StreamHandler()],
    )

    config = Config.load(args.config)
    train(config, resume_path=args.resume, dry_run=args.dry_run)


if __name__ == "__main__":
    main()
