"""
scripts/smoke_test.py — End-to-end smoke test of the full pipeline.

Builds both baseline and novel models at smoke-test scale, runs a few
training steps on synthetic data (no TinyStories download required), and
verifies:
  1. Both models forward+backward without crashing.
  2. The novel model's lobe routing produces the expected diagnostics.
  3. Hebbian strength updates actually happen during training.
  4. Growth can fire and resize tensors without breaking the optimizer.
  5. Checkpoint save/load round-trips correctly (including post-growth).
  6. The FLOPs-per-token estimator produces sane numbers.

If this script exits 0, the codebase is structurally sound. Real training
still needs the SETUP.md ROCm environment.
"""
from __future__ import annotations

import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import torch

from config import Config, set_seed, count_parameters
from model.tokenizer import CharTokenizer
from model.baseline_model import build_baseline_model
from model.novel_model import build_novel_model
from training.losses import lm_loss
from training.train import build_optimizer, build_lr_scheduler, AMPContext, device_type_str, estimate_flops_per_token
from training.checkpoint import save_checkpoint, load_checkpoint


def make_synthetic_tokenizer(vocab_size: int = 80) -> CharTokenizer:
    """Build a tokenizer with a deterministic vocab of size N."""
    chars = [chr(ord("a") + i) for i in range(26)]
    chars += [chr(ord("A") + i) for i in range(26)]
    chars += [str(i) for i in range(10)]
    chars += [" ", ".", ",", "!", "?", "\n", '"', "'", "-", ":", ";", "(", ")"]
    chars = chars[:vocab_size - 2]  # leave room for <pad>, <unk>
    return CharTokenizer(vocab=["<pad>", "<unk>"] + chars)


def make_synthetic_batch(tokenizer, batch_size, seq_len, device):
    """Random token IDs in [2, vocab_size) — never <pad> or <unk>."""
    ids = torch.randint(2, tokenizer.vocab_size, (batch_size, seq_len + 1),
                        device=device)
    return ids[:, :-1].contiguous(), ids[:, 1:].contiguous()


# =====================================================================
# Test 1: baseline forward + backward
# =====================================================================
def test_baseline_fwd_bwd(device):
    print("\n=== Test 1: baseline forward + backward ===")
    cfg = Config.smoke()
    cfg.model_type = "baseline"
    cfg.model.vocab_size = 80
    cfg.model.tie_embeddings = False  # so param counts are obvious
    cfg.train.use_amp = "fp32"  # CPU-only — no AMP
    set_seed(cfg.train.seed)

    tok = make_synthetic_tokenizer(cfg.model.vocab_size)
    model = build_baseline_model(cfg).to(device)
    optim = build_optimizer(model, cfg)
    amp = AMPContext(cfg.train.use_amp, device_type_str(device))

    print(f"  baseline params: {count_parameters(model):,}")
    print(f"  baseline FLOPs/token: {estimate_flops_per_token(model, cfg):,}")

    x, y = make_synthetic_batch(tok, cfg.train.batch_size, cfg.data.seq_len, device)
    with amp.autocast():
        logits = model(x)
        loss = lm_loss(logits, y)
    optim.zero_grad()
    scaled = amp.scale_loss(loss)
    scaled.backward()
    amp.unscale_and_step(optim, model, cfg.train.grad_clip)
    print(f"  loss after 1 step: {loss.item():.4f}")
    assert loss.item() > 0, "loss should be positive"
    assert logits.shape == (cfg.train.batch_size, cfg.data.seq_len, cfg.model.vocab_size)
    print("  PASS")


# =====================================================================
# Test 2: novel forward + backward + Hebbian update
# =====================================================================
def test_novel_fwd_bwd_hebbian(device):
    print("\n=== Test 2: novel forward + backward + Hebbian ===")
    cfg = Config.smoke()
    cfg.model_type = "novel"
    cfg.model.vocab_size = 80
    cfg.model.tie_embeddings = False
    cfg.train.use_amp = "fp32"
    cfg.hebbian.enabled = True
    cfg.ablation.use_hebbian = True
    set_seed(cfg.train.seed)

    tok = make_synthetic_tokenizer(cfg.model.vocab_size)
    model = build_novel_model(cfg).to(device)
    optim = build_optimizer(model, cfg)
    amp = AMPContext(cfg.train.use_amp, device_type_str(device))

    print(f"  novel params: {count_parameters(model):,}")
    print(f"  novel FLOPs/token: {estimate_flops_per_token(model, cfg):,}")
    print(f"  lobe neuron counts: {model.get_lobe_neuron_counts()}")

    # Capture strength stats BEFORE training step.
    s_before = model.hebbian_trackers[0].get_strength_stats()

    x, y = make_synthetic_batch(tok, cfg.train.batch_size, cfg.data.seq_len, device)
    model.train()
    with amp.autocast():
        logits, diag = model(x)  # Hebbian update happens inside
        loss = lm_loss(logits, y)
    optim.zero_grad()
    scaled = amp.scale_loss(loss)
    scaled.backward()
    amp.unscale_and_step(optim, model, cfg.train.grad_clip)

    s_after = model.hebbian_trackers[0].get_strength_stats()
    print(f"  loss: {loss.item():.4f}")
    print(f"  strength before: mean={s_before['mean']:.6f} max={s_before['max']:.6f}")
    print(f"  strength after:  mean={s_after['mean']:.6f} max={s_after['max']:.6f}")
    assert s_after["max"] > s_before["max"], "Hebbian strength should have grown"
    assert s_after["max"] <= cfg.hebbian.clamp_max + 1e-6, "strength must respect clamp"

    # Check diagnostics structure
    assert "per_layer" in diag
    assert len(diag["per_layer"]) == cfg.model.num_layers
    assert diag["hebbian_enabled"] is True
    print("  PASS")


# =====================================================================
# Test 3: Growth fires and resizes without breaking the optimizer
# =====================================================================
def test_growth_fires_and_optim_survives(device):
    print("\n=== Test 3: growth fires + optimizer survives ===")
    cfg = Config.smoke()
    cfg.model_type = "novel"
    cfg.model.vocab_size = 80
    cfg.model.tie_embeddings = False
    cfg.train.use_amp = "fp32"
    cfg.hebbian.enabled = True
    cfg.ablation.use_growth = True
    cfg.growth.enabled = True
    cfg.growth.rolling_window = 2
    cfg.growth.persistence_ratio = 0.0  # always pass
    cfg.growth.confidence_threshold = 0.0
    cfg.growth.utilization_threshold = 0.0
    cfg.growth.entropy_threshold = 0.0
    cfg.growth.minimum_growth_interval = 0
    cfg.growth.neurons_per_growth = 4
    set_seed(cfg.train.seed)

    tok = make_synthetic_tokenizer(cfg.model.vocab_size)
    model = build_novel_model(cfg).to(device)
    optim = build_optimizer(model, cfg)
    growth_monitor = model.attach_growth_monitor()

    # Run a few forward passes to populate Adam state and growth windows.
    model.train()
    for _ in range(3):
        x, y = make_synthetic_batch(tok, cfg.train.batch_size, cfg.data.seq_len, device)
        with torch.no_grad():
            pass  # just need diagnostics
        # Manually push growth signals with high values
        for li in range(growth_monitor.num_layers):
            for lj in range(growth_monitor.num_lobes_per_layer):
                growth_monitor.step(li, lj, 0.95, 0.95, 0.95)
        growth_monitor.advance_step()

    # Run a real backward so Adam state populates.
    with torch.no_grad():
        pass
    x, y = make_synthetic_batch(tok, cfg.train.batch_size, cfg.data.seq_len, device)
    logits, diag = model(x)
    loss = lm_loss(logits, y)
    optim.zero_grad()
    loss.backward()
    optim.step()
    # Push signals after the step
    for li in range(growth_monitor.num_layers):
        for lj in range(growth_monitor.num_lobes_per_layer):
            growth_monitor.step(li, lj, 0.95, 0.95, 0.95)
    growth_monitor.advance_step()

    counts_before = model.get_lobe_neuron_counts()
    print(f"  lobe counts before growth: {counts_before}")

    # Force a growth event on lobe (0, 0).
    ev = growth_monitor.grow_lobe(0, 0, hebbian_tracker=model.hebbian_trackers[0],
                                   optimizer=optim)
    counts_after = model.get_lobe_neuron_counts()
    print(f"  lobe counts after growth:  {counts_after}")
    print(f"  growth event: layer={ev['layer']} lobe={ev['lobe']} "
          f"old={ev['old_ffn_dim']} new={ev['new_ffn_dim']}")

    assert counts_after[0][0] == counts_before[0][0] + 4

    # Now run another forward+backward — must not crash, and the new
    # parameters must receive gradients (verified by checking they're in
    # the optimizer's param_groups).
    new_param = model.layers[0].lobe_layer.lobes[0].fc1.weight
    in_optim = any(new_param is p for g in optim.param_groups for p in g["params"])
    assert in_optim, "new param must be in optimizer.param_groups after growth"
    assert new_param in optim.state, "new param must have Adam state (transferred from old)"

    x, y = make_synthetic_batch(tok, cfg.train.batch_size, cfg.data.seq_len, device)
    logits, diag = model(x)
    loss = lm_loss(logits, y)
    optim.zero_grad()
    loss.backward()
    optim.step()
    print(f"  post-growth step OK, loss={loss.item():.4f}")
    print("  PASS")


# =====================================================================
# Test 4: Checkpoint save/load round-trips (including post-growth)
# =====================================================================
def test_checkpoint_roundtrip(device):
    print("\n=== Test 4: checkpoint save/load (with post-growth shape) ===")
    cfg = Config.smoke()
    cfg.model_type = "novel"
    cfg.model.vocab_size = 80
    cfg.model.tie_embeddings = False
    cfg.train.use_amp = "fp32"
    cfg.hebbian.enabled = True
    cfg.ablation.use_growth = True
    set_seed(cfg.train.seed)

    tok = make_synthetic_tokenizer(cfg.model.vocab_size)
    model = build_novel_model(cfg).to(device)
    optim = build_optimizer(model, cfg)

    # Grow a lobe to make the architecture non-default.
    growth_monitor = model.attach_growth_monitor()
    # Need to do a forward first so growth monitor's windows warm up — but
    # we'll just call grow_lobe directly (bypassing saturation check).
    ev = growth_monitor.grow_lobe(0, 1, hebbian_tracker=model.hebbian_trackers[0],
                                   optimizer=optim)
    print(f"  grew lobe (0,1): {ev['old_ffn_dim']} -> {ev['new_ffn_dim']}")

    # Mutate Hebbian strengths to non-zero.
    with torch.no_grad():
        for tracker in model.hebbian_trackers:
            for lobe in tracker.lobes:
                lobe.strength.fill_(0.5)

    with tempfile.TemporaryDirectory() as td:
        ckpt_path = Path(td) / "ckpt.pt"
        save_checkpoint(ckpt_path, model, optim, tok, cfg, step=42, epoch=1)

        # Load into a fresh model (None) — must reconstruct architecture
        # at the saved shape (post-growth) and load weights + strengths.
        payload = load_checkpoint(ckpt_path, model=None, optimizer=None, device=device)
        loaded_model = payload["model"]
        loaded_tok = payload["tokenizer"]

        # Verify lobe shapes match.
        loaded_counts = loaded_model.get_lobe_neuron_counts()
        original_counts = model.get_lobe_neuron_counts()
        assert loaded_counts == original_counts, \
            f"lobe counts mismatch: {loaded_counts} != {original_counts}"

        # Verify Hebbian strengths were preserved.
        for li in range(len(model.layers)):
            for lj in range(len(model.layers[li].lobe_layer.lobes)):
                s_orig = model.layers[li].lobe_layer.lobes[lj].strength
                s_load = loaded_model.layers[li].lobe_layer.lobes[lj].strength
                assert torch.allclose(s_orig.cpu(), s_load.cpu()), \
                    f"strength mismatch at layer {li} lobe {lj}"

        # Verify tokenizer round-tripped.
        assert loaded_tok.vocab_size == tok.vocab_size
        sample = "hello world"
        assert loaded_tok.decode(loaded_tok.encode(sample)) == sample

        # Verify step/epoch were saved.
        assert payload["step"] == 42
        assert payload["epoch"] == 1

    print(f"  loaded lobe counts: {loaded_counts}")
    print("  PASS")


# =====================================================================
# Test 5: Ablation flags actually disable the right things
# =====================================================================
def test_ablation_flags(device):
    print("\n=== Test 5: ablation flags ===")
    tok = make_synthetic_tokenizer(80)
    x, y = make_synthetic_batch(tok, 4, 16, device)

    # No k-WTA: winning masks should be all-True.
    cfg = Config.smoke()
    cfg.model_type = "novel"
    cfg.model.vocab_size = 80
    cfg.model.tie_embeddings = False
    cfg.train.use_amp = "fp32"
    cfg.ablation.use_kwta = False
    set_seed(cfg.train.seed)
    m = build_novel_model(cfg).to(device)
    m.train()
    with torch.no_grad():
        _, diag = m(x)
    for ld in diag["per_layer"]:
        for mask in ld["per_lobe_winning_masks"]:
            if mask is not None:
                assert mask.all(), "use_kwta=False should keep all neurons"
    print("  use_kwta=False: all neurons survive (correct)")

    # No Hebbian: strengths should stay at 0.
    cfg = Config.smoke()
    cfg.model_type = "novel"
    cfg.model.vocab_size = 80
    cfg.model.tie_embeddings = False
    cfg.train.use_amp = "fp32"
    cfg.ablation.use_hebbian = False
    cfg.hebbian.enabled = False
    set_seed(cfg.train.seed)
    m = build_novel_model(cfg).to(device)
    m.train()
    with torch.no_grad():
        _, diag = m(x)
    s = m.hebbian_trackers[0].get_strength_stats()
    assert s["max"] == 0.0, "use_hebbian=False should leave strengths at 0"
    print("  use_hebbian=False: strengths stay at 0 (correct)")

    # Dense routing: all lobes should run.
    cfg = Config.smoke()
    cfg.model_type = "novel"
    cfg.model.vocab_size = 80
    cfg.model.tie_embeddings = False
    cfg.train.use_amp = "fp32"
    cfg.ablation.routing_mode = "dense"
    set_seed(cfg.train.seed)
    m = build_novel_model(cfg).to(device)
    m.train()
    with torch.no_grad():
        _, diag = m(x)
    eff_k = diag["per_layer"][0]["effective_top_k"]
    assert eff_k == cfg.model.lobes_per_layer, \
        f"dense routing should set effective_top_k = num_lobes, got {eff_k}"
    print(f"  routing_mode='dense': effective_top_k={eff_k} (correct)")

    print("  PASS")


# =====================================================================
# Main
# =====================================================================
def main():
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"Device: {device}")
    print(f"PyTorch: {torch.__version__}")

    test_baseline_fwd_bwd(device)
    test_novel_fwd_bwd_hebbian(device)
    test_growth_fires_and_optim_survives(device)
    test_checkpoint_roundtrip(device)
    test_ablation_flags(device)

    print("\n" + "=" * 60)
    print("ALL SMOKE TESTS PASSED")
    print("=" * 60)


if __name__ == "__main__":
    main()
