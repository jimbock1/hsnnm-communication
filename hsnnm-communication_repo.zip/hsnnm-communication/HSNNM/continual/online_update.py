"""
continual/online_update.py — Phase 2: surprise-triggered post-training updates.

After a trained model is deployed, conversation text is fed in and the model's
own prediction loss is computed. If average surprise (loss) exceeds a
threshold, a *small, low-learning-rate* gradient update is performed using
that conversation as training data. If surprise is below threshold, the
update is skipped entirely.

The model decides for itself whether to learn from a given conversation.

Safety:
  - ALWAYS saves a pre-update checkpoint before any update (rollback safety).
  - Logs before/after validation loss on a fixed held-out set.
  - If the update degraded held-out loss beyond a tolerance, automatically
    rolls back.

Phase 2 only — not wired into the Phase 1 training loop. Activate manually
after Phase 1 validation passes.

Usage:
    python -m continual.online_update \\
        --ckpt runs/phase1_novel/final.pt \\
        --conversation conversations/batch_42.txt \\
        --surprise-threshold 2.5 \\
        --update-lr 1e-5 \\
        --out runs/phase2_online
"""
from __future__ import annotations

from pathlib import Path
import argparse
import json
import logging
import sys
import time

import torch
import torch.nn as nn

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from config import Config, count_parameters
from model.tokenizer import CharTokenizer
from training.losses import lm_loss
from training.train import build_optimizer, AMPContext, device_type_str
from training.checkpoint import (save_checkpoint, load_checkpoint,
                                  save_pre_update_checkpoint)

log = logging.getLogger("online_update")


# =====================================================================
# Online updater
# =====================================================================

class OnlineUpdater:
    """Surprise-triggered post-training gradient updates.

    Lifecycle per conversation batch:
      1. Compute mean prediction loss on the conversation text (surprise).
      2. If surprise < threshold: log "skip" and return.
      3. If surprise >= threshold:
         a. Save pre-update checkpoint.
         b. Eval on held-out set -> val_loss_pre.
         c. Run a few low-LR gradient steps on the conversation.
         d. Eval on held-out set -> val_loss_post.
         e. If val_loss_post - val_loss_pre > tolerance: roll back.
         f. Otherwise: keep the update, log everything.
    """

    def __init__(
        self,
        model,
        tokenizer: CharTokenizer,
        config: Config,
        run_dir: Path,
        device: str,
        surprise_threshold: float = 2.5,
        update_lr: float = 1e-5,
        update_steps: int = 5,
        rollback_tolerance: float = 0.1,
        held_out_texts: list = None,
    ):
        self.model = model
        self.tokenizer = tokenizer
        self.config = config
        self.run_dir = Path(run_dir)
        self.run_dir.mkdir(parents=True, exist_ok=True)
        self.device = device
        self.amp = AMPContext(config.train.use_amp, device_type_str(device))

        self.surprise_threshold = surprise_threshold
        self.update_lr = update_lr
        self.update_steps = update_steps
        self.rollback_tolerance = rollback_tolerance
        self.held_out_texts = held_out_texts or []

        # Separate optimizer for online updates — low LR, fresh state.
        # We do NOT reuse the training optimizer (its momentum / lr are wrong
        # for the low-rate online regime).
        self.optimizer = torch.optim.AdamW(
            model.parameters(), lr=update_lr, weight_decay=0.0
        )

        self.history = []

    # ------------------------------------------------------------------
    # Surprisal computation
    # ------------------------------------------------------------------
    def compute_surprise(self, text: str) -> float:
        """Mean per-token loss on the conversation text. This is the model's
        own 'surprise' at what was actually said."""
        ids = self.tokenizer.encode(text)
        if len(ids) < 2:
            return 0.0
        seq_len = self.config.data.seq_len
        total_loss, n_tokens = 0.0, 0
        self.model.eval()
        with torch.no_grad():
            for i in range(0, len(ids) - seq_len - 1, seq_len):
                chunk = ids[i:i + seq_len + 1]
                x = torch.tensor(chunk[:-1], dtype=torch.long,
                                 device=self.device).unsqueeze(0)
                y = torch.tensor(chunk[1:], dtype=torch.long,
                                 device=self.device).unsqueeze(0)
                with self.amp.autocast():
                    if self.config.model_type == "novel":
                        logits, _ = self.model(x, update_hebbian=False)
                    else:
                        logits = self.model(x)
                    loss = lm_loss(logits, y)
                total_loss += loss.item() * x.size(1)
                n_tokens += x.size(1)
        return total_loss / max(1, n_tokens)

    # ------------------------------------------------------------------
    # Held-out eval
    # ------------------------------------------------------------------
    def eval_held_out(self) -> float:
        if not self.held_out_texts:
            return float("nan")
        from evaluation.forgetting_test import eval_on_texts
        return eval_on_texts(self.model, self.tokenizer, self.held_out_texts,
                             self.config, self.device, self.amp)

    # ------------------------------------------------------------------
    # Gradient update on conversation
    # ------------------------------------------------------------------
    def update_on_text(self, text: str) -> dict:
        """Run `update_steps` low-LR gradient steps on the conversation."""
        ids = self.tokenizer.encode(text)
        seq_len = self.config.data.seq_len
        if len(ids) < seq_len + 1:
            return {"updated": False, "reason": "conversation too short"}

        # Build a small dataset of non-overlapping chunks.
        chunks = []
        for i in range(0, len(ids) - seq_len - 1, seq_len):
            chunk = ids[i:i + seq_len + 1]
            chunks.append((chunk[:-1], chunk[1:]))
        if not chunks:
            return {"updated": False, "reason": "no chunks"}

        self.model.train()
        losses = []
        step = 0
        while step < self.update_steps:
            for x_ids, y_ids in chunks:
                if step >= self.update_steps:
                    break
                x = torch.tensor(x_ids, dtype=torch.long,
                                 device=self.device).unsqueeze(0)
                y = torch.tensor(y_ids, dtype=torch.long,
                                 device=self.device).unsqueeze(0)
                with self.amp.autocast():
                    if self.config.model_type == "novel":
                        logits, _ = self.model(x)  # Hebbian updates active
                    else:
                        logits = self.model(x)
                    loss = lm_loss(logits, y)
                self.optimizer.zero_grad()
                scaled = self.amp.scale_loss(loss)
                scaled.backward()
                self.amp.unscale_and_step(self.optimizer, self.config.train.grad_clip)
                losses.append(loss.item())
                step += 1
        return {"updated": True, "mean_update_loss": sum(losses) / max(1, len(losses))}

    # ------------------------------------------------------------------
    # Top-level: process one conversation
    # ------------------------------------------------------------------
    def process_conversation(self, text: str, tag: str) -> dict:
        log.info("=== Online update: %s ===", tag)
        surprise = self.compute_surprise(text)
        log.info("  Surprise (mean token loss): %.4f  (threshold: %.4f)",
                 surprise, self.surprise_threshold)

        if surprise < self.surprise_threshold:
            log.info("  Below threshold — skipping update.")
            record = {"tag": tag, "surprise": surprise, "action": "skip",
                      "threshold": self.surprise_threshold}
            self.history.append(record)
            return record

        # Pre-update checkpoint.
        pre_path = save_pre_update_checkpoint(
            self.run_dir, self.model, self.optimizer, self.tokenizer,
            self.config, step=0, epoch=0, tag=f"online_{tag}",
        )
        log.info("  Pre-update checkpoint: %s", pre_path)

        val_pre = self.eval_held_out()
        log.info("  Val loss pre-update: %.4f", val_pre)

        upd = self.update_on_text(text)
        if not upd.get("updated"):
            log.info("  Update skipped: %s", upd.get("reason"))
            record = {"tag": tag, "surprise": surprise, "action": "skip_no_data",
                      "reason": upd.get("reason"), "pre_checkpoint": str(pre_path)}
            self.history.append(record)
            return record

        val_post = self.eval_held_out()
        log.info("  Val loss post-update: %.4f", val_post)

        degradation = (val_post - val_pre) if not (val_pre != val_pre) else 0.0  # NaN-safe
        record = {
            "tag": tag,
            "surprise": surprise,
            "action": "update",
            "val_pre": val_pre,
            "val_post": val_post,
            "degradation": degradation,
            "pre_checkpoint": str(pre_path),
            "update_result": upd,
        }

        # Auto-rollback if degradation exceeds tolerance.
        if degradation > self.rollback_tolerance:
            log.warning("  Degradation %.4f > tolerance %.4f — ROLLING BACK.",
                        degradation, self.rollback_tolerance)
            payload = load_checkpoint(pre_path, model=self.model,
                                      optimizer=self.optimizer, device=self.device)
            self.model = payload["model"]
            record["rolled_back"] = True
        else:
            record["rolled_back"] = False
            log.info("  Update accepted (degradation within tolerance).")

        self.history.append(record)
        return record

    # ------------------------------------------------------------------
    # Save final state
    # ------------------------------------------------------------------
    def save_final(self, path: Path) -> None:
        save_checkpoint(path, self.model, self.optimizer, self.tokenizer,
                        self.config, step=0, epoch=0,
                        extra={"online_update_history": self.history})
        (self.run_dir / "online_history.json").write_text(json.dumps(self.history, indent=2))


# =====================================================================
# CLI
# =====================================================================

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--ckpt", required=True, help="Path to trained model checkpoint")
    parser.add_argument("--conversation", required=True,
                        help="Path to a text file with the conversation to learn from")
    parser.add_argument("--surprise-threshold", type=float, default=2.5,
                        help="If surprise > this, update is triggered")
    parser.add_argument("--update-lr", type=float, default=1e-5)
    parser.add_argument("--update-steps", type=int, default=5)
    parser.add_argument("--rollback-tolerance", type=float, default=0.1,
                        help="If held-out loss degrades by more than this, roll back")
    parser.add_argument("--out", default="runs/phase2_online")
    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
    device = "cuda" if torch.cuda.is_available() else "cpu"

    payload = load_checkpoint(args.ckpt, model=None, optimizer=None, device=device)
    model = payload["model"]
    config = payload["config"]
    tokenizer = payload["tokenizer"]

    text = Path(args.conversation).read_text(encoding="utf-8")
    updater = OnlineUpdater(
        model, tokenizer, config, Path(args.out), device,
        surprise_threshold=args.surprise_threshold,
        update_lr=args.update_lr,
        update_steps=args.update_steps,
        rollback_tolerance=args.rollback_tolerance,
    )
    record = updater.process_conversation(text, tag=Path(args.conversation).stem)
    updater.save_final(Path(args.out) / "final.pt")
    print(json.dumps(record, indent=2))


if __name__ == "__main__":
    main()
