"""
data/dataset_loader.py — TinyStories loading + batching.

Builds a char-level corpus from the TinyStories HF dataset, packs it into
fixed-length training sequences (sliding window), and exposes PyTorch
`Dataset`/`DataLoader` interfaces producing `(input_ids, target_ids)` pairs.

For the next-token prediction LM task, `target_ids[i]` is `input_ids[i+1]`.
The model is fed `input_ids[:-1]` and predicts `target_ids[1:]` — i.e. the
standard shifted-1 LM formulation. We pre-shift here so the training loop
stays simple.

Phase 1 uses a small slice (default 5% of the dataset). Phase 2 uses the full
~500M-token corpus — `data_fraction=1.0`.
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional, Tuple, List
import logging

import torch
from torch.utils.data import Dataset, DataLoader

from model.tokenizer import CharTokenizer

log = logging.getLogger(__name__)


# =====================================================================
# Corpus loading + tokenization
# =====================================================================

def _load_tinystories_texts(fraction: float, cache_dir: Optional[str] = None) -> List[str]:
    """Load TinyStories `train` split, returning a list of story strings.

    `fraction` in (0, 1] controls how much of the dataset is loaded.
    Phase 1 default is 5%; Phase 2 is 100%.
    """
    from datasets import load_dataset

    log.info("Loading TinyStories (fraction=%.3f, cache_dir=%s)...", fraction, cache_dir)
    # TinyStories is a standard parquet dataset — no custom code needed.
    # `trust_remote_code` was removed in datasets >= 3.0, so we try without
    # it first (works on all versions) and fall back to passing it explicitly
    # for older versions that emit a warning otherwise.
    try:
        ds = load_dataset(
            "roneneldan/TinyStories",
            split="train",
            cache_dir=cache_dir,
        )
    except TypeError:
        # Older datasets versions accept trust_remote_code; pass it.
        ds = load_dataset(
            "roneneldan/TinyStories",
            split="train",
            cache_dir=cache_dir,
            trust_remote_code=True,
        )
    if fraction < 1.0:
        n = max(1, int(len(ds) * fraction))
        ds = ds.select(range(n))
    texts = [row["text"] for row in ds]
    log.info("Loaded %d stories (total chars: %d).", len(texts), sum(len(t) for t in texts))
    return texts


def build_corpus(
    fraction: float = 0.05,
    cache_dir: Optional[str] = None,
) -> Tuple[List[str], CharTokenizer]:
    """Load texts and build a char-level tokenizer from them.

    Returns (texts, tokenizer).
    """
    texts = _load_tinystories_texts(fraction, cache_dir)
    tok = CharTokenizer.from_texts(texts)
    log.info("Built char vocab: size=%d (sample: %s)",
             tok.vocab_size, tok._vocab[:20])
    return texts, tok


# =====================================================================
# Packing into fixed-length sequences
# =====================================================================

class CharLMDataset(Dataset):
    """Packs a list of texts into fixed-length (input_ids, target_ids) pairs.

    Implementation: concatenate all texts with a single <pad>-equivalent
    separator (we use a newline), then slide a window of `seq_len + 1` chars
    across the packed stream with stride `seq_len` (non-overlapping chunks).
    Each chunk yields one sample of shape (seq_len,) for input and (seq_len,)
    for target (target = input shifted left by 1 within the chunk).

    For Phase 1 fast iteration this is sufficient. Phase 2 may switch to a
    streaming / mmap-backed implementation to avoid materializing the whole
    packed tensor in memory.
    """

    def __init__(
        self,
        texts: List[str],
        tokenizer: CharTokenizer,
        seq_len: int = 256,
        is_validation: bool = False,
        val_fraction: float = 0.05,
        seed: int = 42,
    ):
        self.seq_len = seq_len
        self.tokenizer = tokenizer

        # Hold out a fraction of *stories* for validation (not a slice of
        # the packed stream — that would leak across story boundaries).
        rng = torch.Generator().manual_seed(seed)
        perm = torch.randperm(len(texts), generator=rng).tolist()
        n_val = max(1, int(len(texts) * val_fraction))
        if is_validation:
            idxs = perm[:n_val]
        else:
            idxs = perm[n_val:]

        # Concatenate selected stories with a newline separator. The newline
        # is in the vocab (we built the vocab from the same texts), so this
        # won't produce <unk>.
        sep = "\n"
        joined = sep.join(texts[i] for i in idxs)
        ids = tokenizer.encode(joined)

        # Trim to a multiple of (seq_len + 1) so every sample is full-length.
        chunk_len = seq_len + 1
        n_chunks = len(ids) // chunk_len
        ids = ids[: n_chunks * chunk_len]
        data = torch.tensor(ids, dtype=torch.long)
        self._data = data.view(n_chunks, chunk_len)
        log.info("%s set: %d chunks of length %d (%.2fM tokens).",
                 "val" if is_validation else "train",
                 n_chunks, chunk_len, n_chunks * chunk_len / 1e6)

    def __len__(self) -> int:
        return self._data.size(0)

    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, torch.Tensor]:
        """Returns (input_ids, target_ids), each shape (seq_len,).

        target_ids[i] is the next-token target for input_ids[i].
        """
        chunk = self._data[idx]               # shape (seq_len + 1,)
        return chunk[:-1].clone(), chunk[1:].clone()


# =====================================================================
# Public entry point
# =====================================================================

def make_dataloaders(
    fraction: float,
    seq_len: int,
    batch_size: int,
    val_fraction: float,
    num_workers: int,
    cache_dir: Optional[str] = None,
    seed: int = 42,
    tokenizer: Optional[CharTokenizer] = None,
) -> Tuple[CharTokenizer, DataLoader, DataLoader]:
    """Build (tokenizer, train_loader, val_loader).

    If `tokenizer` is None, a fresh one is built from the loaded texts.
    Otherwise the provided tokenizer is used (useful for continuing a run
    with a previously-saved vocab).
    """
    texts = _load_tinystories_texts(fraction, cache_dir)
    if tokenizer is None:
        tokenizer = CharTokenizer.from_texts(texts)

    train_ds = CharLMDataset(texts, tokenizer, seq_len,
                             is_validation=False, val_fraction=val_fraction, seed=seed)
    val_ds = CharLMDataset(texts, tokenizer, seq_len,
                           is_validation=True, val_fraction=val_fraction, seed=seed)

    train_loader = DataLoader(
        train_ds, batch_size=batch_size, shuffle=True,
        num_workers=num_workers, drop_last=True, pin_memory=True,
    )
    val_loader = DataLoader(
        val_ds, batch_size=batch_size, shuffle=False,
        num_workers=num_workers, drop_last=False, pin_memory=True,
    )
    return tokenizer, train_loader, val_loader
