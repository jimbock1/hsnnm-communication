"""tests/test_growth.py — growth resize, ceiling, cooldown, opt-state preservation."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import torch
import torch.nn as nn

from config import Config, GrowthConfig, AblationConfig, ModelConfig, HebbianConfig
from model.lobe import Lobe, LobeLayer
from model.novel_model import NovelModel
from model.growth import GrowthMonitor, LobeSignalWindow


def _build_tiny_novel_model() -> NovelModel:
    cfg = Config()
    cfg.model = ModelConfig(
        vocab_size=64, hidden_dim=32, max_seq_len=64,
        num_layers=2, num_heads=4, ffn_dim=32,
        lobes_per_layer=3, top_k_lobes=1, kwta_ratio=0.25,
        dropout=0.0, tie_embeddings=False,
    )
    cfg.hebbian = HebbianConfig(enabled=True)
    cfg.ablation = AblationConfig(use_kwta=True, use_hebbian=True, use_growth=True)
    return NovelModel(cfg)


# =====================================================================
# Lobe.grow_neurons
# =====================================================================

def test_lobe_grow_resizes_weights():
    lobe = Lobe(hidden_dim=16, ffn_dim=32, kwta_ratio=0.25)
    old_ffn = lobe.ffn_dim
    old_fc1_shape = lobe.fc1.weight.shape
    old_fc2_shape = lobe.fc2.weight.shape

    lobe.grow_neurons(n_new=8, donor_strength_idx=0, noise_scale=0.01)

    assert lobe.ffn_dim == old_ffn + 8
    assert lobe.fc1.weight.shape == (old_ffn + 8, 16)
    assert lobe.fc2.weight.shape == (16, old_ffn + 8)
    assert lobe.strength.shape == (old_ffn + 8,)


def test_lobe_grow_donates_weights():
    """New neurons should have weights ≈ donor's weights (plus small noise)."""
    lobe = Lobe(hidden_dim=16, ffn_dim=32, kwta_ratio=0.25)
    donor_w1 = lobe.fc1.weight[0].clone()
    donor_w2 = lobe.fc2.weight[:, 0].clone()

    lobe.grow_neurons(n_new=1, donor_strength_idx=0, noise_scale=0.0)  # zero noise for exact check

    new_w1 = lobe.fc1.weight[-1]
    new_w2 = lobe.fc2.weight[:, -1]
    assert torch.allclose(new_w1, donor_w1)
    assert torch.allclose(new_w2, donor_w2)


def test_lobe_grow_preserves_existing_weights():
    """Existing neurons' weights must be unchanged by growth."""
    lobe = Lobe(hidden_dim=16, ffn_dim=32, kwta_ratio=0.25)
    before_fc1 = lobe.fc1.weight[:10].clone()
    before_fc2 = lobe.fc2.weight[:, :10].clone()
    before_strength = lobe.strength[:10].clone()

    lobe.grow_neurons(n_new=5, donor_strength_idx=0, noise_scale=0.01)

    assert torch.allclose(lobe.fc1.weight[:10], before_fc1)
    assert torch.allclose(lobe.fc2.weight[:, :10], before_fc2)
    assert torch.allclose(lobe.strength[:10], before_strength)


# =====================================================================
# GrowthMonitor — saturation signals
# =====================================================================

def test_signal_window_warming_up():
    w = LobeSignalWindow(window=10, persistence_ratio=0.9)
    for i in range(5):
        w.push(0.9, 0.9, 0.9)
    score, detail = w.combined_score(GrowthConfig(rolling_window=10, persistence_ratio=0.9,
                                                    confidence_threshold=0.5,
                                                    utilization_threshold=0.5,
                                                    entropy_threshold=0.5))
    assert detail["status"] == "warming_up"
    assert score == 0.0


def test_signal_window_saturated_when_all_signals_persistent():
    cfg = GrowthConfig(rolling_window=10, persistence_ratio=0.9,
                        confidence_threshold=0.5, utilization_threshold=0.5,
                        entropy_threshold=0.5)
    w = LobeSignalWindow(window=10, persistence_ratio=0.9)
    for _ in range(10):
        w.push(0.9, 0.9, 0.9)  # all above thresholds
    score, detail = w.combined_score(cfg)
    assert score >= 0.9
    assert detail["status"] == "ready"


def test_signal_window_not_saturated_when_one_signal_low():
    cfg = GrowthConfig(rolling_window=10, persistence_ratio=0.9,
                        confidence_threshold=0.5, utilization_threshold=0.5,
                        entropy_threshold=0.5)
    w = LobeSignalWindow(window=10, persistence_ratio=0.9)
    # Confidence high, utilization low.
    for _ in range(10):
        w.push(0.9, 0.1, 0.9)
    score, detail = w.combined_score(cfg)
    # min(p_conf=1.0, p_util=0.0, p_entr=1.0) = 0.0
    assert score == 0.0


# =====================================================================
# GrowthMonitor — cooldown + ceiling
# =====================================================================

def test_cooldown_blocks_rapid_growth():
    model = _build_tiny_novel_model()
    cfg = GrowthConfig(enabled=True, rolling_window=5, persistence_ratio=0.5,
                        confidence_threshold=0.5, utilization_threshold=0.5,
                        entropy_threshold=0.5,
                        minimum_growth_interval=100, neurons_per_growth=4,
                        param_ceiling=10**9, check_interval_steps=1)
    monitor = GrowthMonitor(model, cfg)

    # Fill the windows with high signals.
    for li in range(monitor.num_layers):
        for lj in range(monitor.num_lobes_per_layer):
            for _ in range(5):
                monitor.step(li, lj, 0.9, 0.9, 0.9)

    # First growth should succeed.
    should, _ = monitor.check_saturation(0, 0)
    assert should, "first growth should fire"
    monitor.grow_lobe(0, 0, hebbian_tracker=None, optimizer=None)
    monitor.last_growth_step[0][0] = monitor.current_step

    # Advance a tiny bit — still within cooldown.
    for _ in range(50):
        monitor.advance_step()
        for li in range(monitor.num_layers):
            for lj in range(monitor.num_lobes_per_layer):
                monitor.step(li, lj, 0.9, 0.9, 0.9)

    should, detail = monitor.check_saturation(0, 0)
    assert not should
    assert detail["status"] == "cooldown"


def test_param_ceiling_blocks_growth():
    model = _build_tiny_novel_model()
    # Set a ceiling that's just above current params but below what growth would add.
    current = sum(p.numel() for p in model.parameters() if p.requires_grad)
    cfg = GrowthConfig(enabled=True, rolling_window=5, persistence_ratio=0.5,
                        confidence_threshold=0.5, utilization_threshold=0.5,
                        entropy_threshold=0.5,
                        minimum_growth_interval=0, neurons_per_growth=32,
                        param_ceiling=current + 10,  # only 10 params of headroom
                        check_interval_steps=1)
    monitor = GrowthMonitor(model, cfg)
    for li in range(monitor.num_layers):
        for lj in range(monitor.num_lobes_per_layer):
            for _ in range(5):
                monitor.step(li, lj, 0.9, 0.9, 0.9)
    should, detail = monitor.check_saturation(0, 0)
    assert not should
    assert detail["status"] == "capped_at_ceiling"


# =====================================================================
# Optimizer state preservation on growth — addendum #9
# =====================================================================

def test_optimizer_state_preserved_on_growth():
    """After growth, Adam's exp_avg / exp_avg_sq for EXISTING neurons must
    be unchanged; new neurons get zero moments."""
    model = _build_tiny_novel_model()
    optim = torch.optim.AdamW(model.parameters(), lr=1e-3)

    # Run a few steps to populate optimizer state.
    for _ in range(3):
        x = torch.randint(0, 64, (2, 16))
        if hasattr(model, "hebbian_trackers"):
            logits, _ = model(x)
        else:
            logits = model(x)
        loss = logits.sum()
        optim.zero_grad()
        loss.backward()
        optim.step()

    # Pick a lobe, capture its optimizer state for fc1.weight BEFORE growth.
    lobe = model.layers[0].lobe_layer.lobes[0]
    param = lobe.fc1.weight
    assert param in optim.state, "Adam state should exist after step"
    exp_avg_before = optim.state[param]["exp_avg"][:10].clone()
    exp_avg_sq_before = optim.state[param]["exp_avg_sq"][:10].clone()
    old_ffn = lobe.ffn_dim

    # Grow.
    cfg = GrowthConfig(enabled=True, neurons_per_growth=8,
                        minimum_growth_interval=0, param_ceiling=10**9,
                        rolling_window=2, persistence_ratio=0.0,
                        confidence_threshold=0.0, utilization_threshold=0.0,
                        entropy_threshold=0.0, check_interval_steps=1)
    monitor = GrowthMonitor(model, cfg)
    monitor.grow_lobe(0, 0, hebbian_tracker=None, optimizer=optim)

    # After growth:
    #  - param shape changed (it's a new tensor since we rebuilt nn.Linear)
    #  - but optim.state for the new param should have correctly-sized buffers
    #  - existing entries preserved (we can't directly compare since the param
    #    pointer changed; but we can check the new buffers have the right shape
    #    and that the first 10 rows match the saved values)
    new_param = model.layers[0].lobe_layer.lobes[0].fc1.weight
    assert new_param.shape[0] == old_ffn + 8
    assert new_param in optim.state, "optimizer state must exist for new (resized) param"
    new_exp_avg = optim.state[new_param]["exp_avg"]
    new_exp_avg_sq = optim.state[new_param]["exp_avg_sq"]
    assert new_exp_avg.shape[0] == old_ffn + 8
    # Existing neurons' moments preserved.
    assert torch.allclose(new_exp_avg[:10], exp_avg_before)
    assert torch.allclose(new_exp_avg_sq[:10], exp_avg_sq_before)
    # New neurons have zero moments.
    assert (new_exp_avg[old_ffn:] == 0).all()
    assert (new_exp_avg_sq[old_ffn:] == 0).all()


if __name__ == "__main__":
    import pytest
    pytest.main([__file__, "-v"])
