"""tests/test_tokenizer.py — encode/decode round-trip."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from model.tokenizer import CharTokenizer, PAD_ID, UNK_ID


def test_encode_decode_roundtrip():
    text = "Hello, world! 123\n\tTabbed line."
    tok = CharTokenizer.from_texts([text])
    ids = tok.encode(text)
    decoded = tok.decode(ids)
    assert decoded == text, f"round-trip failed: {decoded!r} != {text!r}"


def test_unknown_char_maps_to_unk():
    tok = CharTokenizer.from_texts(["abc"])
    ids = tok.encode("abz")  # 'z' not in vocab
    assert ids == [tok._stoi["a"], tok._stoi["b"], UNK_ID]


def test_pad_id_skipped_on_decode():
    tok = CharTokenizer.from_texts(["abc"])
    encoded = tok.encode("abc")
    padded = [PAD_ID, PAD_ID] + encoded + [PAD_ID]
    decoded = tok.decode(padded)
    assert decoded == "abc"


def test_vocab_size():
    text = "abcdef"
    tok = CharTokenizer.from_texts([text])
    # 6 chars + 2 specials (<pad>, <unk>)
    assert tok.vocab_size == 8


def test_save_load_roundtrip(tmp_path):
    text = "Hello world!"
    tok = CharTokenizer.from_texts([text])
    p = tmp_path / "vocab.json"
    tok.save(p)
    tok2 = CharTokenizer.load(p)
    assert tok2.vocab_size == tok.vocab_size
    assert tok2.encode(text) == tok.encode(text)
    assert tok2.decode(tok.encode(text)) == text


def test_deterministic_vocab_ordering():
    """Two tokenizers built from the same texts must have identical vocabs."""
    texts = ["banana", "apple", "cherry"]
    t1 = CharTokenizer.from_texts(texts)
    t2 = CharTokenizer.from_texts(texts)
    assert t1._vocab == t2._vocab


if __name__ == "__main__":
    import pytest
    pytest.main([__file__, "-v"])
