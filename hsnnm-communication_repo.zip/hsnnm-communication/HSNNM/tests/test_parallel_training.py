"""
tests/test_parallel_training.py — Verify the parallel training orchestration
works correctly by simulating two training processes.

This test does NOT actually train models (too slow). Instead it verifies:
1. Two subprocesses can be launched with different CUDA_VISIBLE_DEVICES
2. The parent correctly waits for both
3. Output goes to separate log files
4. Return codes are checked correctly
"""
import sys
import os
import subprocess
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


def test_parallel_subprocess_launch():
    """Verify two subprocesses can run in parallel with different env vars."""
    print("Test: parallel subprocess launch with different CUDA_VISIBLE_DEVICES")
    
    # Use a simple Python one-liner that prints its CUDA_VISIBLE_DEVICES
    # and sleeps briefly to simulate work
    code = '''
import os, time, sys
sys.stdout.write(f"PID={os.getpid()} CUDA_VISIBLE_DEVICES={os.environ.get('CUDA_VISIBLE_DEVICES', 'NOT SET')}\\n")
sys.stdout.flush()
time.sleep(1)
sys.stdout.write(f"PID={os.getpid()} DONE\\n")
sys.stdout.flush()
'''
    
    env0 = os.environ.copy()
    env0["CUDA_VISIBLE_DEVICES"] = "0"
    env1 = os.environ.copy()
    env1["CUDA_VISIBLE_DEVICES"] = "1"
    
    t0 = time.time()
    p0 = subprocess.Popen([sys.executable, "-c", code], env=env0,
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    p1 = subprocess.Popen([sys.executable, "-c", code], env=env1,
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    
    out0, _ = p0.communicate()
    out1, _ = p1.communicate()
    elapsed = time.time() - t0
    
    # Verify both ran in parallel (total time should be ~1s, not ~2s)
    assert elapsed < 1.5, f"Processes did not run in parallel (took {elapsed:.2f}s)"
    
    # Verify each got its own CUDA_VISIBLE_DEVICES
    assert "CUDA_VISIBLE_DEVICES=0" in out0, f"Process 0 didn't get GPU 0: {out0}"
    assert "CUDA_VISIBLE_DEVICES=1" in out1, f"Process 1 didn't get GPU 1: {out1}"
    
    print(f"  Process 0: {out0.strip()}")
    print(f"  Process 1: {out1.strip()}")
    print(f"  Elapsed: {elapsed:.2f}s (parallel if < 1.5s)")
    print("  PASS")


def test_parallel_log_separation():
    """Verify two processes write to separate log files without interleaving."""
    print("\nTest: parallel log separation")
    
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        log0 = Path(td) / "proc0.log"
        log1 = Path(td) / "proc1.log"
        
        code = '''
import os, time, sys
for i in range(5):
    sys.stdout.write(f"line {i} from proc {os.environ.get('PROC_ID')}\\n")
    sys.stdout.flush()
    time.sleep(0.1)
'''
        
        env0 = os.environ.copy()
        env0["PROC_ID"] = "0"
        env1 = os.environ.copy()
        env1["PROC_ID"] = "1"
        
        with open(log0, "w") as f0, open(log1, "w") as f1:
            p0 = subprocess.Popen([sys.executable, "-c", code], env=env0,
                                  stdout=f0, stderr=subprocess.STDOUT, text=True)
            p1 = subprocess.Popen([sys.executable, "-c", code], env=env1,
                                  stdout=f1, stderr=subprocess.STDOUT, text=True)
            p0.wait()
            p1.wait()
        
        # Verify logs are separate and correct
        out0 = log0.read_text()
        out1 = log1.read_text()
        
        assert "proc 0" in out0 and "proc 0" not in out1, "Log 0 contaminated"
        assert "proc 1" in out1 and "proc 1" not in out0, "Log 1 contaminated"
        assert len(out0.strip().split("\n")) == 5, f"Log 0 has wrong line count: {out0}"
        assert len(out1.strip().split("\n")) == 5, f"Log 1 has wrong line count: {out1}"
        
        print(f"  Log 0: 5 lines, all 'proc 0' ✓")
        print(f"  Log 1: 5 lines, all 'proc 1' ✓")
        print("  PASS")


def test_kaggle_run_imports():
    """Verify kaggle_run.py imports cleanly and exposes the parallel functions."""
    print("\nTest: kaggle_run.py imports and function signatures")
    
    # Import without running main
    import importlib.util
    spec = importlib.util.spec_from_file_location("kaggle_run", "/home/z/my-project/kaggle_run.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    
    # Check key functions exist
    assert hasattr(mod, 'train_both_parallel'), "Missing train_both_parallel"
    assert hasattr(mod, '_train_parallel_two_gpus'), "Missing _train_parallel_two_gpus"
    assert hasattr(mod, 'forgetting_tests_parallel'), "Missing forgetting_tests_parallel"
    assert hasattr(mod, '_forget_parallel_two_gpus'), "Missing _forget_parallel_two_gpus"
    assert hasattr(mod, '_build_train_cmd'), "Missing _build_train_cmd"
    assert hasattr(mod, '_peek_log_status'), "Missing _peek_log_status"
    
    print(f"  train_both_parallel: ✓")
    print(f"  _train_parallel_two_gpus: ✓")
    print(f"  forgetting_tests_parallel: ✓")
    print(f"  _forget_parallel_two_gpus: ✓")
    print(f"  _build_train_cmd: ✓")
    print(f"  _peek_log_status: ✓")
    print("  PASS")


def test_build_train_cmd_resume_logic():
    """Verify _build_train_cmd correctly adds --resume when checkpoint exists."""
    print("\nTest: _build_train_cmd resume logic")
    
    import importlib.util
    spec = importlib.util.spec_from_file_location("kaggle_run", "/home/z/my-project/kaggle_run.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    
    from pathlib import Path
    import tempfile
    
    # Test 1: No checkpoint — no --resume flag
    with tempfile.TemporaryDirectory() as td:
        mod.PROJECT_DIR = Path(td)
        cmd = mod._build_train_cmd("configs/phase1_baseline.yaml",
                                    "runs/phase1_baseline/latest.pt")
        assert "--resume" not in cmd, f"Should not have --resume without checkpoint: {cmd}"
        print(f"  No checkpoint: --resume not added ✓")
        
        # Test 2: Create checkpoint — --resume should be added
        ckpt_dir = Path(td) / "runs" / "phase1_baseline"
        ckpt_dir.mkdir(parents=True)
        (ckpt_dir / "latest.pt").touch()
        
        cmd = mod._build_train_cmd("configs/phase1_baseline.yaml",
                                    "runs/phase1_baseline/latest.pt")
        assert "--resume" in cmd, f"Should have --resume with checkpoint: {cmd}"
        assert str(ckpt_dir / "latest.pt") in " ".join(cmd), "Resume path wrong"
        print(f"  With checkpoint: --resume added correctly ✓")
    
    print("  PASS")


def test_peek_log_status():
    """Verify _peek_log_status extracts the last meaningful line from a log."""
    print("\nTest: _peek_log_status log parsing")
    
    import importlib.util
    spec = importlib.util.spec_from_file_location("kaggle_run", "/home/z/my-project/kaggle_run.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        log = Path(td) / "train.log"
        log.write_text("""2026-01-01 INFO: starting training
2026-01-01 INFO: step=0 loss=4.5
2026-01-01 INFO: step=25 loss=4.2
2026-01-01 INFO: step=50 loss=3.9
""")
        
        status = mod._peek_log_status(log)
        assert "step=50" in status or "loss=3.9" in status, f"Should find last training line: {status}"
        print(f"  Status: {status!r}")
        print("  PASS")
    
    # Test with empty log
    with tempfile.TemporaryDirectory() as td:
        log = Path(td) / "empty.log"
        log.write_text("")
        status = mod._peek_log_status(log)
        assert "no output" in status or status == "(reading log...)", f"Should handle empty log: {status}"
        print(f"  Empty log status: {status!r}")
        print("  PASS")


if __name__ == "__main__":
    import pytest
    pytest.main([__file__, "-v"])
