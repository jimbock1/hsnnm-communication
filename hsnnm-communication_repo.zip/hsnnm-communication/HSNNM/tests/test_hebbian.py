"""tests/test_hebbian.py — verify the clamped Hebbian update rule."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import torch

from config import HebbianConfig
from model.lobe import Lobe
from model.hebbian import HebbianTracker


def _build_tracker(ffn_dim=64, **cfg_overrides):
    cfg = HebbianConfig(enabled=True, **cfg_overrides)
    lobes = [Lobe(hidden_dim=16, ffn_dim=ffn_dim, kwta_ratio=0.25)]
    return HebbianTracker(lobes, cfg), lobes[0]


def test_initial_strength_is_zero():
    tracker, lobe = _build_tracker()
    assert (lobe.strength == 0).all()


def test_winner_increment_increases_strength():
    tracker, lobe = _build_tracker(increment=0.01, decay_rate=0.0,
                                    clamp_min=0.0, clamp_max=2.0)
    # All neurons win for all tokens — every strength should rise.
    mask = torch.ones(4, lobe.ffn_dim, dtype=torch.bool)
    tracker.update([mask])
    assert (lobe.strength > 0).all()
    # Each neuron won for 100% of tokens -> increment = 0.01
    assert torch.allclose(lobe.strength, torch.tensor(0.01), atol=1e-6)


def test_loser_decay_decreases_strength():
    """A neuron that initially has high strength but never wins should decay
    toward zero."""
    tracker, lobe = _build_tracker(increment=0.01, decay_rate=0.5,
                                    clamp_min=0.0, clamp_max=2.0)
    with torch.no_grad():
        lobe.strength.fill_(1.0)
    # Mask where NO neurons win — but k-WTA always produces SOME winners.
    # The realistic case: a few neurons win, others don't. Here we set
    # only neuron 0 as winner; all others should decay.
    mask = torch.zeros(1, lobe.ffn_dim, dtype=torch.bool)
    mask[0, 0] = True
    tracker.update([mask])
    # Neuron 0: 1.0 * (1-0.5) + 1.0*0.01 = 0.51
    # Other neurons: 1.0 * (1-0.5) + 0 = 0.5
    assert abs(lobe.strength[0].item() - 0.51) < 1e-5
    assert torch.allclose(lobe.strength[1:], torch.tensor(0.5), atol=1e-5)


def test_clamp_prevents_unbounded_growth():
    """Even after 10000 updates with all-winners, strength must not exceed clamp_max."""
    tracker, lobe = _build_tracker(increment=0.1, decay_rate=0.0,
                                    clamp_min=0.0, clamp_max=2.0)
    mask = torch.ones(1, lobe.ffn_dim, dtype=torch.bool)
    for _ in range(10000):
        tracker.update([mask])
    assert (lobe.strength <= 2.0 + 1e-6).all(), \
        f"strength exceeded clamp_max: max={lobe.strength.max().item()}"
    # And should be at the ceiling.
    assert (lobe.strength >= 2.0 - 1e-3).all()


def test_clamp_prevents_negative_strength():
    """Strength must not go below clamp_min even with high decay and no wins."""
    tracker, lobe = _build_tracker(increment=0.01, decay_rate=0.9,
                                    clamp_min=0.0, clamp_max=2.0)
    with torch.no_grad():
        lobe.strength.fill_(0.0)
    # All-zero mask (no winners) — but k-WTA always picks SOME. So simulate
    # by passing None (lobe didn't run).
    for _ in range(1000):
        tracker.update([None])
    assert (lobe.strength >= 0.0 - 1e-6).all(), \
        f"strength went below clamp_min: min={lobe.strength.min().item()}"


def test_disabled_tracker_does_not_modify_strength():
    cfg = HebbianConfig(enabled=False)
    lobes = [Lobe(hidden_dim=16, ffn_dim=32, kwta_ratio=0.25)]
    tracker = HebbianTracker(lobes, cfg)
    with torch.no_grad():
        lobes[0].strength.fill_(0.5)
    mask = torch.ones(2, 32, dtype=torch.bool)
    tracker.update([mask])
    assert torch.allclose(lobes[0].strength, torch.tensor(0.5))


def test_get_strength_map_returns_copy():
    """get_strength_map must return a copy, not a live reference."""
    tracker, lobe = _build_tracker()
    m = tracker.get_strength_map()[0]
    m[0] = 999.0
    # Original must be unchanged.
    assert lobe.strength[0].item() != 999.0


def test_strength_stats():
    tracker, lobe = _build_tracker()
    with torch.no_grad():
        lobe.strength.fill_(0.5)
        lobe.strength[0] = 2.0
        lobe.strength[1] = 0.0
    stats = tracker.get_strength_stats()
    assert "mean" in stats and "min" in stats and "max" in stats
    assert stats["min"] == 0.0
    assert stats["max"] == 2.0
    # frac_at_max should count neurons at 2.0
    assert stats["frac_at_max"] > 0


if __name__ == "__main__":
    import pytest
    pytest.main([__file__, "-v"])
