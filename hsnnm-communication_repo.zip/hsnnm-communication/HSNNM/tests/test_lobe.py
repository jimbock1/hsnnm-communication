"""tests/test_lobe.py — lobe forward shapes + the critical OUTER-SKIP test.

The OUTER-SKIP test is the single most important test in the project.
If it fails, the entire performance rationale collapses: an unselected lobe
that still runs its FFN gives zero compute savings vs a dense model.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import torch
import torch.nn as nn

from model.lobe import Lobe, LobeLayer


def test_lobe_forward_shapes():
    hidden, ffn, k = 32, 64, 16
    lobe = Lobe(hidden_dim=hidden, ffn_dim=ffn, kwta_ratio=k / ffn)
    x = torch.randn(8, hidden)
    out, conf, mask = lobe(x)
    assert out.shape == (8, hidden)
    assert conf.shape == (8, 1)
    assert mask.shape == (8, ffn)
    assert mask.dtype == torch.bool


def test_lobe_kwta_keeps_correct_k():
    hidden, ffn = 16, 40
    lobe = Lobe(hidden_dim=hidden, ffn_dim=ffn, kwta_ratio=0.25)  # k = 10
    x = torch.randn(4, hidden)
    _, _, mask = lobe(x)
    counts = mask.sum(dim=-1)
    assert (counts == 10).all(), f"expected 10 winners per row, got {counts}"


def test_lobe_no_kwta_keeps_all():
    """When use_kwta=False, all neurons survive (mask all True)."""
    lobe = Lobe(hidden_dim=16, ffn_dim=32, kwta_ratio=0.1, use_kwta=False)
    x = torch.randn(4, 16)
    _, _, mask = lobe(x)
    assert mask.all()


def test_lobe_strength_modulation_amplifies_winners():
    """When strength > 0, the activations of those neurons should be
    amplified (by factor 1+strength) before k-WTA — so high-strength
    neurons should be more likely to win k-WTA."""
    torch.manual_seed(42)
    hidden, ffn = 8, 16
    lobe = Lobe(hidden_dim=hidden, ffn_dim=ffn, kwta_ratio=0.5)  # k=8
    # Set neuron 0's strength to max (2.0). Run many forwards; neuron 0
    # should win k-WTA much more often than chance.
    with torch.no_grad():
        lobe.strength[0] = 2.0
    wins = 0
    n_trials = 50
    for _ in range(n_trials):
        x = torch.randn(1, hidden)
        _, _, mask = lobe(x)
        wins += int(mask[0, 0].item())
    # With strength=2.0 (3x amplification), neuron 0 should win almost always.
    assert wins > n_trials * 0.7, f"strength amplification failed: {wins}/{n_trials}"


# =====================================================================
# THE CRITICAL OUTER-SKIP TEST
# =====================================================================

def test_outer_skip_unselected_lobe_never_runs():
    """When top_k=1 and there are 4 lobes, only 1 lobe per token should
    have forward_subnetwork called. The other 3 should NOT execute.

    IMPORTANT: the implementation *batches* all tokens routed to a single
    lobe into ONE forward_subnetwork call (more efficient — a single
    matmul over a batch of tokens). So the correct invariant is NOT
    "number of calls == N*top_k" but rather "total tokens processed
    across all calls == N*top_k". If unselected lobes were being
    computed, total tokens processed would equal N*num_lobes instead.
    """
    hidden, ffn = 16, 32
    num_lobes, top_k = 4, 1
    layer = LobeLayer(
        hidden_dim=hidden, ffn_dim=ffn, num_lobes=num_lobes,
        top_k=top_k, kwta_ratio=0.25, use_kwta=True,
        routing_mode="learned",
    )

    # Wrap each lobe's forward_subnetwork to count TOKENS processed.
    tokens_per_lobe = [0] * num_lobes
    for i, lobe in enumerate(layer.lobes):
        def make_wrapped(idx, orig):
            def wrapped(x):
                tokens_per_lobe[idx] += x.shape[0]  # count tokens, not calls
                return orig(x)
            return wrapped
        lobe.forward_subnetwork = make_wrapped(i, lobe.forward_subnetwork)

    # Run forward on a batch.
    B, T = 4, 8
    x = torch.randn(B, T, hidden)
    out, diag = layer(x)
    assert out.shape == (B, T, hidden)

    # Total tokens processed across all lobe subnetwork calls.
    # Each token routes to top_k=1 lobe, so total tokens processed = B*T*top_k.
    # If unselected lobes were being computed, this would be B*T*num_lobes.
    total_tokens = sum(tokens_per_lobe)
    expected = B * T * top_k
    forbidden = B * T * num_lobes
    assert total_tokens == expected, (
        f"OUTER-SKIP FAILURE: expected {expected} token-processings (B*T*top_k), "
        f"got {total_tokens}. If this equals {forbidden} (B*T*num_lobes), unselected "
        f"lobes are being computed — this silently invalidates the entire performance "
        f"rationale. Per-lobe tokens processed: {tokens_per_lobe}"
    )


def test_outer_skip_dense_mode_runs_all_lobes():
    """In dense routing mode, ALL lobes run for every token. This is the
    'no compute savings' ablation variant — should process B*T*num_lobes
    token-passes total."""
    hidden, ffn = 16, 32
    num_lobes = 4
    layer = LobeLayer(
        hidden_dim=hidden, ffn_dim=ffn, num_lobes=num_lobes,
        top_k=1, kwta_ratio=0.25, use_kwta=True,
        routing_mode="dense",
    )

    tokens_per_lobe = [0] * num_lobes
    for i, lobe in enumerate(layer.lobes):
        def make_wrapped(idx, orig):
            def wrapped(x):
                tokens_per_lobe[idx] += x.shape[0]
                return orig(x)
            return wrapped
        lobe.forward_subnetwork = make_wrapped(i, lobe.forward_subnetwork)

    B, T = 2, 4
    x = torch.randn(B, T, hidden)
    layer(x)

    total_tokens = sum(tokens_per_lobe)
    expected = B * T * num_lobes
    assert total_tokens == expected, (
        f"dense mode should process all lobes per token: expected {expected}, got {total_tokens}"
    )


def test_outer_skip_random_mode_respects_top_k():
    """Random routing mode should also respect top_k — only k lobes per token."""
    hidden, ffn = 16, 32
    num_lobes, top_k = 4, 2
    layer = LobeLayer(
        hidden_dim=hidden, ffn_dim=ffn, num_lobes=num_lobes,
        top_k=top_k, kwta_ratio=0.25, use_kwta=True,
        routing_mode="random",
    )

    tokens_per_lobe = [0] * num_lobes
    for i, lobe in enumerate(layer.lobes):
        def make_wrapped(idx, orig):
            def wrapped(x):
                tokens_per_lobe[idx] += x.shape[0]
                return orig(x)
            return wrapped
        lobe.forward_subnetwork = make_wrapped(i, lobe.forward_subnetwork)

    B, T = 2, 4
    x = torch.randn(B, T, hidden)
    layer(x)
    total_tokens = sum(tokens_per_lobe)
    expected = B * T * top_k
    assert total_tokens == expected, f"random routing: expected {expected}, got {total_tokens}"


if __name__ == "__main__":
    import pytest
    pytest.main([__file__, "-v"])
